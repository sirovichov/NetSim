//! Local virtual management view contracts; never starts a host HTTP server.

pub const WEP_125_MENU: &[&str] = &[
    "Basic Settings",
    "Status",
    "Manage",
    "Services",
    "SNMPv3",
    "Maintenance",
    "Cluster",
    "Captive Portal",
    "Client QoS",
];
