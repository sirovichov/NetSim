//! Bounded capture of actual simulated Ethernet transmissions. No host interfaces.
use netsim_core::{DeviceId, LinkId, PacketId, PortId};
use netsim_packet::{
    ethernet::EthernetFrame,
    ipv4::{IcmpMessage, Ipv4Packet},
};
use std::{
    collections::VecDeque,
    io::{self, Write},
};

pub const ETHERNET_LINK_TYPE: u32 = 1;
pub const CAPACITY: usize = 4096;
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Record {
    pub at: u64,
    pub device: DeviceId,
    pub port: PortId,
    pub link: LinkId,
    pub packet: PacketId,
    pub lost: bool,
    pub bytes: Vec<u8>,
}
#[derive(Default)]
pub struct Capture {
    records: VecDeque<Record>,
    dropped: u64,
}
impl Capture {
    pub fn push(&mut self, r: Record) {
        if self.records.len() == CAPACITY {
            self.records.pop_front();
            self.dropped = self.dropped.saturating_add(1);
        }
        self.records.push_back(r);
    }
    pub fn records(&self) -> &VecDeque<Record> {
        &self.records
    }
    pub fn dropped(&self) -> u64 {
        self.dropped
    }
}
/// Classic little-endian nanosecond PCAP, DLT_EN10MB. Virtual time, no FCS.
pub fn write_pcap(
    mut out: impl Write,
    records: impl IntoIterator<Item = Record>,
) -> io::Result<()> {
    out.write_all(&0xa1b23c4du32.to_le_bytes())?;
    out.write_all(&2u16.to_le_bytes())?;
    out.write_all(&4u16.to_le_bytes())?;
    for v in [0u32, 0, 65535, ETHERNET_LINK_TYPE] {
        out.write_all(&v.to_le_bytes())?;
    }
    for r in records {
        let secs = u32::try_from(r.at / 1_000_000_000)
            .map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "PCAP timestamp overflow"))?;
        let len = u32::try_from(r.bytes.len())
            .map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "frame too long"))?;
        if len > 65535 {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "frame too long",
            ));
        }
        for v in [secs, (r.at % 1_000_000_000) as u32, len, len] {
            out.write_all(&v.to_le_bytes())?;
        }
        out.write_all(&r.bytes)?;
    }
    Ok(())
}
/// Layers 5/6 are not fabricated for protocols without such model.
pub fn inspect(r: &Record) -> Vec<String> {
    let mut out = vec![format!(
        "L1 virtual link {:?}, {} ns, {} bytes, lost={}",
        r.link,
        r.at,
        r.bytes.len(),
        r.lost
    )];
    let Ok(f) = EthernetFrame::decode(&r.bytes) else {
        out.push("L2 malformed Ethernet".into());
        return out;
    };
    out.push(format!(
        "L2 Ethernet {:?} -> {:?}, type/length 0x{:04x}, tag {:?}",
        f.src, f.dst, f.kind, f.tag
    ));
    match f.kind {
        0x0806 if f.payload.len() >= 28 => {
            let p = &f.payload;
            out.push(format!(
                "L2/L3 ARP op {}: {} -> {}",
                u16::from_be_bytes([p[6], p[7]]),
                std::net::Ipv4Addr::new(p[14], p[15], p[16], p[17]),
                std::net::Ipv4Addr::new(p[24], p[25], p[26], p[27])
            ));
        }
        0x0800 => match Ipv4Packet::decode(&f.payload) {
            Ok(ip) => {
                out.push(format!(
                    "L3 IPv4 {} -> {}, TTL {}, protocol {}, ID {}",
                    ip.src, ip.dst, ip.ttl, ip.protocol, ip.identification
                ));
                match ip.protocol {
                    1 => out.push(format!("L3 ICMP {:?}", IcmpMessage::decode(&ip.payload))),
                    17 if ip.payload.len() >= 8 => {
                        let p = &ip.payload;
                        let a = u16::from_be_bytes([p[0], p[1]]);
                        let b = u16::from_be_bytes([p[2], p[3]]);
                        out.push(format!(
                            "L4 UDP {a} -> {b}, length {}",
                            u16::from_be_bytes([p[4], p[5]])
                        ));
                        if (a, b) == (67, 68) || (a, b) == (68, 67) {
                            out.push("L7 DHCP / BOOTP".into());
                        }
                    }
                    89 => out.push("L3 OSPF teaching wire format (not RFC 2328)".into()),
                    _ => {}
                }
            }
            Err(e) => out.push(format!("L3 IPv4 decode error: {e:?}")),
        },
        _ if f.dst == netsim_packet::ethernet::STP_MAC => out.push("L2 STP control frame".into()),
        _ => {}
    }
    out
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn pcap_header_and_record() {
        let r = Record {
            at: 1_000_000_005,
            device: DeviceId(1),
            port: PortId(1),
            link: LinkId(1),
            packet: PacketId(1),
            lost: false,
            bytes: vec![0; 14],
        };
        let mut b = vec![];
        write_pcap(&mut b, [r]).unwrap();
        assert_eq!(&b[..4], &[0x4d, 0x3c, 0xb2, 0xa1]);
        assert_eq!(&b[24..32], &[1, 0, 0, 0, 5, 0, 0, 0]);
        assert_eq!(b.len(), 54);
    }
}

#[cfg(test)]
mod capacity_tests {
    use super::*;
    #[test]
    fn bounded_eviction() {
        let mut c = Capture::default();
        for i in 0..=CAPACITY {
            c.push(Record {
                at: i as u64,
                device: DeviceId(1),
                port: PortId(1),
                link: LinkId(1),
                packet: PacketId(i as u64),
                lost: false,
                bytes: vec![0; 14],
            });
        }
        assert_eq!(c.records().len(), CAPACITY);
        assert_eq!(c.dropped(), 1);
        assert_eq!(c.records()[0].at, 1);
    }
}
