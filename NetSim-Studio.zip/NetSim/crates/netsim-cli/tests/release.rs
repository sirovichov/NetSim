use std::{fs, process::Command};

#[test]
fn release_version_matches_manifest() {
    let output = Command::new(env!("CARGO_BIN_EXE_netsim-cli"))
        .arg("--version")
        .output()
        .unwrap();
    assert!(output.status.success());
    assert_eq!(
        String::from_utf8(output.stdout).unwrap().trim(),
        concat!("NetSim Studio ", env!("CARGO_PKG_VERSION"))
    );
}

#[test]
fn incomplete_lab_is_nonzero() {
    let dir = std::env::temp_dir().join(format!("netsim-lab-{}", std::process::id()));
    fs::create_dir_all(&dir).unwrap();
    let path = dir.join("incomplete.netsim");
    let exe = env!("CARGO_BIN_EXE_netsim-cli");
    let start = Command::new(exe)
        .args(["lab-start", "LAB-001"])
        .arg(&path)
        .output()
        .unwrap();
    assert!(start.status.success(), "{start:?}");
    let grade = Command::new(exe)
        .args(["lab-grade", "LAB-001"])
        .arg(&path)
        .output()
        .unwrap();
    let _ = fs::remove_dir_all(dir);
    assert!(!grade.status.success());
    assert!(String::from_utf8_lossy(&grade.stderr).contains("0/100"));
}

#[test]
fn validate_checks_runtime_ports_without_modifying_project() {
    let exe = env!("CARGO_BIN_EXE_netsim-cli");
    let sample = include_str!("../../../examples/two-pcs.netsim");
    let path = std::env::temp_dir().join(format!("netsim-validate-{}.netsim", std::process::id()));
    fs::write(&path, sample).unwrap();
    let run = || {
        Command::new(exe)
            .arg("validate")
            .arg(&path)
            .output()
            .unwrap()
    };
    let valid = run();
    assert!(valid.status.success());
    assert!(String::from_utf8_lossy(&valid.stdout).contains("nodes=2, cables=1"));
    assert_eq!(fs::read_to_string(&path).unwrap(), sample);
    fs::write(&path, sample.replacen("eth0", "bad-port", 1)).unwrap();
    let invalid = run();
    fs::remove_file(path).unwrap();
    assert!(!invalid.status.success());
    assert!(String::from_utf8_lossy(&invalid.stderr).contains("bad-port"));
}

#[test]
fn arp_lab_requires_configuring_the_second_host() {
    let exe = env!("CARGO_BIN_EXE_netsim-cli");
    let path = std::env::temp_dir().join(format!("netsim-arp-{}.netsim", std::process::id()));
    let run = |cmd| {
        Command::new(exe)
            .args([cmd, "LAB-002"])
            .arg(&path)
            .output()
            .unwrap()
    };
    assert!(run("lab-start").status.success());
    let before = run("lab-grade");
    assert!(!before.status.success());
    assert!(String::from_utf8_lossy(&before.stderr).contains("0/100"));
    let mut project = netsim_storage::load(&path).unwrap();
    project.nodes.iter_mut().find(|n| n.id == 2).unwrap().host = Some(netsim_storage::HostConfig {
        ip: "10.0.0.2".parse().unwrap(),
        prefix: 24,
        gateway: None,
    });
    netsim_storage::save(&path, &project).unwrap();
    let after = run("lab-grade");
    fs::remove_file(path).unwrap();
    assert!(after.status.success());
    assert!(String::from_utf8_lossy(&after.stdout).contains("100/100"));
}
