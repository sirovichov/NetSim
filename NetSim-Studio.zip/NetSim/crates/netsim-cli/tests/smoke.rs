use std::process::Command;

#[test]
fn catalog_and_demo() {
    let exe = env!("CARGO_BIN_EXE_netsim-cli");
    let output = Command::new(exe).arg("catalog").output().unwrap();
    assert!(output.status.success());
    let text = String::from_utf8(output.stdout).unwrap();
    assert_eq!(text.lines().count(), 9);
    assert!(text.contains("eltex.ap.wep2ac"));
    let output = Command::new(exe).arg("demo").output().unwrap();
    assert!(output.status.success());
    let text = String::from_utf8(output.stdout).unwrap();
    assert!(text.contains("10 ns #1"));
    assert!(text.contains("virtual clock: 30 ns"));
}

#[test]
fn invalid_command_has_nonzero_exit() {
    let status = Command::new(env!("CARGO_BIN_EXE_netsim-cli"))
        .arg("unknown")
        .status()
        .unwrap();
    assert_eq!(status.code(), Some(2));
}

#[test]
fn core_demo() {
    let output = Command::new(env!("CARGO_BIN_EXE_netsim-cli"))
        .arg("core-demo")
        .output()
        .unwrap();
    assert!(output.status.success());
    let text = String::from_utf8(output.stdout).unwrap();
    assert!(text.contains("5 ns device=1"));
    assert!(text.contains("10 ns device=2"));
    assert!(text.contains("devices: 2"));
    assert!(text.contains("pending events: 0"));
    assert!(text.contains("virtual clock: 30 ns"));
}

#[test]
fn l2_demo() {
    let output = Command::new(env!("CARGO_BIN_EXE_netsim-cli"))
        .arg("l2-demo")
        .output()
        .unwrap();
    assert!(output.status.success());
    assert!(
        String::from_utf8(output.stdout)
            .unwrap()
            .contains("ARP resolution successful")
    );
}

#[test]
fn l3_demo() {
    let output = Command::new(env!("CARGO_BIN_EXE_netsim-cli"))
        .arg("l3-demo")
        .output()
        .unwrap();
    assert!(output.status.success());
    let text = String::from_utf8(output.stdout).unwrap();
    assert!(text.contains("IPv4 routing and ICMP successful"));
    assert!(text.contains("TimeExceeded"));
}

#[test]
fn cisco_console_and_demo() {
    use std::io::Write;
    use std::process::Stdio;
    let exe = env!("CARGO_BIN_EXE_netsim-cli");
    let output = Command::new(exe).arg("cisco-demo").output().unwrap();
    assert!(output.status.success());
    assert!(
        String::from_utf8(output.stdout)
            .unwrap()
            .contains("Cisco IOS simulation successful")
    );
    let mut child = Command::new(exe)
        .args(["cisco", "router"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .spawn()
        .unwrap();
    child
        .stdin
        .take()
        .unwrap()
        .write_all(b"en\nconf t\nhostname R1\nend\nshow running-config\n:quit\n")
        .unwrap();
    let output = child.wait_with_output().unwrap();
    assert!(output.status.success());
    let stdout = String::from_utf8(output.stdout).unwrap();
    assert!(stdout.contains("R1(config)#"));
    assert!(stdout.contains("hostname R1"));
}

#[test]
fn eltex_demo_smoke() {
    let out = Command::new(env!("CARGO_BIN_EXE_netsim-cli"))
        .arg("eltex-demo")
        .output()
        .unwrap();
    assert!(out.status.success());
    assert!(
        String::from_utf8(out.stdout)
            .unwrap()
            .contains("Cisco/Eltex simulation successful")
    );
}

#[test]
fn wireless_demo_smoke() {
    let out = Command::new(env!("CARGO_BIN_EXE_netsim-cli"))
        .arg("wireless-demo")
        .output()
        .unwrap();
    assert!(
        out.status.success(),
        "{:?}",
        String::from_utf8_lossy(&out.stderr)
    );
    assert!(
        String::from_utf8(out.stdout)
            .unwrap()
            .contains("Wireless DHCP simulation successful")
    );
}
