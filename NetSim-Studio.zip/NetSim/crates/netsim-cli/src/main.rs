use std::process::ExitCode;

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    match args.as_slice() {
        [] => help(),
        [arg] if arg == "--help" || arg == "-h" => help(),
        [arg] if arg == "--version" || arg == "-V" => {
            println!("NetSim Studio {}", env!("CARGO_PKG_VERSION"));
            ExitCode::SUCCESS
        }
        [arg] if arg == "catalog" => {
            for (id, profile) in netsim_app::catalog() {
                println!("{id}\t{} {}\tdraft", profile.vendor, profile.model);
            }
            ExitCode::SUCCESS
        }
        [arg] if arg == "demo" => match netsim_app::scheduler_demo() {
            Ok(report) => {
                for event in report.events {
                    println!("{} ns #{} {:?}", event.at, event.sequence, event.kind);
                }
                println!("virtual clock: {} ns", report.now);
                ExitCode::SUCCESS
            }
            Err(error) => {
                eprintln!("{error}");
                ExitCode::FAILURE
            }
        },
        [arg] if arg == "core-demo" => match netsim_app::core_demo() {
            Ok((snapshot, trace)) => {
                for entry in trace.entries {
                    println!(
                        "{} ns device={} {:?} {:?}",
                        entry.at, entry.device.0, entry.action, entry.outcome
                    );
                }
                println!("devices: {}", snapshot.devices.len());
                println!("pending events: {}", snapshot.pending_events);
                println!("virtual clock: {} ns", snapshot.now);
                ExitCode::SUCCESS
            }
            Err(error) => {
                eprintln!("{error}");
                ExitCode::FAILURE
            }
        },
        [arg] if arg == "l2-demo" => match netsim_app::l2_demo() {
            Ok(snapshot) => {
                for (id, host) in snapshot.l2.hosts {
                    println!("host {} {} ARP {:?}", id.0, host.ip, host.arp);
                }
                for (id, bridge) in snapshot.l2.switches {
                    println!("switch {} learned MACs: {}", id.0, bridge.macs.len());
                }
                println!("ARP resolution successful");
                ExitCode::SUCCESS
            }
            Err(error) => {
                eprintln!("{error}");
                ExitCode::FAILURE
            }
        },
        [arg] if arg == "l3-demo" => match netsim_app::l3_demo() {
            Ok((ping, hops)) => {
                println!("Ping {}: {:?}", ping.destination, ping.status);
                println!("Traceroute:");
                for hop in hops {
                    println!("{} {:?}", hop.ttl, hop.status);
                }
                println!("IPv4 routing and ICMP successful");
                ExitCode::SUCCESS
            }
            Err(error) => {
                eprintln!("{error}");
                ExitCode::FAILURE
            }
        },
        [arg] if arg == "cisco-demo" => match netsim_app::cisco_demo() {
            Ok(output) => {
                println!("{output}");
                ExitCode::SUCCESS
            }
            Err(error) => {
                eprintln!("{error}");
                ExitCode::FAILURE
            }
        },
        [arg, model] if arg == "cisco" => console(model),
        [arg, model] if arg == "eltex" => eltex_console(model),
        [arg] if arg == "eltex-demo" => match netsim_app::eltex_demo() {
            Ok(output) => {
                println!("{output}");
                ExitCode::SUCCESS
            }
            Err(error) => {
                eprintln!("{error}");
                ExitCode::FAILURE
            }
        },
        [arg] if arg == "wireless-demo" => match netsim_app::wireless_demo() {
            Ok(output) => {
                println!("{output}");
                ExitCode::SUCCESS
            }
            Err(error) => {
                eprintln!("{error}");
                ExitCode::FAILURE
            }
        },
        [arg] if arg == "labs" => {
            for (id, title) in netsim_app::beta_labs::CATALOG {
                println!("{id} {title}");
            }
            ExitCode::SUCCESS
        }
        [arg, path] if arg == "validate" => beta_result(validate_project(path)),
        [arg] if arg == "lab-verify" => beta_result(verify_labs()),
        [arg, id, path] if arg == "lab-start" || arg == "lab-grade" => {
            beta_result(lab_command(arg, id, path))
        }
        [arg, path, node, command @ ..] if arg == "service" && !command.is_empty() => {
            beta_result(service_command(path, node, &command.join(" ")))
        }
        [arg, path, source, destination, output] if arg == "capture-ping" => {
            beta_result(capture_ping(path, source, destination, output))
        }
        _ => {
            eprintln!("Unknown command. Use --help.");
            ExitCode::from(2)
        }
    }
}

fn help() -> ExitCode {
    println!(
        "NetSim Studio {}\n\
         Usage: netsim-cli COMMAND [ARGUMENTS]\n\n\
         Projects\n  validate FILE                Load a project and check its topology\n  capture-ping FILE NODE IP PCAP\n  service FILE NODE COMMAND\n\n\
         Labs\n  labs                         List available labs\n  lab-start ID FILE            Save the starter project\n  lab-grade ID FILE            Grade a saved project\n  lab-verify                   Verify all reference solutions\n\n\
         Devices and demos\n  catalog\n  cisco router | cisco switch | eltex mes | eltex esr\n  demo | core-demo | l2-demo | l3-demo | cisco-demo | eltex-demo | wireless-demo\n\n\
         --version | --help",
        env!("CARGO_PKG_VERSION")
    );
    ExitCode::SUCCESS
}

fn console(model: &str) -> ExitCode {
    use netsim_app::{CiscoLab, CiscoModel, CiscoSessionId};
    use std::io::{self, BufRead, Write};
    let model = match model {
        "router" => CiscoModel::Isr2911,
        "switch" => CiscoModel::Catalyst2960,
        _ => {
            eprintln!("Use cisco router or cisco switch");
            return ExitCode::from(2);
        }
    };
    let result = (|| -> Result<(), Box<dyn std::error::Error>> {
        let mut lab = CiscoLab::new(42)?;
        let id = lab.add(
            model,
            if model == CiscoModel::Isr2911 {
                "Router"
            } else {
                "Switch"
            },
        )?;
        let session = CiscoSessionId(1);
        let stdin = io::stdin();
        let mut input = stdin.lock();
        let mut line = String::new();
        println!(
            "Educational console. Use ? for help, :quit to leave. No physical network access."
        );
        loop {
            print!("{} ", lab.prompt(id, session)?);
            io::stdout().flush()?;
            line.clear();
            if input.read_line(&mut line)? == 0 {
                break;
            }
            let command = line.trim_end_matches(['\r', '\n']);
            if command == ":quit" {
                break;
            }
            let result = lab.execute(id, session, command)?;
            if !result.is_empty() {
                println!("{result}");
            }
        }
        Ok(())
    })();
    match result {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("{error}");
            ExitCode::FAILURE
        }
    }
}

fn eltex_console(model: &str) -> ExitCode {
    use netsim_app::{CiscoSessionId, EltexModel, MixedLab};
    use std::io::{self, BufRead, Write};
    let model = match model {
        "mes" => EltexModel::Mes2428,
        "esr" => EltexModel::Esr100,
        _ => {
            eprintln!("Use eltex mes or eltex esr");
            return ExitCode::from(2);
        }
    };
    let result = (|| -> Result<(), Box<dyn std::error::Error>> {
        let mut lab = MixedLab::new(42)?;
        let id = lab.add_eltex(
            model,
            if model == EltexModel::Mes2428 {
                "console"
            } else {
                "esr"
            },
        )?;
        let session = CiscoSessionId(1);
        let stdin = io::stdin();
        let mut input = stdin.lock();
        let mut line = String::new();
        println!(
            "Educational Eltex console. ? for help, :quit to leave, :advance SECONDS to advance virtual time."
        );
        loop {
            print!("{} ", lab.prompt(id, session)?);
            io::stdout().flush()?;
            line.clear();
            if input.read_line(&mut line)? == 0 {
                break;
            }
            let cmd = line.trim();
            if cmd == ":quit" {
                break;
            }
            if let Some(n) = cmd.strip_prefix(":advance ") {
                if let Some(ns) = n
                    .parse::<u64>()
                    .ok()
                    .and_then(|s| s.checked_mul(1_000_000_000))
                {
                    lab.run_for(ns)?;
                } else {
                    println!("Invalid seconds");
                }
                continue;
            }
            let out = lab.execute(id, session, cmd)?;
            if !out.is_empty() {
                println!("{out}");
            }
        }
        Ok(())
    })();
    match result {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("{e}");
            ExitCode::FAILURE
        }
    }
}

fn beta_result(result: Result<String, String>) -> ExitCode {
    match result {
        Ok(s) => {
            println!("{s}");
            ExitCode::SUCCESS
        }
        Err(e) => {
            eprintln!("{e}");
            ExitCode::FAILURE
        }
    }
}
fn lab_command(action: &str, id: &str, path: &str) -> Result<String, String> {
    use netsim_app::beta_labs::{CATALOG, grade, starter};
    use std::path::Path;
    let i = CATALOG
        .iter()
        .position(|(key, _)| *key == id)
        .ok_or("Unknown lab ID")?;
    let l = starter(i)?;
    if action == "lab-start" {
        netsim_storage::save(Path::new(path), &l.starter)?;
        return Ok(format!("{}: {}", l.title, l.instructions));
    }
    let g = grade(netsim_storage::load(Path::new(path))?, &l.checks)?;
    let score = g.iter().map(|x| x.points).sum::<u32>();
    let report = format!(
        "{score}/100\n{}",
        g.iter()
            .map(|x| format!("{} {}", if x.passed { "PASS" } else { "FAIL" }, x.label))
            .collect::<Vec<_>>()
            .join("\n")
    );
    if score == 100 {
        Ok(report)
    } else {
        Err(report)
    }
}
fn verify_labs() -> Result<String, String> {
    use netsim_app::beta_labs::{CATALOG, grade, reference};
    let mut lines = Vec::new();
    let mut failed = false;
    for (i, (id, _)) in CATALOG.iter().enumerate() {
        match reference(i).and_then(|l| grade(l.starter, &l.checks)) {
            Ok(g) => {
                let score = g.iter().map(|x| x.points).sum::<u32>();
                let pass = score == 100 && !g.is_empty() && g.iter().all(|x| x.passed);
                failed |= !pass;
                lines.push(format!(
                    "{id}: {score}/100 {}",
                    if pass { "PASS" } else { "FAIL" }
                ));
            }
            Err(e) => {
                failed = true;
                lines.push(format!("{id}: ERROR {e}"));
            }
        }
    }
    if failed {
        Err(lines.join("\n"))
    } else {
        Ok(lines.join("\n"))
    }
}
fn validate_project(path: &str) -> Result<String, String> {
    let project = netsim_storage::load(std::path::Path::new(path))?;
    let version = project.schema_version;
    let desktop = netsim_app::desktop::Desktop::from_project(project)?;
    Ok(format!(
        "OK: schema={version}, nodes={}, cables={}",
        desktop.nodes().len(),
        desktop.cables().len()
    ))
}

fn service_command(path: &str, node: &str, command: &str) -> Result<String, String> {
    use std::path::Path;
    let path = Path::new(path);
    let mut d = netsim_app::desktop::Desktop::from_project(netsim_storage::load(path)?)?;
    let id = node.parse().map_err(|_| "Invalid node ID")?;
    let output = d.service_cli(id, command)?;
    if command.split_whitespace().last() != Some("show") {
        netsim_storage::save(path, &d.export()?)?;
    }
    Ok(output)
}
fn capture_ping(
    path: &str,
    source: &str,
    destination: &str,
    output: &str,
) -> Result<String, String> {
    use std::path::Path;
    let mut d = netsim_app::desktop::Desktop::from_project(netsim_storage::load(Path::new(path))?)?;
    for _ in 0..50 {
        d.advance(1_000_000_000)?;
    }
    let id = source.parse().map_err(|_| "Invalid node ID")?;
    let ip = destination.parse().map_err(|_| "Invalid destination")?;
    let token = d.ping(id, ip)?;
    for _ in 0..6 {
        d.advance(1_000_000_000)?;
    }
    let snapshot = d.snapshot();
    let replied = snapshot.l3.nodes.iter().any(|n| {
        Some(n.device) == d.engine_id(id)
            && n.probes.iter().any(|p| {
                p.token == token && matches!(p.status, netsim_engine::ProbeStatus::Reply { .. })
            })
    });
    if !replied {
        return Err(format!("Probe {token} did not receive an ICMP reply"));
    }
    let f = std::fs::File::create(output).map_err(|e| e.to_string())?;
    netsim_capture::write_pcap(f, d.capture().records().iter().cloned())
        .map_err(|e| e.to_string())?;
    Ok(format!(
        "Probe {token}; exported {} frames; {} evicted",
        d.capture().records().len(),
        d.capture().dropped()
    ))
}
