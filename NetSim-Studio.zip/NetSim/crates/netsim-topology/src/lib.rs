//! Topology contracts. Full graph mutation and validation are scheduled for WP3.

use netsim_types::{DeviceId, LinkId, MediaKind, PortId};

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Port {
    pub id: PortId,
    pub device: DeviceId,
    pub media: MediaKind,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Link {
    pub id: LinkId,
    pub endpoints: [PortId; 2],
    pub bandwidth_bps: u64,
    pub delay_ns: u64,
    pub loss_ppm: u32,
    pub queue_limit_bytes: u64,
}

impl Link {
    /// Local invariants only; endpoint existence is checked by the future graph.
    pub fn is_valid(&self) -> bool {
        self.endpoints[0] != self.endpoints[1]
            && self.bandwidth_bps > 0
            && self.loss_ppm <= 1_000_000
            && self.queue_limit_bytes > 0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn link_rejects_same_endpoint_and_bad_loss() {
        let mut link = Link {
            id: LinkId(3),
            endpoints: [PortId(1), PortId(2)],
            bandwidth_bps: 1_000_000,
            delay_ns: 100,
            loss_ppm: 0,
            queue_limit_bytes: 1024,
        };
        assert!(link.is_valid());
        link.loss_ppm = 1_000_001;
        assert!(!link.is_valid());
        link.loss_ppm = 0;
        link.endpoints[1] = link.endpoints[0];
        assert!(!link.is_valid());
    }
}
