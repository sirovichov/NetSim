//! Educational Eltex device models and independent management console.
mod cli;
mod config;
pub use cli::EltexDevice;
pub use config::Model;

use netsim_devices::DeviceDescriptor;

pub const PROFILES: &[DeviceDescriptor] = &[
    DeviceDescriptor {
        profile_id: "eltex.switch.mes2428",
        profile_version: 1,
        vendor: "Eltex",
        model: "MES2428",
        firmware_reference: Some("10.4.2.1"),
    },
    DeviceDescriptor {
        profile_id: "eltex.router.esr100",
        profile_version: 1,
        vendor: "Eltex",
        model: "ESR-100",
        firmware_reference: Some("1.34"),
    },
    DeviceDescriptor {
        profile_id: "eltex.ap.wep2ac",
        profile_version: 1,
        vendor: "Eltex",
        model: "WEP-2ac",
        firmware_reference: Some("1.25.0"),
    },
    DeviceDescriptor {
        profile_id: "eltex.ap.wep2ac-smart",
        profile_version: 1,
        vendor: "Eltex",
        model: "WEP-2ac Smart",
        firmware_reference: Some("1.25.0"),
    },
];
