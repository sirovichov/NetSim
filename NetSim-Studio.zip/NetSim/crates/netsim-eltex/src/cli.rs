//! Eltex-specific command grammar and configuration lifecycle.
use crate::config::{Config, Interface, Model, StaticRoute, list_text, vlan_id, vlan_list};
use netsim_core::{DeviceId, EngineError, MacAddress, MediaKind, PortId, SessionId};
use netsim_engine::{Engine, InterfaceConfig, InterfaceKey, Ipv4Prefix, PortMode, ProbeStatus};
use std::{collections::BTreeMap, fmt::Write as _, net::Ipv4Addr};
const SEC: u64 = 1_000_000_000;

#[derive(Clone, Debug, Default)]
enum Mode {
    #[default]
    Root,
    User,
    Global,
    Interface(String),
    Vlan(u16),
}

pub struct EltexDevice {
    id: DeviceId,
    model: Model,
    running: Config,
    candidate: Config,
    startup: Config,
    pending: Option<(u64, Config)>,
    sessions: BTreeMap<SessionId, Mode>,
}

fn name_ok(s: &str) -> bool {
    !s.is_empty()
        && s.len() <= 63
        && s.bytes()
            .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
}
fn vid(s: &str) -> Result<u16, String> {
    vlan_id(s).ok_or("Invalid VLAN ID".into())
}
fn cidr(s: &str) -> Result<(Ipv4Addr, u8), String> {
    let (a, b) = s.split_once('/').ok_or("Expected IPv4/prefix")?;
    let ip = a.parse().map_err(|_| "Invalid IPv4 address")?;
    let len = b.parse::<u8>().map_err(|_| "Invalid prefix length")?;
    if len > 32 {
        return Err("Invalid prefix length".into());
    }
    Ok((ip, len))
}
fn ip(s: &str) -> Result<Ipv4Addr, String> {
    s.parse().map_err(|_| "Invalid IPv4 address".into())
}
fn mac(port: PortId) -> MacAddress {
    let b = port.0.to_be_bytes();
    MacAddress([2, 0x45, b[4], b[5], b[6], b[7]])
}
fn fmt_mac(mac: MacAddress) -> String {
    mac.0
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect::<Vec<_>>()
        .join(":")
}

impl EltexDevice {
    pub fn create(engine: &mut Engine, model: Model, hostname: &str) -> Result<Self, EngineError> {
        if !name_ok(hostname) {
            return Err(EngineError::InvalidInput);
        }
        let id = engine.add_device(model.profile(), 1, hostname.into())?;
        let result = (|| {
            let mut interfaces = BTreeMap::new();
            for name in model.port_names() {
                let port = engine.add_port(id, MediaKind::Ethernet)?;
                interfaces.insert(name, Interface::new(port, mac(port), false));
            }
            if model.is_switch() {
                let b = id.0.to_be_bytes();
                engine.configure_switch(
                    id,
                    32768,
                    MacAddress([2, 0x46, b[4], b[5], b[6], b[7]]),
                )?;
                for i in interfaces.values() {
                    engine.configure_switch_port(id, i.port, PortMode::Access(1))?;
                }
            } else {
                engine.configure_router(id)?;
            }
            let c = Config {
                hostname: hostname.into(),
                interfaces,
                vlans: [(1, "default".into())].into_iter().collect(),
                routes: Vec::new(),
            };
            engine.power_on(id)?;
            Ok(Self {
                id,
                model,
                running: c.clone(),
                candidate: c.clone(),
                startup: c,
                pending: None,
                sessions: BTreeMap::new(),
            })
        })();
        if result.is_err() {
            let _ = engine.remove_device(id);
        }
        result
    }
    pub fn export_config(&self) -> Result<serde_json::Value, String> {
        if self.pending.is_some() {
            return Err("Confirm or restore pending ESR commit before saving".into());
        }
        Ok(
            serde_json::json!({"running":self.running,"candidate":self.candidate,"startup":self.startup}),
        )
    }
    /// Only for freshly created devices while opening a new project.
    pub fn import_config(
        &mut self,
        engine: &mut Engine,
        value: serde_json::Value,
    ) -> Result<(), String> {
        #[derive(serde::Deserialize)]
        #[serde(deny_unknown_fields)]
        struct Saved {
            running: Config,
            candidate: Config,
            startup: Config,
        }
        let s: Saved = serde_json::from_value(value).map_err(|e| e.to_string())?;
        let running = s.running.remap(&self.running, self.model)?;
        let candidate = s.candidate.remap(&self.running, self.model)?;
        let startup = s.startup.remap(&self.running, self.model)?;
        self.install(engine, running)?;
        self.candidate = candidate;
        self.startup = startup;
        self.sessions.clear();
        Ok(())
    }
    pub fn id(&self) -> DeviceId {
        self.id
    }
    pub fn port(&self, name: &str) -> Option<PortId> {
        let lower = name.to_ascii_lowercase();
        let n = lower
            .strip_prefix("gigabitethernet")
            .or_else(|| lower.strip_prefix("gi"))
            .unwrap_or(&lower)
            .trim();
        self.running
            .interfaces
            .get(n)
            .filter(|i| i.parent.is_none())
            .map(|i| i.port)
    }
    fn mode(&self, id: SessionId) -> Mode {
        self.sessions
            .get(&id)
            .cloned()
            .unwrap_or(if self.model.is_switch() {
                Mode::User
            } else {
                Mode::Root
            })
    }
    pub fn prompt(&self, session: SessionId) -> String {
        let suffix = match self.mode(session) {
            Mode::User => ">",
            Mode::Root => "#",
            Mode::Global => "(config)#",
            Mode::Interface(_) if self.model.is_switch() => "(config-if)#",
            Mode::Interface(ref n) if n.contains('.') => "(config-if-sub)#",
            Mode::Interface(_) => "(config-if-gi)#",
            Mode::Vlan(_) => "(config-vlan)#",
        };
        format!("{}{suffix}", self.running.hostname)
    }
    pub fn running_config(&self) -> String {
        self.running.render(self.model)
    }
    pub fn candidate_config(&self) -> String {
        self.candidate.render(self.model)
    }
    pub fn startup_config(&self) -> String {
        self.startup.render(self.model)
    }
    pub fn deadline(&self) -> Option<u64> {
        self.pending.as_ref().map(|(t, _)| *t)
    }
    /// Called by the mixed lab at virtual-time boundaries.
    pub fn expire(&mut self, engine: &mut Engine) -> Result<(), String> {
        if self.deadline().is_some_and(|t| engine.now() >= t) {
            let old = self.pending.as_ref().ok_or("No pending commit")?.1.clone();
            self.install(engine, old.clone())?;
            self.candidate = old;
            self.pending = None;
        }
        Ok(())
    }
    fn install(&mut self, engine: &mut Engine, c: Config) -> Result<(), String> {
        let snap = engine.snapshot();
        if c.interfaces.values().any(|i| {
            !snap
                .ports
                .iter()
                .any(|p| p.id == i.port && p.device == self.id)
        }) {
            return Err("Missing physical port".into());
        }
        if self.model.is_switch() {
            for (name, i) in &c.interfaces {
                let m = i.mode(&c.vlans);
                if self
                    .running
                    .interfaces
                    .get(name)
                    .is_none_or(|old| old.mode(&self.running.vlans) != m)
                {
                    engine
                        .set_switch_port_mode(self.id, i.port, m)
                        .map_err(|e| e.to_string())?;
                }
            }
        } else {
            let data = c.router_data().map_err(str::to_owned)?;
            if data != self.running.router_data().map_err(str::to_owned)? {
                engine
                    .replace_router_config(self.id, &data.0, &data.1)
                    .map_err(|e| e.to_string())?;
            }
        }
        for i in c.interfaces.values().filter(|i| i.parent.is_none()) {
            engine
                .set_port_admin(i.port, !i.shutdown)
                .map_err(|e| e.to_string())?;
        }
        engine
            .set_hostname(self.id, c.hostname.clone())
            .map_err(|e| e.to_string())?;
        self.running = c;
        Ok(())
    }
    fn edit(&mut self, engine: &mut Engine, c: Config) -> Result<(), String> {
        if self.model.is_switch() {
            self.install(engine, c.clone())?;
        }
        self.candidate = c;
        Ok(())
    }
    pub fn execute(&mut self, engine: &mut Engine, session: SessionId, line: &str) -> String {
        if line.len() > 4096 {
            return "% Command too long".into();
        }
        if !self.sessions.contains_key(&session) && self.sessions.len() >= 64 {
            return "% Session limit".into();
        }
        let mut mode = self.mode(session);
        let result = self
            .expire(engine)
            .and_then(|()| self.command(engine, &mut mode, line));
        self.sessions.insert(session, mode);
        result.unwrap_or_else(|e| format!("% {e}"))
    }
    fn command(
        &mut self,
        engine: &mut Engine,
        mode: &mut Mode,
        line: &str,
    ) -> Result<String, String> {
        let words: Vec<_> = line.split_whitespace().collect();
        let a = words.as_slice();
        let switch = self.model.is_switch();
        if a.is_empty() {
            return Ok(String::new());
        }
        if a == ["?"] {
            return Ok(self.help(mode));
        }
        if a == ["exit"] {
            *mode = match mode {
                Mode::Interface(_) | Mode::Vlan(_) => Mode::Global,
                Mode::Global => Mode::Root,
                _ if switch => Mode::User,
                _ => Mode::Root,
            };
            return Ok(String::new());
        }
        if a == ["end"] && !matches!(mode, Mode::User) {
            *mode = Mode::Root;
            return Ok(String::new());
        }
        match (&*mode, a) {
            (Mode::User, ["enable"]) if switch => *mode = Mode::Root,
            (Mode::Root, ["disable"]) if switch => *mode = Mode::User,
            (Mode::Root, ["configure", "terminal"]) if switch => *mode = Mode::Global,
            (Mode::Root, ["configure"]) if !switch => *mode = Mode::Global,
            (Mode::Root, ["show", ..]) => return self.show(engine, a),
            (
                Mode::Root,
                ["write", "startup-config"] | ["copy", "running-config", "startup-config"],
            ) if switch => {
                self.startup = self.running.clone();
                return Ok("Configuration saved.".into());
            }
            (Mode::Root | Mode::Global, ["commit"] | ["commit", "confirm-timeout", _])
                if !switch =>
            {
                if self.pending.is_some() {
                    return Err("Confirm or restore the outstanding commit first".into());
                }
                let seconds = if a.len() == 3 {
                    a[2].parse::<u64>().map_err(|_| "Invalid timeout")?
                } else {
                    600
                };
                if !(120..=86400).contains(&seconds) {
                    return Err("Timeout must be 120..86400 seconds".into());
                }
                let deadline = engine
                    .now()
                    .checked_add(seconds * SEC)
                    .ok_or("Time overflow")?;
                let old = self.running.clone();
                self.install(engine, self.candidate.clone())?;
                self.pending = Some((deadline, old));
                return Ok("Configuration applied; confirm required.".into());
            }
            (Mode::Root | Mode::Global, ["confirm"]) if !switch => {
                if self.pending.take().is_none() {
                    return Err("No pending commit".into());
                }
                self.startup = self.running.clone();
                return Ok("Configuration confirmed.".into());
            }
            (Mode::Root, ["rollback"]) if !switch => {
                self.candidate = self.running.clone();
            }
            (Mode::Root, ["restore"]) if !switch => {
                let old = self.pending.as_ref().ok_or("No pending commit")?.1.clone();
                self.install(engine, old.clone())?;
                self.candidate = old;
                self.pending = None;
            }
            (Mode::Root, ["save"]) if !switch => {
                if self.pending.is_some() {
                    return Err("Confirm the pending commit first".into());
                }
                self.startup = self.candidate.clone();
                return Ok("Candidate configuration saved.".into());
            }
            (Mode::Root, ["reload"] | ["reboot"]) => {
                self.install(engine, self.startup.clone())?;
                self.pending = None;
                self.candidate = self.startup.clone();
                engine.power_off(self.id).map_err(|e| e.to_string())?;
                engine.power_on(self.id).map_err(|e| e.to_string())?;
                self.sessions.clear();
                *mode = if switch { Mode::User } else { Mode::Root };
                return Ok("Reboot complete.".into());
            }
            (Mode::Root, ["ping", target]) if !switch => {
                let token = engine
                    .ping(self.id, ip(target)?, 64, 2 * SEC)
                    .map_err(|e| e.to_string())?;
                let deadline = engine.now().checked_add(2 * SEC).ok_or("Time overflow")?;
                let report = engine
                    .run_until(deadline, 100_000)
                    .map_err(|e| e.to_string())?;
                if report.faulted || report.budget_exhausted {
                    return Err("Simulation failed".into());
                }
                let status = engine.probe(self.id, token).map(|p| p.status);
                self.expire(engine)?;
                return Ok(if matches!(status, Some(ProbeStatus::Reply { .. })) {
                    "1 packets transmitted, 1 received, 0% packet loss".into()
                } else {
                    "1 packets transmitted, 0 received, 100% packet loss".into()
                });
            }
            (Mode::Global, ["interface", kind, n])
                if *kind == "gigabitethernet" || *kind == "gi" =>
            {
                let mut c = self.candidate.clone();
                if !c.interfaces.contains_key(*n) {
                    if switch {
                        return Err("Unknown interface".into());
                    }
                    let (parent, v) = n.rsplit_once('.').ok_or("Unknown interface")?;
                    let tag = vid(v)?;
                    if v != tag.to_string() {
                        return Err("Use canonical VLAN number".into());
                    }
                    let mut i = c
                        .interfaces
                        .get(parent)
                        .filter(|i| i.parent.is_none())
                        .ok_or("Unknown parent")?
                        .clone();
                    if c.interfaces.len() >= 256 {
                        return Err("Interface limit".into());
                    }
                    if c.interfaces
                        .values()
                        .any(|j| j.port == i.port && j.dot1q == Some(tag))
                    {
                        return Err("Duplicate VLAN subinterface".into());
                    }
                    i.parent = Some(parent.into());
                    i.dot1q = Some(tag);
                    i.ip = None;
                    i.description.clear();
                    i.shutdown = false;
                    c.interfaces.insert((*n).into(), i);
                    self.edit(engine, c)?;
                }
                *mode = Mode::Interface((*n).into());
            }
            (Mode::Global, ["vlan", v]) if switch => {
                let v = vid(v)?;
                let mut c = self.candidate.clone();
                c.vlans.entry(v).or_insert_with(|| format!("VLAN{v}"));
                self.edit(engine, c)?;
                *mode = Mode::Vlan(v);
            }
            _ => {
                let mut c = self.candidate.clone();
                match (&*mode, a) {
                    (Mode::Global, ["hostname", n]) if name_ok(n) => c.hostname = (*n).into(),
                    (Mode::Global, ["no", "vlan", v]) if switch => {
                        let v = vid(v)?;
                        if v == 1 {
                            return Err("Default VLAN cannot be removed".into());
                        }
                        c.vlans.remove(&v);
                    }
                    (Mode::Vlan(v), ["name", n]) if switch && name_ok(n) => {
                        *c.vlans.get_mut(v).ok_or("Unknown VLAN")? = (*n).into();
                    }
                    (Mode::Global, ["ip", "route", net, hop] | ["no", "ip", "route", net, hop])
                        if !switch =>
                    {
                        let (address, len) = cidr(net)?;
                        let prefix = Ipv4Prefix::new(address, len).ok_or("Invalid prefix")?;
                        if prefix.network() != address {
                            return Err("Noncanonical network".into());
                        }
                        let next_hop = ip(hop)?;
                        if !netsim_protocols::routing::unicast(next_hop) {
                            return Err("Invalid next hop".into());
                        }
                        let r = StaticRoute {
                            prefix,
                            next_hop,
                            distance: 1,
                        };
                        if a[0] == "no" {
                            c.routes.retain(|x| *x != r);
                        } else if !c.routes.contains(&r) {
                            if c.routes.len() >= 4096 {
                                return Err("Route limit".into());
                            }
                            c.routes.push(r);
                        }
                    }
                    (Mode::Interface(n), _) => {
                        let i = c.interfaces.get_mut(n).ok_or("Interface missing")?;
                        match a {
                            ["shutdown"] => i.shutdown = true,
                            ["no", "shutdown"] => i.shutdown = false,
                            ["description", tail @ ..] if !tail.is_empty() => {
                                i.description = tail.join(" ")
                            }
                            ["no", "description"] => i.description.clear(),
                            ["ip", "address", value] if !switch => {
                                let (address, prefix_len) = cidr(value)?;
                                if !(InterfaceConfig {
                                    key: InterfaceKey {
                                        port: i.port,
                                        vlan: i.dot1q,
                                    },
                                    address,
                                    prefix_len,
                                    mac: i.mac,
                                })
                                .valid()
                                {
                                    return Err("Invalid interface address".into());
                                }
                                i.ip = Some((address, prefix_len));
                            }
                            ["no", "ip", "address"] if !switch => i.ip = None,
                            ["switchport", "mode", "access"] if switch => i.trunk = false,
                            ["switchport", "mode", "trunk"] if switch => i.trunk = true,
                            ["switchport", "access", "vlan", v] if switch => {
                                let v = vid(v)?;
                                if !c.vlans.contains_key(&v) {
                                    return Err("Create VLAN first".into());
                                }
                                i.access = v;
                            }
                            ["switchport", "trunk", "native", "vlan", v] if switch => {
                                let v = vid(v)?;
                                if !c.vlans.contains_key(&v) {
                                    return Err("Create VLAN first".into());
                                }
                                i.native = v;
                            }
                            ["switchport", "trunk", "allowed", "vlan", "add", values] if switch => {
                                i.allowed
                                    .extend(vlan_list(values).ok_or("Invalid VLAN list")?)
                            }
                            ["switchport", "trunk", "allowed", "vlan", "remove", values]
                                if switch =>
                            {
                                let remove = vlan_list(values).ok_or("Invalid VLAN list")?;
                                i.allowed.retain(|v| !remove.contains(v));
                            }
                            ["switchport", "trunk", "allowed", "vlan", values] if switch => {
                                i.allowed = if *values == "none" {
                                    Default::default()
                                } else if *values == "all" {
                                    (1..=4094).collect()
                                } else {
                                    vlan_list(values).ok_or("Invalid VLAN list")?
                                };
                            }
                            _ => return Err("Unknown or unsupported interface command".into()),
                        }
                    }
                    _ => return Err("Unknown or unsupported command in this mode".into()),
                }
                self.edit(engine, c)?;
            }
        }
        Ok(String::new())
    }
    fn help(&self, mode: &Mode) -> String {
        match mode {
            Mode::User=>"enable | exit",
            Mode::Root if self.model.is_switch()=>"configure terminal | show | write startup-config | reload | exit",
            Mode::Root=>"configure | show | commit | confirm | rollback | restore | save | ping | reboot",
            Mode::Global if self.model.is_switch()=>"hostname | vlan | interface gigabitethernet | exit | end",
            Mode::Global=>"hostname | interface gigabitethernet | ip route | commit | confirm | exit | end",
            Mode::Interface(_) if self.model.is_switch()=>"switchport mode access/trunk | switchport access vlan | switchport trunk native vlan | switchport trunk allowed vlan | shutdown | no shutdown | exit",
            Mode::Interface(_)=>"ip address IPv4/prefix | no ip address | shutdown | no shutdown | exit",
            Mode::Vlan(_)=>"name | exit",
        }.into()
    }
    fn show(&self, engine: &Engine, a: &[&str]) -> Result<String, String> {
        let snap = engine.snapshot();
        let bridge = snap
            .l2
            .switches
            .iter()
            .find(|(id, _)| *id == self.id)
            .map(|(_, b)| b);
        let node = snap.l3.nodes.iter().find(|n| n.device == self.id);
        let name = |p| {
            self.running
                .interfaces
                .iter()
                .find(|(_, i)| i.port == p && i.parent.is_none())
                .map_or("? ", |(n, _)| n.as_str())
        };
        let mut out = String::new();
        match a {
            ["show", "version"] | ["show", "system", "information"] => {
                return Ok(format!(
                    "NetSim Studio educational Eltex {:?} profile; not vendor firmware",
                    self.model
                ));
            }
            ["show", "running-config"] => return Ok(self.running_config()),
            ["show", "startup-config"] => return Ok(self.startup_config()),
            ["show", "candidate-config"] if !self.model.is_switch() => {
                return Ok(self.candidate_config());
            }
            ["show", "interfaces"]
            | ["show", "interfaces", "status"]
            | ["show", "ip", "interface"] => {
                let _ = writeln!(out, "Interface       Address             Admin  Link");
                for (n, i) in &self.running.interfaces {
                    let _ = writeln!(
                        out,
                        "gi{n:<13} {:<19} {:<6} {}",
                        i.ip.map_or("-".into(), |(a, l)| format!("{a}/{l}")),
                        if engine.port_admin_up(i.port) && !i.shutdown {
                            "up"
                        } else {
                            "down"
                        },
                        if engine.port_oper_up(i.port) && !i.shutdown {
                            "up"
                        } else {
                            "down"
                        }
                    );
                }
            }
            ["show", "vlan"] if self.model.is_switch() => {
                let _ = writeln!(out, "VLAN  Name              Tagged / Untagged");
                for (v, n) in &self.running.vlans {
                    let ports = self
                        .running
                        .interfaces
                        .iter()
                        .filter_map(|(p, i)| {
                            if i.trunk && i.allowed.contains(v) {
                                Some(format!("gi{p}({})", if i.native == *v { "U" } else { "T" }))
                            } else if !i.trunk && i.access == *v {
                                Some(format!("gi{p}(U)"))
                            } else {
                                None
                            }
                        })
                        .collect::<Vec<_>>()
                        .join(" ");
                    let _ = writeln!(out, "{v:<5} {n:<17} {ports}");
                }
            }
            ["show", "interfaces", "switchport"] if self.model.is_switch() => {
                for (n, i) in &self.running.interfaces {
                    let _ = writeln!(
                        out,
                        "gi{n} {} access={} native={} allowed={}",
                        if i.trunk { "trunk" } else { "access" },
                        i.access,
                        i.native,
                        list_text(&i.allowed)
                    );
                }
            }
            ["show", "mac-address-table"] if self.model.is_switch() => {
                let _ = writeln!(out, "VLAN MAC               Port");
                for (v, m, p, _) in &bridge.ok_or("No bridge")?.macs {
                    let _ = writeln!(out, "{v} {} gi{}", fmt_mac(*m), name(*p));
                }
            }
            ["show", "spanning-tree"] if self.model.is_switch() => {
                let b = bridge.ok_or("No bridge")?;
                let _ = writeln!(out, "Root {:016x} Bridge {:016x}", b.root.0, b.bridge.0);
                for (p, r, s) in &b.ports {
                    let _ = writeln!(out, "gi{} {:?} {:?}", name(*p), r, s);
                }
            }
            ["show", "ip", "route"] if !self.model.is_switch() => {
                let _ = writeln!(out, "Prefix             Next hop         Interface");
                for r in node
                    .ok_or("No router")?
                    .routes
                    .iter()
                    .filter(|r| engine.port_oper_up(r.interface.port))
                {
                    let _ = writeln!(
                        out,
                        "{}/{} via {} gi{} {:?}",
                        r.prefix.network(),
                        r.prefix.length(),
                        r.next_hop.map_or("connected".into(), |a| a.to_string()),
                        name(r.interface.port),
                        r.origin
                    );
                }
            }
            ["show", "ip", "arp"] | ["show", "arp"] if !self.model.is_switch() => {
                for i in &node.ok_or("No router")?.interfaces {
                    for (a, m, _) in &i.arp {
                        let _ = writeln!(out, "{a} {} gi{}", fmt_mac(*m), name(i.config.key.port));
                    }
                }
            }
            _ => return Err("Unsupported show command".into()),
        }
        Ok(out.trim_end().into())
    }
}
