//! Stable identifiers and shared values. Simulation time is measured in nanoseconds.

pub type SimTime = u64;

macro_rules! identifier {
    ($name:ident) => {
        #[derive(
            Clone,
            Copy,
            Debug,
            PartialEq,
            Eq,
            PartialOrd,
            Ord,
            Hash,
            serde::Serialize,
            serde::Deserialize,
        )]
        pub struct $name(pub u64);
    };
}

identifier!(DeviceId);
identifier!(PortId);
identifier!(LinkId);
identifier!(PacketId);
identifier!(TimerId);
identifier!(SessionId);
identifier!(InterfaceId);

#[derive(
    Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash, serde::Serialize, serde::Deserialize,
)]
pub struct MacAddress(pub [u8; 6]);

impl MacAddress {
    pub const BROADCAST: Self = Self([255; 6]);

    pub fn is_multicast(self) -> bool {
        self.0[0] & 1 != 0
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MediaKind {
    Ethernet,
    Wireless,
    Serial,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PowerState {
    Off,
    On,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct VlanId(u16);

impl VlanId {
    pub fn new(value: u16) -> Option<Self> {
        (1..=4094).contains(&value).then_some(Self(value))
    }

    pub fn get(self) -> u16 {
        self.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vlan_boundaries() {
        assert_eq!(VlanId::new(1).unwrap().get(), 1);
        assert_eq!(VlanId::new(4094).unwrap().get(), 4094);
        assert!(VlanId::new(0).is_none());
        assert!(VlanId::new(4095).is_none());
    }

    #[test]
    fn multicast_bit() {
        assert!(MacAddress::BROADCAST.is_multicast());
        assert!(!MacAddress([2, 0, 0, 0, 0, 1]).is_multicast());
    }
}
