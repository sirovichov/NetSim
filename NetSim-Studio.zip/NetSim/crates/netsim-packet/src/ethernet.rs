//! Ethernet II / 802.3, single 802.1Q tag. Bytes exclude FCS and preamble.
use netsim_types::MacAddress;

pub const ARP: u16 = 0x0806;
pub const IPV4: u16 = 0x0800;
pub const DOT1Q: u16 = 0x8100;
pub const STP_MAC: MacAddress = MacAddress([1, 128, 194, 0, 0, 0]);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FrameError {
    Truncated,
    Invalid,
    TooLong,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Tag {
    pub vid: u16,
    pub pcp: u8,
    pub dei: bool,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct EthernetFrame {
    pub dst: MacAddress,
    pub src: MacAddress,
    pub tag: Option<Tag>,
    /// EtherType >= 1536, or IEEE 802.3 payload length <= 1500.
    pub kind: u16,
    pub payload: Vec<u8>,
}

impl EthernetFrame {
    pub fn encode(&self) -> Result<Vec<u8>, FrameError> {
        if self.payload.len() > 1500 {
            return Err(FrameError::TooLong);
        }
        if self.src.is_multicast()
            || self.src.0 == [0; 6]
            || self.kind == DOT1Q
            || self.kind == 0x88a8
            || (self.kind > 1500 && self.kind < 1536)
            || (self.kind <= 1500 && usize::from(self.kind) != self.payload.len())
        {
            return Err(FrameError::Invalid);
        }
        let mut out = Vec::with_capacity(18 + self.payload.len());
        out.extend_from_slice(&self.dst.0);
        out.extend_from_slice(&self.src.0);
        if let Some(tag) = self.tag {
            if tag.vid > 4094 || tag.pcp > 7 {
                return Err(FrameError::Invalid);
            }
            out.extend_from_slice(&DOT1Q.to_be_bytes());
            let tci = (u16::from(tag.pcp) << 13) | (u16::from(tag.dei) << 12) | tag.vid;
            out.extend_from_slice(&tci.to_be_bytes());
        }
        out.extend_from_slice(&self.kind.to_be_bytes());
        out.extend_from_slice(&self.payload);
        Ok(out)
    }

    pub fn decode(bytes: &[u8]) -> Result<Self, FrameError> {
        if bytes.len() < 14 {
            return Err(FrameError::Truncated);
        }
        let dst = MacAddress(bytes[0..6].try_into().map_err(|_| FrameError::Truncated)?);
        let src = MacAddress(bytes[6..12].try_into().map_err(|_| FrameError::Truncated)?);
        let mut kind = u16::from_be_bytes([bytes[12], bytes[13]]);
        let mut offset = 14;
        let mut tag = None;
        if kind == DOT1Q {
            if bytes.len() < 18 {
                return Err(FrameError::Truncated);
            }
            let tci = u16::from_be_bytes([bytes[14], bytes[15]]);
            tag = Some(Tag {
                vid: tci & 4095,
                pcp: (tci >> 13) as u8,
                dei: tci & 4096 != 0,
            });
            kind = u16::from_be_bytes([bytes[16], bytes[17]]);
            offset = 18;
        }
        let payload = &bytes[offset..];
        if payload.len() > 1500 {
            return Err(FrameError::TooLong);
        }
        let payload = if kind <= 1500 {
            payload
                .get(..usize::from(kind))
                .ok_or(FrameError::Truncated)?
        } else {
            payload
        };
        let frame = Self {
            dst,
            src,
            tag,
            kind,
            payload: payload.to_vec(),
        };
        frame.encode()?;
        Ok(frame)
    }

    /// Wire size for link timing, including FCS, minimum frame padding, preamble/SFD and IFG.
    pub fn wire_bytes(encoded_len: usize) -> u64 {
        (encoded_len as u64 + 4).max(64) + 20
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn dot1q_roundtrip() {
        let frame = EthernetFrame {
            dst: MacAddress::BROADCAST,
            src: MacAddress([2, 0, 0, 0, 0, 1]),
            tag: Some(Tag {
                vid: 100,
                pcp: 5,
                dei: true,
            }),
            kind: ARP,
            payload: vec![1, 2, 3],
        };
        let bytes = frame.encode().unwrap();
        assert_eq!(&bytes[12..18], &[0x81, 0, 0xb0, 0x64, 8, 6]);
        assert_eq!(EthernetFrame::decode(&bytes), Ok(frame));
        assert_eq!(EthernetFrame::wire_bytes(14), 84);
    }

    #[test]
    fn malformed_frames_rejected() {
        assert_eq!(EthernetFrame::decode(&[0; 13]), Err(FrameError::Truncated));
        let mut bytes = vec![0; 14];
        bytes[6] = 2;
        bytes[12] = 0x81;
        assert_eq!(EthernetFrame::decode(&bytes), Err(FrameError::Truncated));
    }
}
