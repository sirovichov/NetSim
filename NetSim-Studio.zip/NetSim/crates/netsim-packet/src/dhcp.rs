//! Bounded DHCPv4 BOOTP/UDP codec for the teaching DORA subset.
use crate::ethernet::EthernetFrame;
use crate::ipv4::{IPV4, Ipv4Packet};
use netsim_types::MacAddress;
use std::net::Ipv4Addr;
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Kind {
    Discover = 1,
    Offer = 2,
    Request = 3,
    Ack = 5,
    Nak = 6,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Message {
    pub kind: Kind,
    pub xid: u32,
    pub mac: MacAddress,
    pub offered: Ipv4Addr,
    pub server: Ipv4Addr,
    pub requested: Ipv4Addr,
    pub prefix: u8,
    pub gateway: Option<Ipv4Addr>,
    pub lease: u32,
}
impl Message {
    pub fn frame(self, src_mac: MacAddress) -> Option<EthernetFrame> {
        if self.prefix > 32 {
            return None;
        }
        let reply = matches!(self.kind, Kind::Offer | Kind::Ack | Kind::Nak);
        let mut b = vec![0; 240];
        b[0] = if reply { 2 } else { 1 };
        b[1] = 1;
        b[2] = 6;
        b[4..8].copy_from_slice(&self.xid.to_be_bytes());
        b[10] = 128;
        b[16..20].copy_from_slice(&self.offered.octets());
        b[28..34].copy_from_slice(&self.mac.0);
        b[236..240].copy_from_slice(&[99, 130, 83, 99]);
        b.extend([53, 1, self.kind as u8]);
        if !self.server.is_unspecified() {
            b.extend([54, 4]);
            b.extend(self.server.octets());
        }
        if !self.requested.is_unspecified() {
            b.extend([50, 4]);
            b.extend(self.requested.octets());
        }
        if reply && self.kind != Kind::Nak {
            let mask = if self.prefix == 0 {
                0
            } else {
                u32::MAX << (32 - self.prefix)
            };
            b.extend([1, 4]);
            b.extend(mask.to_be_bytes());
            b.extend([51, 4]);
            b.extend(self.lease.to_be_bytes());
            if let Some(g) = self.gateway {
                b.extend([3, 4]);
                b.extend(g.octets());
            }
        }
        b.push(255);
        b.resize(b.len().max(300), 0);
        let (sp, dp): (u16, u16) = if reply { (67, 68) } else { (68, 67) };
        let mut udp = Vec::new();
        udp.extend(sp.to_be_bytes());
        udp.extend(dp.to_be_bytes());
        udp.extend(((b.len() + 8) as u16).to_be_bytes());
        udp.extend([0, 0]);
        udp.extend(b);
        let packet = Ipv4Packet {
            src: if reply {
                self.server
            } else {
                Ipv4Addr::UNSPECIFIED
            },
            dst: Ipv4Addr::BROADCAST,
            ttl: 64,
            protocol: 17,
            identification: 0,
            dscp_ecn: 0,
            dont_fragment: true,
            payload: udp,
        };
        Some(EthernetFrame {
            dst: MacAddress::BROADCAST,
            src: src_mac,
            tag: None,
            kind: IPV4,
            payload: packet.encode().ok()?,
        })
    }
    pub fn decode(frame: &EthernetFrame) -> Option<Self> {
        if frame.kind != IPV4 || frame.tag.is_some() || frame.dst != MacAddress::BROADCAST {
            return None;
        }
        let p = Ipv4Packet::decode(&frame.payload).ok()?;
        let u = &p.payload;
        if p.protocol != 17 || p.dst != Ipv4Addr::BROADCAST || u.len() < 248 {
            return None;
        }
        let ports = (
            u16::from_be_bytes([u[0], u[1]]),
            u16::from_be_bytes([u[2], u[3]]),
        );
        let len = usize::from(u16::from_be_bytes([u[4], u[5]]));
        if len != u.len() {
            return None;
        }
        let b = &u[8..];
        if b[1] != 1 || b[2] != 6 || b[236..240] != [99, 130, 83, 99] {
            return None;
        }
        let mut m = Self {
            kind: Kind::Discover,
            xid: u32::from_be_bytes(b[4..8].try_into().ok()?),
            mac: MacAddress(b[28..34].try_into().ok()?),
            offered: Ipv4Addr::from(<[u8; 4]>::try_from(&b[16..20]).ok()?),
            server: Ipv4Addr::UNSPECIFIED,
            requested: Ipv4Addr::UNSPECIFIED,
            prefix: 0,
            gateway: None,
            lease: 0,
        };
        let mut i = 240;
        let mut found = false;
        let mut end = false;
        while i < b.len() {
            let t = b[i];
            i += 1;
            if t == 255 {
                end = true;
                break;
            }
            if t == 0 {
                continue;
            }
            let n = usize::from(*b.get(i)?);
            i += 1;
            let v = b.get(i..i + n)?;
            i += n;
            match (t, n) {
                (53, 1) => {
                    if found {
                        return None;
                    }
                    found = true;
                    m.kind = match v[0] {
                        1 => Kind::Discover,
                        2 => Kind::Offer,
                        3 => Kind::Request,
                        5 => Kind::Ack,
                        6 => Kind::Nak,
                        _ => return None,
                    };
                }
                (54, 4) => m.server = Ipv4Addr::from(<[u8; 4]>::try_from(v).ok()?),
                (50, 4) => m.requested = Ipv4Addr::from(<[u8; 4]>::try_from(v).ok()?),
                (1, 4) => {
                    let mask = u32::from_be_bytes(v.try_into().ok()?);
                    let n = mask.count_ones();
                    if mask != (if n == 0 { 0 } else { u32::MAX << (32 - n) }) {
                        return None;
                    }
                    m.prefix = n as u8;
                }
                (3, 4) => m.gateway = Some(Ipv4Addr::from(<[u8; 4]>::try_from(v).ok()?)),
                (51, 4) => m.lease = u32::from_be_bytes(v.try_into().ok()?),
                _ => {}
            }
        }
        if !found || !end {
            return None;
        }
        let reply = matches!(m.kind, Kind::Offer | Kind::Ack | Kind::Nak);
        if (reply && (ports != (67, 68) || b[0] != 2 || m.server != p.src))
            || (!reply && (ports != (68, 67) || b[0] != 1 || m.mac != frame.src))
        {
            return None;
        }
        Some(m)
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn discover_roundtrip() {
        let m = Message {
            kind: Kind::Discover,
            xid: 123,
            mac: MacAddress([2, 0, 1, 2, 3, 4]),
            offered: Ipv4Addr::UNSPECIFIED,
            server: Ipv4Addr::UNSPECIFIED,
            requested: Ipv4Addr::UNSPECIFIED,
            prefix: 0,
            gateway: None,
            lease: 0,
        };
        assert_eq!(Message::decode(&m.frame(m.mac).unwrap()), Some(m));
    }
}
