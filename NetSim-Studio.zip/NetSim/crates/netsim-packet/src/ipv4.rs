//! IPv4 (no options/fragmentation) and ICMPv4 wire codecs.
use std::net::Ipv4Addr;

pub const IPV4: u16 = 0x0800;
pub const ICMP: u8 = 1;
pub const MTU: usize = 1500;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum IpError {
    Truncated,
    Invalid,
    Checksum,
    Unsupported,
    TooLong,
}

/// Internet one's-complement checksum, including an odd trailing byte.
pub fn checksum(bytes: &[u8]) -> u16 {
    let mut sum = 0u32;
    for pair in bytes.chunks(2) {
        sum += u32::from(u16::from_be_bytes([pair[0], *pair.get(1).unwrap_or(&0)]));
        sum = (sum & 0xffff) + (sum >> 16);
    }
    !(sum as u16)
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Ipv4Packet {
    pub src: Ipv4Addr,
    pub dst: Ipv4Addr,
    pub ttl: u8,
    pub protocol: u8,
    pub identification: u16,
    pub dscp_ecn: u8,
    pub dont_fragment: bool,
    pub payload: Vec<u8>,
}

impl Ipv4Packet {
    pub fn encode(&self) -> Result<Vec<u8>, IpError> {
        if self.payload.len() > MTU - 20 {
            return Err(IpError::TooLong);
        }
        let len = (20 + self.payload.len()) as u16;
        let mut bytes = vec![0x45, self.dscp_ecn];
        bytes.extend_from_slice(&len.to_be_bytes());
        bytes.extend_from_slice(&self.identification.to_be_bytes());
        bytes.extend_from_slice(&(if self.dont_fragment { 0x4000u16 } else { 0 }).to_be_bytes());
        bytes.extend_from_slice(&[self.ttl, self.protocol, 0, 0]);
        bytes.extend_from_slice(&self.src.octets());
        bytes.extend_from_slice(&self.dst.octets());
        let sum = checksum(&bytes);
        bytes[10..12].copy_from_slice(&sum.to_be_bytes());
        bytes.extend_from_slice(&self.payload);
        Ok(bytes)
    }

    pub fn decode(bytes: &[u8]) -> Result<Self, IpError> {
        if bytes.len() < 20 {
            return Err(IpError::Truncated);
        }
        if bytes[0] >> 4 != 4 {
            return Err(IpError::Invalid);
        }
        if bytes[0] & 15 != 5 {
            return Err(IpError::Unsupported);
        }
        let len = usize::from(u16::from_be_bytes([bytes[2], bytes[3]]));
        if len < 20 {
            return Err(IpError::Invalid);
        }
        if len > MTU {
            return Err(IpError::TooLong);
        }
        if len > bytes.len() {
            return Err(IpError::Truncated);
        }
        if checksum(&bytes[..20]) != 0 {
            return Err(IpError::Checksum);
        }
        let flags = u16::from_be_bytes([bytes[6], bytes[7]]);
        if flags & 0xbfff != 0 {
            return Err(IpError::Unsupported);
        }
        Ok(Self {
            src: Ipv4Addr::new(bytes[12], bytes[13], bytes[14], bytes[15]),
            dst: Ipv4Addr::new(bytes[16], bytes[17], bytes[18], bytes[19]),
            ttl: bytes[8],
            protocol: bytes[9],
            identification: u16::from_be_bytes([bytes[4], bytes[5]]),
            dscp_ecn: bytes[1],
            dont_fragment: flags & 0x4000 != 0,
            payload: bytes[20..len].to_vec(),
        })
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum IcmpMessage {
    Echo {
        reply: bool,
        token: u32,
        data: Vec<u8>,
    },
    Unreachable {
        code: u8,
        quote: Vec<u8>,
    },
    TimeExceeded {
        code: u8,
        quote: Vec<u8>,
    },
}

impl IcmpMessage {
    pub fn encode(&self) -> Vec<u8> {
        let (kind, code, word, data) = match self {
            Self::Echo { reply, token, data } => (if *reply { 0 } else { 8 }, 0, *token, data),
            Self::Unreachable { code, quote } => (3, *code, 0, quote),
            Self::TimeExceeded { code, quote } => (11, *code, 0, quote),
        };
        let mut out = vec![kind, code, 0, 0];
        out.extend_from_slice(&word.to_be_bytes());
        out.extend_from_slice(data);
        let sum = checksum(&out);
        out[2..4].copy_from_slice(&sum.to_be_bytes());
        out
    }

    pub fn decode(bytes: &[u8]) -> Result<Self, IpError> {
        if bytes.len() < 8 {
            return Err(IpError::Truncated);
        }
        if checksum(bytes) != 0 {
            return Err(IpError::Checksum);
        }
        let data = bytes[8..].to_vec();
        match (bytes[0], bytes[1]) {
            (kind @ (0 | 8), 0) => Ok(Self::Echo {
                reply: kind == 0,
                token: u32::from_be_bytes(bytes[4..8].try_into().map_err(|_| IpError::Truncated)?),
                data,
            }),
            (3, code) => Ok(Self::Unreachable { code, quote: data }),
            (11, code) => Ok(Self::TimeExceeded { code, quote: data }),
            _ => Err(IpError::Unsupported),
        }
    }
}

/// ICMP error quotes the original IPv4 header plus at least eight payload bytes.
pub fn quote(packet: &Ipv4Packet) -> Vec<u8> {
    packet
        .encode()
        .map(|mut bytes| {
            bytes.truncate(28);
            bytes
        })
        .unwrap_or_default()
}

/// Match a quoted echo request without requiring the full original IP payload.
pub fn quoted_echo(bytes: &[u8]) -> Option<(Ipv4Addr, Ipv4Addr, u32)> {
    if bytes.len() < 28
        || bytes[0] != 0x45
        || bytes[9] != ICMP
        || bytes[20..22] != [8, 0]
        || checksum(&bytes[..20]) != 0
    {
        return None;
    }
    Some((
        Ipv4Addr::new(bytes[12], bytes[13], bytes[14], bytes[15]),
        Ipv4Addr::new(bytes[16], bytes[17], bytes[18], bytes[19]),
        u32::from_be_bytes(bytes[24..28].try_into().ok()?),
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn packet() -> Ipv4Packet {
        Ipv4Packet {
            src: Ipv4Addr::new(10, 0, 0, 1),
            dst: Ipv4Addr::new(10, 1, 0, 2),
            ttl: 64,
            protocol: ICMP,
            identification: 5,
            dscp_ecn: 0,
            dont_fragment: true,
            payload: IcmpMessage::Echo {
                reply: false,
                token: 123,
                data: vec![1, 2, 3],
            }
            .encode(),
        }
    }

    #[test]
    fn ipv4_and_icmp_roundtrip() {
        let p = packet();
        let bytes = p.encode().unwrap();
        assert_eq!(checksum(&bytes[..20]), 0);
        assert_eq!(Ipv4Packet::decode(&bytes), Ok(p.clone()));
        assert_eq!(
            IcmpMessage::decode(&p.payload),
            Ok(IcmpMessage::Echo {
                reply: false,
                token: 123,
                data: vec![1, 2, 3],
            })
        );
        assert_eq!(quoted_echo(&quote(&p)), Some((p.src, p.dst, 123)));
    }

    #[test]
    fn malformed_packets() {
        let mut bytes = packet().encode().unwrap();
        assert_eq!(Ipv4Packet::decode(&bytes[..19]), Err(IpError::Truncated));
        bytes[8] ^= 1;
        assert_eq!(Ipv4Packet::decode(&bytes), Err(IpError::Checksum));
        assert_eq!(
            IcmpMessage::decode(&[8, 0, 0, 0, 0, 0, 0, 0]),
            Err(IpError::Checksum)
        );
    }
}
