//! Immutable shared packet bytes and Ethernet codecs.
pub mod ethernet;
pub mod ipv4;

use netsim_types::PacketId;
use std::sync::Arc;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Packet {
    pub id: PacketId,
    pub parent_id: Option<PacketId>,
    pub bytes: Arc<[u8]>,
}

impl Packet {
    pub fn new(id: PacketId, bytes: impl Into<Arc<[u8]>>) -> Self {
        Self {
            id,
            parent_id: None,
            bytes: bytes.into(),
        }
    }

    pub fn derived(&self, id: PacketId, bytes: impl Into<Arc<[u8]>>) -> Self {
        Self {
            id,
            parent_id: Some(self.id),
            bytes: bytes.into(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn immutable_clone_and_lineage() {
        let packet = Packet::new(PacketId(1), vec![1, 2, 3]);
        let clone = packet.clone();
        assert!(Arc::ptr_eq(&packet.bytes, &clone.bytes));
        let next = packet.derived(PacketId(2), vec![4]);
        assert_eq!(next.parent_id, Some(PacketId(1)));
        assert_eq!(&*packet.bytes, &[1, 2, 3]);
    }
}

pub mod dhcp;
