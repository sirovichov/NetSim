//! Versioned project data, bounded decoding and atomic same-directory saves.
use serde::{Deserialize, Serialize};
use std::{
    fs,
    io::{Read, Write},
    net::Ipv4Addr,
    path::Path,
};
pub const PROJECT_FORMAT: &str = "netsim-studio";
pub const PROJECT_SCHEMA_VERSION: u32 = 3;
pub const MAX_PROJECT_BYTES: u64 = 32 * 1024 * 1024;
pub fn supports_schema(version: u32) -> bool {
    version == PROJECT_SCHEMA_VERSION
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum Model {
    CiscoSwitch,
    CiscoRouter,
    EltexSwitch,
    EltexRouter,
    Pc,
    Laptop,
    Server,
    Wep2ac,
    Wep2acSmart,
}
impl Model {
    pub const ALL: [Self; 9] = [
        Self::CiscoSwitch,
        Self::CiscoRouter,
        Self::EltexSwitch,
        Self::EltexRouter,
        Self::Pc,
        Self::Laptop,
        Self::Server,
        Self::Wep2ac,
        Self::Wep2acSmart,
    ];
    pub fn label(self) -> &'static str {
        match self {
            Self::CiscoSwitch => "Cisco Catalyst 2960",
            Self::CiscoRouter => "Cisco ISR 2911",
            Self::EltexSwitch => "Eltex MES2428",
            Self::EltexRouter => "Eltex ESR-100",
            Self::Pc => "PC",
            Self::Laptop => "Laptop",
            Self::Server => "Server",
            Self::Wep2ac => "Eltex WEP-2ac",
            Self::Wep2acSmart => "Eltex WEP-2ac Smart",
        }
    }
    pub fn ap(self) -> bool {
        matches!(self, Self::Wep2ac | Self::Wep2acSmart)
    }
    pub fn host(self) -> bool {
        matches!(self, Self::Pc | Self::Laptop | Self::Server)
    }
    pub fn profile(self) -> &'static str {
        match self {
            Self::CiscoSwitch => "cisco.switch.2960",
            Self::CiscoRouter => "cisco.router.2911",
            Self::EltexSwitch => "eltex.switch.mes2428",
            Self::EltexRouter => "eltex.router.esr100",
            Self::Pc => "generic.host.pc",
            Self::Laptop => "generic.host.laptop",
            Self::Server => "generic.host.server",
            Self::Wep2ac => "eltex.ap.wep2ac",
            Self::Wep2acSmart => "eltex.ap.wep2ac-smart",
        }
    }
}
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct HostConfig {
    pub ip: Ipv4Addr,
    pub prefix: u8,
    pub gateway: Option<Ipv4Addr>,
}
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Node {
    pub id: u64,
    pub model: Model,
    pub hostname: String,
    pub position: [f32; 2],
    pub powered: bool,
    pub host: Option<HostConfig>,
    pub vendor: Option<serde_json::Value>,
}
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Endpoint {
    pub node: u64,
    pub port: String,
}
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Cable {
    pub ends: [Endpoint; 2],
}
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Project {
    pub format: String,
    pub schema_version: u32,
    pub seed: u64,
    pub nodes: Vec<Node>,
    pub cables: Vec<Cable>,
    #[serde(default)]
    pub wireless: WirelessSettings,
    #[serde(default)]
    pub services: Services,
}
impl Project {
    pub fn new(seed: u64) -> Self {
        Self {
            format: PROJECT_FORMAT.into(),
            schema_version: PROJECT_SCHEMA_VERSION,
            seed,
            nodes: vec![],
            cables: vec![],
            wireless: WirelessSettings::default(),
            services: Services::default(),
        }
    }
    pub fn validate(&self) -> Result<(), String> {
        use std::collections::{BTreeMap, BTreeSet};
        if self.format != PROJECT_FORMAT || !supports_schema(self.schema_version) {
            return Err("Unsupported project format/version".into());
        }
        if self.nodes.len() > 1000 || self.cables.len() > 5000 {
            return Err("Project limit exceeded".into());
        }
        let mut ids = BTreeMap::new();
        for n in &self.nodes {
            if n.id == 0
                || n.id == u64::MAX
                || ids.insert(n.id, n.model).is_some()
                || n.hostname.is_empty()
                || n.hostname.len() > 63
                || !n
                    .hostname
                    .bytes()
                    .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
                || n.position
                    .iter()
                    .any(|v| !v.is_finite() || v.abs() > 1_000_000.0)
                || (n.model.host() && n.vendor.is_some())
                || (!n.model.host() && n.host.is_some())
                || n.host.as_ref().is_some_and(|h| h.prefix > 32)
            {
                return Err(format!("Invalid project node {}", n.id));
            }
        }
        let mut used = BTreeSet::new();
        for c in &self.cables {
            if c.ends[0].node == c.ends[1].node {
                return Err("Self-link not supported".into());
            }
            for e in &c.ends {
                if !ids.contains_key(&e.node)
                    || e.port.is_empty()
                    || e.port.len() > 64
                    || !used.insert(e)
                {
                    return Err(format!(
                        "Invalid or busy cable endpoint on node {}, port {:?}",
                        e.node, e.port
                    ));
                }
            }
        }
        self.wireless.validate(&ids)?;
        self.services.validate(&ids)?;
        if self.nodes.iter().any(|n| {
            (n.model.ap() && (!self.wireless.aps.contains_key(&n.id) || n.vendor.is_some()))
                || (self.services.dhcp_clients.contains(&n.id) && n.host.is_some())
                || (self.services.dhcp_servers.contains_key(&n.id) && n.host.is_none())
        }) || self
            .cables
            .iter()
            .flat_map(|c| &c.ends)
            .any(|e| self.wireless.clients.contains_key(&e.node))
        {
            return Err("Inconsistent wireless or DHCP configuration".into());
        }
        Ok(())
    }
    pub fn decode(bytes: &[u8]) -> Result<Self, String> {
        if bytes.len() as u64 > MAX_PROJECT_BYTES {
            return Err("Project too large".into());
        }
        let v: serde_json::Value = serde_json::from_slice(bytes).map_err(|e| e.to_string())?;
        // The previous version only shipped an empty template. Migrate that template, not arbitrary v1 configs.
        if v.get("format").and_then(|v| v.as_str()) == Some(PROJECT_FORMAT)
            && v.get("schema_version").and_then(|v| v.as_u64()) == Some(1)
            && ["devices", "links", "configurations"].iter().all(|k| {
                v.get(*k)
                    .and_then(|v| v.as_array())
                    .is_some_and(Vec::is_empty)
            })
        {
            return Ok(Self::new(
                v.get("seed")
                    .and_then(|v| v.as_u64())
                    .ok_or("Missing seed")?,
            ));
        }
        let mut p: Self = serde_json::from_value(v).map_err(|e| e.to_string())?;
        if p.schema_version == 2 {
            p.schema_version = 3;
        }
        p.validate()?;
        Ok(p)
    }
    pub fn encode(&self) -> Result<Vec<u8>, String> {
        self.validate()?;
        let bytes = serde_json::to_vec_pretty(self).map_err(|e| e.to_string())?;
        if bytes.len() as u64 > MAX_PROJECT_BYTES {
            return Err("Project too large".into());
        }
        Ok(bytes)
    }
}
mod wireless;
pub use wireless::*;
pub fn load(path: &Path) -> Result<Project, String> {
    let f = fs::File::open(path).map_err(|e| e.to_string())?;
    let mut bytes = Vec::new();
    f.take(MAX_PROJECT_BYTES + 1)
        .read_to_end(&mut bytes)
        .map_err(|e| e.to_string())?;
    Project::decode(&bytes)
}
/// Temp file is exclusive and on the same volume. On failed rename the existing file is untouched.
pub fn save(path: &Path, p: &Project) -> Result<(), String> {
    let bytes = p.encode()?;
    let mut tmp = path.as_os_str().to_os_string();
    tmp.push(format!(".{}.tmp", std::process::id()));
    let tmp = std::path::PathBuf::from(tmp);
    let mut file = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&tmp)
        .map_err(|e| e.to_string())?;
    let result = file.write_all(&bytes).and_then(|()| file.sync_all());
    drop(file);
    let result = result.and_then(|()| fs::rename(&tmp, path));
    if result.is_err() {
        let _ = fs::remove_file(&tmp);
    }
    result.map_err(|e| e.to_string())
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn project_roundtrip() {
        let p = Project::new(42);
        assert_eq!(p, Project::decode(&p.encode().unwrap()).unwrap());
    }
    #[test]
    fn rejects_unknown_version() {
        let mut p = Project::new(0);
        p.schema_version = 99;
        assert!(p.encode().is_err());
    }
    #[test]
    fn old_empty_template() {
        let p = Project::decode(include_bytes!("../../../examples/empty.netsim")).unwrap();
        assert_eq!(p.seed, 42);
    }
    #[test]
    fn rejects_invalid_endpoint() {
        let mut p = Project::new(0);
        p.cables.push(Cable {
            ends: [
                Endpoint {
                    node: 1,
                    port: "eth0".into(),
                },
                Endpoint {
                    node: 2,
                    port: "eth0".into(),
                },
            ],
        });
        assert!(p.validate().is_err());
    }
}
