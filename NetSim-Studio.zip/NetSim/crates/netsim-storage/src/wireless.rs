use super::*;
use std::collections::{BTreeMap, BTreeSet};

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Radio {
    pub enabled: bool,
    pub channel: u8,
}
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Vap {
    pub radio: u8,
    pub index: u8,
    pub enabled: bool,
    pub ssid: String,
    pub broadcast: bool,
    pub vlan: u16,
    pub psk: Option<String>,
}
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ApConfig {
    pub radios: [Radio; 2],
    pub vaps: Vec<Vap>,
    pub native_vlan: u16,
}
impl Default for ApConfig {
    fn default() -> Self {
        Self {
            radios: [
                Radio {
                    enabled: true,
                    channel: 36,
                },
                Radio {
                    enabled: true,
                    channel: 1,
                },
            ],
            vaps: vec![Vap {
                radio: 2,
                index: 0,
                enabled: true,
                ssid: "NetSim".into(),
                broadcast: true,
                vlan: 1,
                psk: None,
            }],
            native_vlan: 1,
        }
    }
}
impl ApConfig {
    pub fn validate(&self) -> Result<(), String> {
        let vlan = |v| (1..=4094).contains(&v);
        let mut slots = BTreeSet::new();
        if !vlan(self.native_vlan)
            || ![
                36, 40, 44, 48, 52, 56, 60, 64, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136,
                140, 144, 149, 153, 157, 161, 165,
            ]
            .contains(&self.radios[0].channel)
            || !(1..=13).contains(&self.radios[1].channel)
            || self.vaps.len() > 32
        {
            return Err("Invalid radio configuration".into());
        }
        for v in &self.vaps {
            if !(1..=2).contains(&v.radio)
                || v.index >= 16
                || !slots.insert((v.radio, v.index))
                || v.ssid.is_empty()
                || v.ssid.len() > 32
                || v.ssid.chars().any(char::is_control)
                || !vlan(v.vlan)
                || v.psk.as_ref().is_some_and(|s| {
                    !(8..=63).contains(&s.len()) || !s.is_ascii() || s.chars().any(char::is_control)
                })
            {
                return Err("Invalid VAP".into());
            }
        }
        Ok(())
    }
}
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct WifiClient {
    pub ssid: String,
    pub psk: Option<String>,
    pub radio: u8,
}
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct WirelessSettings {
    pub aps: BTreeMap<u64, ApConfig>,
    pub clients: BTreeMap<u64, WifiClient>,
}
impl WirelessSettings {
    pub(super) fn validate(&self, ids: &BTreeMap<u64, Model>) -> Result<(), String> {
        for (id, ap) in &self.aps {
            if !ids.get(id).is_some_and(|m| m.ap()) {
                return Err("Invalid AP".into());
            }
            ap.validate()?;
        }
        for (id, c) in &self.clients {
            if ids.get(id) != Some(&Model::Laptop)
                || !(1..=2).contains(&c.radio)
                || c.ssid.is_empty()
                || c.ssid.len() > 32
                || c.psk
                    .as_ref()
                    .is_some_and(|s| !(8..=63).contains(&s.len()) || !s.is_ascii())
            {
                return Err("Invalid Wi-Fi client".into());
            }
        }
        Ok(())
    }
}
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DhcpPool {
    pub first: Ipv4Addr,
    pub last: Ipv4Addr,
    pub prefix: u8,
    pub gateway: Option<Ipv4Addr>,
    pub lease_secs: u32,
}
impl DhcpPool {
    pub fn valid(&self) -> bool {
        let a = u32::from(self.first);
        let b = u32::from(self.last);
        if !(1..=30).contains(&self.prefix)
            || a > b
            || b - a >= 256
            || self.lease_secs < 60
            || self.lease_secs > 86400
        {
            return false;
        }
        let mask = u32::MAX << (32 - self.prefix);
        let net = a & mask;
        let broadcast = net | !mask;
        a > net
            && b < broadcast
            && (b & mask) == net
            && !self.first.is_multicast()
            && !self.first.is_loopback()
            && self.first.octets()[0] != 0
            && self.first.octets()[0] < 224
            && self.gateway.is_none_or(|g| {
                let g = u32::from(g);
                g > net && g < broadcast && (g < a || g > b)
            })
    }
}
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Services {
    pub dhcp_servers: BTreeMap<u64, DhcpPool>,
    pub dhcp_clients: BTreeSet<u64>,
    pub ospf: BTreeMap<u64, Ipv4Addr>,
}
impl Services {
    pub(super) fn validate(&self, ids: &BTreeMap<u64, Model>) -> Result<(), String> {
        for (id, p) in &self.dhcp_servers {
            if ids.get(id) != Some(&Model::Server) || !p.valid() {
                return Err("Invalid DHCP server pool".into());
            }
        }
        for id in &self.dhcp_clients {
            if !ids.get(id).is_some_and(|m| m.host()) || self.dhcp_servers.contains_key(id) {
                return Err("Invalid DHCP client".into());
            }
        }
        let mut rids = BTreeSet::new();
        for (id, r) in &self.ospf {
            if !matches!(ids.get(id), Some(Model::CiscoRouter | Model::EltexRouter))
                || r.is_unspecified()
                || r.is_multicast()
                || !rids.insert(*r)
            {
                return Err("Invalid OSPF router ID".into());
            }
        }
        Ok(())
    }
}
