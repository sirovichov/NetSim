//! Declarative lab catalog and typed grading results.
use std::net::Ipv4Addr;
pub const LAB_SCHEMA_VERSION: u32 = 1;
#[derive(Clone, Debug)]
pub enum Check {
    Ping {
        source: u64,
        destination: Ipv4Addr,
        reachable: bool,
    },
    Address {
        node: u64,
        ip: Ipv4Addr,
    },
    Learned {
        node: u64,
        vlan: u16,
    },
    Tagged {
        a: u64,
        b: u64,
        vlan: u16,
    },
    Arp {
        node: u64,
        ip: Ipv4Addr,
    },
    Tree {
        nodes: Vec<u64>,
    },
    Dhcp {
        node: u64,
    },
    Ospf {
        node: u64,
        network: Ipv4Addr,
    },
    Wifi {
        node: u64,
    },
}
#[derive(Clone, Debug)]
pub struct Grade {
    pub label: String,
    pub passed: bool,
    pub points: u32,
}
pub const CATALOG: [(&str, &str); 13] = [
    ("LAB-001", "Connect two PCs"),
    ("LAB-002", "ARP and ICMP"),
    ("LAB-003", "Cisco switch"),
    ("LAB-004", "Cisco router"),
    ("LAB-005", "Static routing"),
    ("LAB-006", "VLAN and trunk"),
    ("LAB-007", "STP"),
    ("LAB-008", "DHCP"),
    ("LAB-009", "OSPF"),
    ("LAB-010", "Eltex MES"),
    ("LAB-011", "Eltex ESR"),
    ("LAB-012", "Eltex WEP"),
    ("LAB-013", "Mixed Cisco/Eltex"),
];
