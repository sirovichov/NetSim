use eframe::egui::{self, Color32, Pos2, Rect, Stroke, StrokeKind, Vec2};
use netsim_storage::Model;

pub const CANVAS: Color32 = Color32::from_rgb(15, 22, 33);
pub const PANEL: Color32 = Color32::from_rgb(23, 32, 45);
pub const CARD: Color32 = Color32::from_rgb(32, 44, 60);
pub const BORDER: Color32 = Color32::from_rgb(54, 71, 91);
pub const MINT: Color32 = Color32::from_rgb(109, 228, 195);
pub const MUTED: Color32 = Color32::from_rgb(164, 182, 202);
pub const OFF: Color32 = Color32::from_rgb(246, 146, 132);

pub fn apply(ctx: &egui::Context) {
    ctx.set_visuals(egui::Visuals::dark());
    ctx.style_mut(|s| {
        s.spacing.item_spacing = Vec2::new(7., 6.);
        s.spacing.button_padding = Vec2::new(10., 5.);
        s.spacing.interact_size.y = 24.;
        s.spacing.window_margin = egui::Margin::same(12);
        let v = &mut s.visuals;
        v.panel_fill = PANEL;
        v.window_fill = PANEL;
        v.extreme_bg_color = CANVAS;
        v.widgets.noninteractive.bg_stroke = Stroke::new(1., BORDER);
        v.widgets.noninteractive.fg_stroke.color = Color32::from_rgb(223, 232, 243);
        v.widgets.inactive.weak_bg_fill = CARD;
        v.widgets.inactive.bg_fill = CARD;
        v.widgets.hovered.weak_bg_fill = BORDER;
        v.widgets.active.weak_bg_fill = Color32::from_rgb(46, 83, 87);
        v.selection.bg_fill = Color32::from_rgb(34, 84, 81);
        v.selection.stroke.color = MINT;
        v.hyperlink_color = MINT;
    });
}

pub fn accent(model: Model) -> Color32 {
    match model {
        Model::CiscoSwitch | Model::EltexSwitch => Color32::from_rgb(126, 188, 255),
        Model::CiscoRouter | Model::EltexRouter => MINT,
        Model::Wep2ac | Model::Wep2acSmart => Color32::from_rgb(192, 165, 255),
        _ => Color32::from_rgb(248, 198, 134),
    }
}

// Glyphs use a common 20-unit grid in both the library and the topology.
pub fn icon(p: &egui::Painter, model: Model, center: Pos2, scale: f32) {
    let color = accent(model);
    let at = |x, y| center + Vec2::new(x, y) * scale;
    let stroke = Stroke::new(1.5 * scale, color);
    let line = |x, y, u, v| p.line_segment([at(x, y), at(u, v)], stroke);
    let outline = |w, h, y| {
        p.rect_stroke(
            Rect::from_center_size(at(0., y), Vec2::new(w, h) * scale),
            2.,
            stroke,
            StrokeKind::Inside,
        )
    };
    match model {
        Model::CiscoSwitch | Model::EltexSwitch => {
            outline(20., 11., 0.);
            for x in [-6., -2., 2., 6.] {
                line(x, -1., x, 2.);
            }
        }
        Model::CiscoRouter | Model::EltexRouter => {
            p.circle_stroke(center, 9. * scale, stroke);
            line(-6., 0., 6., 0.);
            line(2., -3., 6., 0.);
            line(2., 3., 6., 0.);
            line(-2., -3., -6., 0.);
            line(-2., 3., -6., 0.);
        }
        Model::Wep2ac | Model::Wep2acSmart => {
            for r in [5., 10.] {
                let points = (0..=12)
                    .map(|i| {
                        let a = std::f32::consts::FRAC_PI_4 * (1. + i as f32 / 6.);
                        at(r * a.cos(), 5. - r * a.sin())
                    })
                    .collect();
                p.add(egui::Shape::line(points, stroke));
            }
            p.circle_filled(at(0., 5.), 1.8 * scale, color);
        }
        Model::Server => {
            for y in [-4., 4.] {
                outline(16., 7., y);
                line(-5., y, -3., y);
            }
        }
        Model::Pc | Model::Laptop => {
            outline(17., 12., -2.);
            if model == Model::Pc {
                line(0., 4., 0., 7.);
                line(-5., 7., 5., 7.);
            } else {
                line(-10., 6., 10., 6.);
            }
        }
    }
}

pub fn mark(ui: &mut egui::Ui) {
    let (rect, _) = ui.allocate_exact_size(Vec2::splat(30.), egui::Sense::hover());
    let p = ui.painter();
    p.rect_filled(rect, 8., MINT);
    let at = |x, y| rect.center() + Vec2::new(x, y);
    let nodes = [at(-7., 4.), at(0., -6.), at(7., 4.)];
    p.add(egui::Shape::line(nodes.to_vec(), Stroke::new(2., CANVAS)));
    for n in nodes {
        p.circle_filled(n, 2.8, CANVAS);
    }
}
