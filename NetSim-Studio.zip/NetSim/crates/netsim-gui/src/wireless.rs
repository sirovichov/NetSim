//! Native rendering of documented Eltex management pages; no HTTP listener.
use super::*;
use netsim_storage::{DhcpPool, Vap, WifiClient};

impl Studio {
    pub(super) fn ap_panel(&mut self, ui: &mut egui::Ui, id: u64) {
        ui.separator();
        ui.heading("Eltex Web UI • 1.25.0");
        ui.collapsing("Manage / Ethernet Settings", |ui| {
            ui.add(
                egui::DragValue::new(&mut self.ap_draft.native_vlan)
                    .range(1..=4094)
                    .prefix("Untagged VLAN ID "),
            );
        });
        ui.collapsing("Manage / Radio", |ui| {
            for (idx, r) in self.ap_draft.radios.iter_mut().enumerate() {
                ui.label(if idx == 0 {
                    "Radio 1 — 5 GHz"
                } else {
                    "Radio 2 — 2.4 GHz"
                });
                ui.checkbox(&mut r.enabled, "Status: On");
                let channels: Vec<u8> = if idx == 0 {
                    vec![
                        36, 40, 44, 48, 52, 56, 60, 64, 100, 104, 108, 112, 116, 120, 124, 128,
                        132, 136, 140, 144, 149, 153, 157, 161, 165,
                    ]
                } else {
                    (1..=13).collect()
                };
                egui::ComboBox::from_id_salt(("channel", id, idx))
                    .selected_text(r.channel.to_string())
                    .show_ui(ui, |ui| {
                        for ch in channels {
                            ui.selectable_value(&mut r.channel, ch, ch.to_string());
                        }
                    });
            }
        });
        ui.collapsing("Manage / VAP", |ui| {
            let mut remove = None;
            for (i, v) in self.ap_draft.vaps.iter_mut().enumerate() {
                ui.push_id(i, |ui| {
                    ui.separator();
                    ui.horizontal(|ui| {
                        ui.label(format!("Radio {} / VAP {}", v.radio, v.index));
                        if ui.small_button("×").clicked() {
                            remove = Some(i);
                        }
                    });
                    ui.checkbox(&mut v.enabled, "Enabled");
                    ui.add(
                        egui::DragValue::new(&mut v.radio)
                            .range(1..=2)
                            .prefix("Radio "),
                    );
                    ui.add(
                        egui::DragValue::new(&mut v.index)
                            .range(0..=15)
                            .prefix("VAP "),
                    );
                    ui.label("SSID");
                    ui.text_edit_singleline(&mut v.ssid);
                    ui.checkbox(&mut v.broadcast, "Broadcast SSID");
                    ui.add(
                        egui::DragValue::new(&mut v.vlan)
                            .range(1..=4094)
                            .prefix("VLAN ID "),
                    );
                    let mut secure = v.psk.is_some();
                    if ui
                        .checkbox(&mut secure, "WPA Personal / WPA2-AES")
                        .changed()
                    {
                        v.psk = secure.then(String::new);
                    }
                    if let Some(key) = v.psk.as_mut() {
                        ui.add(
                            egui::TextEdit::singleline(key)
                                .password(true)
                                .hint_text("Key (8–63)"),
                        );
                    }
                });
            }
            if let Some(i) = remove {
                self.ap_draft.vaps.remove(i);
            }
            if ui
                .add_enabled(self.ap_draft.vaps.len() < 32, egui::Button::new("Add VAP"))
                .clicked()
            {
                if let Some((radio, index)) = (1..=2)
                    .flat_map(|r| (0..16).map(move |i| (r, i)))
                    .find(|(r, i)| {
                        !self
                            .ap_draft
                            .vaps
                            .iter()
                            .any(|v| v.radio == *r && v.index == *i)
                    })
                {
                    self.ap_draft.vaps.push(Vap {
                        radio,
                        index,
                        enabled: true,
                        ssid: format!("NetSim-{radio}-{index}"),
                        broadcast: true,
                        vlan: 1,
                        psk: None,
                    });
                }
            }
        });
        if ui.button("Update").clicked() {
            let r = self.doc.configure_ap(id, self.ap_draft.clone());
            self.result(r);
        }
        ui.collapsing("Status / Client Associations", |ui| {
            for a in self.doc.associations().iter().filter(|a| a.ap == id) {
                ui.label(format!(
                    "{} | Radio {} ch {} VAP {} | VLAN {} | {} dBm",
                    a.client, a.radio, a.channel, a.vap, a.vlan, a.signal_dbm
                ));
            }
        });
        ui.small(self.tr(
            "Учебная модель. Ключи хранятся в проекте открытым текстом.",
            "Teaching model. Keys are stored in plaintext in project.",
        ));
    }
    pub(super) fn wifi_panel(&mut self, ui: &mut egui::Ui, id: u64) {
        ui.separator();
        ui.heading("Wi-Fi");
        ui.label("SSID");
        ui.text_edit_singleline(&mut self.wifi_ssid);
        ui.add(
            egui::TextEdit::singleline(&mut self.wifi_key)
                .password(true)
                .hint_text("PSK (optional)"),
        );
        ui.radio_value(&mut self.wifi_radio, 1, "5 GHz");
        ui.radio_value(&mut self.wifi_radio, 2, "2.4 GHz");
        if ui.button(self.tr("Подключиться", "Associate")).clicked() {
            let c = WifiClient {
                ssid: self.wifi_ssid.clone(),
                psk: (!self.wifi_key.is_empty()).then(|| self.wifi_key.clone()),
                radio: self.wifi_radio,
            };
            let r = self.doc.configure_wifi(id, Some(c));
            self.result(r);
        }
        if ui
            .button(self.tr("Отключить Wi-Fi", "Disable Wi-Fi"))
            .clicked()
        {
            let r = self.doc.configure_wifi(id, None);
            self.result(r);
        }
        if let Some(a) = self.doc.associations().iter().find(|a| a.client == id) {
            ui.label(format!(
                "AP {} / VLAN {} / {} dBm",
                a.ap, a.vlan, a.signal_dbm
            ));
        } else {
            ui.label(self.tr("Нет ассоциации", "Not associated"));
        }
        ui.collapsing(
            self.tr("Доступные сети", "Available networks"),
            |ui| {
                let networks = self.doc.wifi_scan(id, self.wifi_radio);
                if networks.is_empty() {
                    ui.label(self.tr(
                        "В этом диапазоне сети не обнаружены",
                        "No networks found on this band",
                    ));
                }
                for network in networks {
                    let name = self
                        .doc
                        .node(network.ap)
                        .map_or("", |n| n.hostname.as_str());
                    let security = if network.secured {
                        "WPA2"
                    } else {
                        self.tr("открытая", "open")
                    };
                    let channel = self.tr("канал", "channel");
                    let label = format!(
                        "{} · {name} · {security}\n{channel} {} · {} dBm",
                        network.ssid, network.channel, network.signal_dbm
                    );
                    if ui.button(label).clicked() {
                        if network.ssid != self.wifi_ssid || !network.secured {
                            self.wifi_key.clear();
                        }
                        self.wifi_ssid = network.ssid;
                    }
                }
            },
        );
    }
    pub(super) fn service_panel(&mut self, ui: &mut egui::Ui, id: u64, model: Model) {
        if model.host() {
            ui.separator();
            ui.heading("DHCP");
            if ui
                .add_enabled(
                    !self.doc.services().dhcp_clients.contains(&id)
                        && !self.doc.services().dhcp_servers.contains_key(&id),
                    egui::Button::new("DHCP Client"),
                )
                .clicked()
            {
                let r = self.doc.enable_dhcp(id);
                self.result(r);
            }
            for d in self
                .doc
                .dhcp_status()
                .iter()
                .filter(|d| Some(d.device) == self.doc.engine_id(id))
            {
                ui.label(format!(
                    "{:?} {:?} / expiry {} s",
                    d.phase,
                    d.address,
                    d.expires / 1_000_000_000
                ));
            }
        }
        if model == Model::Server {
            ui.collapsing("DHCP Server", |ui| {
                ui.label("First address");
                ui.text_edit_singleline(&mut self.pool_first);
                ui.label("Last address");
                ui.text_edit_singleline(&mut self.pool_last);
                ui.add(
                    egui::DragValue::new(&mut self.pool_prefix)
                        .range(1..=30)
                        .prefix("CIDR /"),
                );
                ui.label("Gateway");
                ui.text_edit_singleline(&mut self.pool_gateway);
                ui.add(
                    egui::DragValue::new(&mut self.pool_lease)
                        .range(60..=86400)
                        .prefix("Lease s "),
                );
                if ui.button("Apply pool").clicked() {
                    let r = (|| {
                        let first = self
                            .pool_first
                            .parse()
                            .map_err(|_| "Invalid pool".to_string())?;
                        let last = self
                            .pool_last
                            .parse()
                            .map_err(|_| "Invalid pool".to_string())?;
                        let gateway = if self.pool_gateway.is_empty() {
                            None
                        } else {
                            Some(
                                self.pool_gateway
                                    .parse()
                                    .map_err(|_| "Invalid gateway".to_string())?,
                            )
                        };
                        self.doc.configure_dhcp_server(
                            id,
                            DhcpPool {
                                first,
                                last,
                                prefix: self.pool_prefix,
                                gateway,
                                lease_secs: self.pool_lease,
                            },
                        )
                    })();
                    self.result(r);
                }
            });
        }
        if matches!(model, Model::CiscoRouter | Model::EltexRouter) {
            ui.separator();
            ui.heading("OSPF • Area 0");
            ui.label("Router ID");
            ui.text_edit_singleline(&mut self.ospf_id);
            if ui.button("Enable / Apply OSPF").clicked() {
                let r = self
                    .ospf_id
                    .parse()
                    .map_err(|_| "Invalid router ID".to_string())
                    .and_then(|rid| self.doc.enable_ospf(id, rid));
                self.result(r);
            }
            for o in self
                .doc
                .ospf_status()
                .iter()
                .filter(|o| Some(o.device) == self.doc.engine_id(id))
            {
                ui.label(format!("Neighbors: {:?} / LSDB: {}", o.neighbors, o.lsdb));
            }
        }
    }
}
