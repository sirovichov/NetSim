//! Native topology editor. No external network sockets are opened.
use eframe::egui::{self, Color32, Pos2, Rect, Sense, Stroke, Vec2};
use netsim_app::beta_labs;
use netsim_app::beta_worker::{Action, Reply, Worker};
use netsim_app::desktop::{Desktop, History};
use netsim_core::{LinkId, PortId, PowerState};
use netsim_engine::{Outcome, SimulationSnapshot, TraceAction, TraceEntry};
use netsim_storage::{ApConfig, Endpoint, HostConfig, Model};
mod terminal;
mod theme;
use terminal::Terminal;
mod wireless;
use std::{
    collections::BTreeMap,
    path::Path,
    time::{Duration, Instant},
};

fn main() -> eframe::Result<()> {
    let smoke = std::env::args().any(|arg| arg == "--gui-smoke");
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1200.0, 800.0])
            .with_min_inner_size([800.0, 560.0]),
        ..Default::default()
    };
    eframe::run_native(
        "NetSim Studio",
        options,
        Box::new(move |cc| {
            theme::apply(&cc.egui_ctx);
            let mut app = Studio::new();
            if smoke {
                let project = netsim_storage::Project::decode(include_bytes!(
                    "../../../examples/two-pcs.netsim"
                ))
                .expect("valid smoke project");
                app.doc = Desktop::from_project(project).expect("build smoke topology");
                app.select(1);
                app.open_terminal(&cc.egui_ctx, 1);
                app.open_terminal(&cc.egui_ctx, 2);
                app.smoke_frames = Some(0);
            }
            Ok(Box::new(app))
        }),
    )
}

struct Pulse {
    link: LinkId,
    source: PortId,
    start: Instant,
}
#[derive(Clone, Copy, PartialEq, Eq)]
enum Mode {
    Simulation,
    RealTime,
}
struct Studio {
    doc: Desktop,
    worker: Worker,
    busy: bool,
    pending_cli: Option<u64>,
    worker_failed: bool,
    history: History,
    drag_checkpoint: bool,
    inspect: bool,
    capture_path: String,
    packet_index: usize,
    lab_index: usize,
    lab_loaded: Option<usize>,
    lab_report: String,
    ru: bool,
    mode: Mode,
    playing: bool,
    speed: f32,
    last: Instant,
    zoom: f32,
    pan: Vec2,
    selected: Option<u64>,
    placing: Option<Model>,
    drag_model: Option<Model>,
    pending: Option<Endpoint>,
    selected_port: String,
    terminals: BTreeMap<u64, Terminal>,
    ip: String,
    prefix: u8,
    gateway: String,
    ping: String,
    path: String,
    status: String,
    ap_draft: ApConfig,
    wifi_ssid: String,
    wifi_key: String,
    wifi_radio: u8,
    pool_first: String,
    pool_last: String,
    pool_gateway: String,
    pool_prefix: u8,
    pool_lease: u32,
    ospf_id: String,
    trace_cursor: u64,
    pulses: Vec<Pulse>,
    confirm_open: bool,
    smoke_frames: Option<u8>,
}
impl Studio {
    fn new() -> Self {
        Self {
            doc: Desktop::new(42).expect("valid built-in registry"),
            worker: Worker::new().expect("simulation worker"),
            busy: false,
            pending_cli: None,
            worker_failed: false,
            history: History::default(),
            drag_checkpoint: false,
            inspect: false,
            capture_path: "capture.pcap".into(),
            packet_index: 0,
            lab_index: 0,
            lab_loaded: None,
            lab_report: String::new(),
            ru: true,
            mode: Mode::Simulation,
            playing: false,
            speed: 1.0,
            last: Instant::now(),
            zoom: 1.0,
            pan: Vec2::ZERO,
            selected: None,
            placing: None,
            drag_model: None,
            pending: None,
            selected_port: String::new(),
            terminals: BTreeMap::new(),
            ip: String::new(),
            prefix: 24,
            gateway: String::new(),
            ping: "10.0.0.2".into(),
            path: "network.netsim".into(),
            status: String::new(),
            ap_draft: ApConfig::default(),
            wifi_ssid: "NetSim".into(),
            wifi_key: String::new(),
            wifi_radio: 2,
            pool_first: "10.0.0.100".into(),
            pool_last: "10.0.0.150".into(),
            pool_gateway: String::new(),
            pool_prefix: 24,
            pool_lease: 3600,
            ospf_id: "1.1.1.1".into(),
            trace_cursor: 0,
            pulses: Vec::new(),
            confirm_open: false,
            smoke_frames: None,
        }
    }
    fn tr(&self, ru: &'static str, en: &'static str) -> &'static str {
        if self.ru { ru } else { en }
    }
    fn result<T>(&mut self, r: Result<T, String>) -> Option<T> {
        match r {
            Ok(v) => {
                self.status.clear();
                Some(v)
            }
            Err(e) => {
                self.status = e;
                self.playing = false;
                None
            }
        }
    }
    fn select(&mut self, id: u64) {
        self.selected = Some(id);
        if let Some(n) = self.doc.node(id) {
            self.ap_draft = self
                .doc
                .wireless()
                .aps
                .get(&id)
                .cloned()
                .unwrap_or_default();
            if let Some(c) = self.doc.wireless().clients.get(&id) {
                self.wifi_ssid = c.ssid.clone();
                self.wifi_key = c.psk.clone().unwrap_or_default();
                self.wifi_radio = c.radio;
            } else {
                self.wifi_ssid = "NetSim".into();
                self.wifi_key.clear();
                self.wifi_radio = 2;
            }
            if let Some(pool) = self.doc.services().dhcp_servers.get(&id) {
                self.pool_first = pool.first.to_string();
                self.pool_last = pool.last.to_string();
                self.pool_gateway = pool.gateway.map(|g| g.to_string()).unwrap_or_default();
                self.pool_prefix = pool.prefix;
                self.pool_lease = pool.lease_secs;
            }
            if let Some(rid) = self.doc.services().ospf.get(&id) {
                self.ospf_id = rid.to_string();
            }
            self.selected_port = Desktop::port_names(n.model)
                .first()
                .cloned()
                .unwrap_or_default();
            self.ip = n
                .host
                .as_ref()
                .map(|h| h.ip.to_string())
                .unwrap_or_default();
            self.prefix = n.host.as_ref().map_or(24, |h| h.prefix);
            self.gateway = n
                .host
                .as_ref()
                .and_then(|h| h.gateway)
                .map(|g| g.to_string())
                .unwrap_or_default();
        }
    }
    fn submit(&mut self, action: Action) {
        if self.busy {
            return;
        }
        let replacement = match Desktop::new(42) {
            Ok(d) => d,
            Err(e) => {
                self.status = e;
                return;
            }
        };
        let d = std::mem::replace(&mut self.doc, replacement);
        let terminal_id = match &action {
            Action::Cli { node, .. } => Some(*node),
            _ => None,
        };
        match self.worker.submit(d, action) {
            Ok(()) => {
                self.busy = true;
                self.pending_cli = terminal_id;
            }
            Err(d) => {
                self.doc = d;
                self.status = "Worker busy or disconnected".into();
                if let Some(terminal) = terminal_id.and_then(|id| self.terminals.get_mut(&id)) {
                    terminal.append(&self.status);
                }
                self.playing = false;
            }
        }
    }
    fn checkpoint(&mut self) -> bool {
        match self.doc.export() {
            Ok(p) => {
                self.history.record(p);
                true
            }
            Err(e) => {
                self.status = e;
                false
            }
        }
    }
    fn history_action(&mut self, undo: bool) {
        let r = if undo {
            self.history.undo(&self.doc)
        } else {
            self.history.redo(&self.doc)
        };
        if let Some(Some(d)) = self.result(r) {
            self.doc = d;
            self.clear_ui();
        }
    }
    fn add(&mut self, m: Model, p: Pos2) {
        if !self.checkpoint() {
            return;
        }

        let r = self.doc.add(m, [p.x, p.y]);
        if let Some(id) = self.result(r) {
            self.select(id);
        }
    }
    fn clear_ui(&mut self) {
        self.selected = None;
        self.placing = None;
        self.drag_model = None;
        self.pending = None;
        self.terminals.clear();
        self.pulses.clear();
        self.trace_cursor = 0;
        self.drag_checkpoint = false;
        self.playing = false;
        self.pan = Vec2::ZERO;
        self.zoom = 1.0;
    }
    fn load(&mut self) {
        let r = netsim_storage::load(Path::new(&self.path)).and_then(Desktop::from_project);
        if let Some(doc) = self.result(r) {
            self.doc = doc;
            self.history = History::default();
            self.lab_loaded = None;
            self.clear_ui();
            self.status = self.tr("Проект открыт", "Project loaded").into();
        }
    }
    fn save(&mut self) {
        let r = self
            .doc
            .export()
            .and_then(|p| netsim_storage::save(Path::new(&self.path), &p));
        if self.result(r).is_some() {
            self.status = self.tr("Проект сохранён", "Project saved").into();
        }
    }
    fn update_pulses(&mut self, trace: &netsim_engine::TraceSnapshot) {
        let end = trace.dropped.saturating_add(trace.entries.len() as u64);
        let start = self
            .trace_cursor
            .saturating_sub(trace.dropped)
            .min(trace.entries.len() as u64) as usize;
        for e in trace.entries[start..].iter().rev().take(64).rev() {
            if let TraceAction::FrameTx { port, link, .. } = e.action {
                if e.outcome == Outcome::Applied {
                    self.pulses.push(Pulse {
                        link,
                        source: port,
                        start: Instant::now(),
                    });
                }
            }
        }
        self.trace_cursor = end;
        self.pulses
            .retain(|p| p.start.elapsed() < Duration::from_millis(650));
        if self.pulses.len() > 128 {
            self.pulses.drain(..self.pulses.len() - 128);
        }
    }
    fn top(&mut self, ctx: &egui::Context, snap: &SimulationSnapshot) {
        egui::TopBottomPanel::top("toolbar").show(ctx, |ui| {
            ui.horizontal(|ui| {
                theme::mark(ui);
                ui.label(egui::RichText::new("NetSim Studio").size(22.).strong());
                ui.add_space(8.);
                ui.menu_button(self.tr("Проект", "Project"), |ui| {
                    ui.label(self.tr("Файл проекта", "Project file"));
                    ui.add(egui::TextEdit::singleline(&mut self.path).desired_width(270.));
                    if ui.button(self.tr("Открыть…", "Open…")).clicked() {
                        self.confirm_open = true;
                        ui.close_menu();
                    }
                    if ui.button(self.tr("Сохранить", "Save")).clicked() {
                        self.save();
                        ui.close_menu();
                    }
                });
                ui.menu_button(self.tr("Правка", "Edit"), |ui| {
                    if ui.button(self.tr("Отменить", "Undo")).clicked() {
                        self.history_action(true);
                        ui.close_menu();
                    }
                    if ui.button(self.tr("Повторить", "Redo")).clicked() {
                        self.history_action(false);
                        ui.close_menu();
                    }
                });
                if ui
                    .selectable_label(self.inspect, self.tr("Пакеты", "Packets"))
                    .clicked()
                {
                    self.inspect = !self.inspect;
                }
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    ui.selectable_value(&mut self.ru, false, "EN");
                    ui.selectable_value(&mut self.ru, true, "RU");
                });
            });
            ui.separator();
            ui.horizontal_wrapped(|ui| {
                let sim = self.tr("Симуляция", "Simulation");
                ui.selectable_value(&mut self.mode, Mode::Simulation, sim);
                ui.selectable_value(&mut self.mode, Mode::RealTime, "Real-Time");
                if self.mode == Mode::Simulation {
                    self.playing = false;
                }
                if self.mode == Mode::RealTime {
                    let label = if self.playing {
                        self.tr("Пауза", "Pause")
                    } else {
                        self.tr("Пуск", "Play")
                    };
                    if ui.button(label).clicked() {
                        self.playing = !self.playing;
                        self.last = Instant::now();
                    }
                    ui.add(egui::Slider::new(&mut self.speed, 0.1..=4.0).text("×"));
                }
                if ui.button(self.tr("Шаг", "Step")).clicked() {
                    self.playing = false;
                    self.submit(Action::Step);
                }
                if ui.button("+1 s").clicked() {
                    self.playing = false;
                    self.submit(Action::Advance(1_000_000_000));
                }
                if ui.button("+40 s").clicked() {
                    self.playing = false;
                    self.submit(Action::Advance(40_000_000_000));
                }
                ui.separator();
                ui.monospace(format!("{:.3} s", snap.now as f64 / 1e9));
                ui.colored_label(
                    theme::MUTED,
                    format!("{} {}", self.tr("В очереди", "Queued"), snap.pending_events),
                );
            });
            if !self.status.is_empty() {
                ui.label(&self.status);
            }
        });
        if self.confirm_open && !self.busy {
            egui::Window::new(self.tr("Открытие проекта", "Open project"))
                .collapsible(false)
                .show(ctx, |ui| {
                    ui.label(self.tr(
                        "Заменить текущую сеть? Несохранённые изменения будут потеряны.",
                        "Replace current network? Unsaved changes will be lost.",
                    ));
                    ui.horizontal(|ui| {
                        if ui.button(self.tr("Открыть", "Open")).clicked() {
                            self.confirm_open = false;
                            self.load();
                        }
                        if ui.button(self.tr("Отмена", "Cancel")).clicked() {
                            self.confirm_open = false;
                        }
                    });
                });
        }
    }
    fn catalog(&mut self, ctx: &egui::Context) {
        egui::SidePanel::left("catalog")
            .default_width(198.0)
            .width_range(172.0..=280.0)
            .show(ctx, |ui| {
                egui::ScrollArea::vertical()
                    .id_salt("catalog-scroll")
                    .auto_shrink([false, false])
                    .show(ui, |ui| {
                        ui.heading(self.tr("Оборудование", "Devices"));
                        for (group, models) in [
                            ("Cisco", &[Model::CiscoSwitch, Model::CiscoRouter][..]),
                            ("Eltex", &[Model::EltexSwitch, Model::EltexRouter][..]),
                            (
                                self.tr("Беспроводная сеть", "Wireless"),
                                &[Model::Wep2ac, Model::Wep2acSmart][..],
                            ),
                            (
                                self.tr("Конечные устройства", "Endpoints"),
                                &[Model::Pc, Model::Laptop, Model::Server][..],
                            ),
                        ] {
                            ui.add_space(4.);
                            ui.label(
                                egui::RichText::new(group)
                                    .small()
                                    .strong()
                                    .color(theme::MUTED),
                            );
                            for &model in models {
                                let (rect, r) = ui.allocate_exact_size(
                                    Vec2::new(ui.available_width(), 27.),
                                    Sense::click_and_drag(),
                                );
                                let fill = if self.placing == Some(model) {
                                    ui.visuals().selection.bg_fill
                                } else if r.hovered() {
                                    theme::BORDER
                                } else {
                                    theme::CARD
                                };
                                ui.painter().rect_filled(rect, 5., fill);
                                theme::icon(
                                    ui.painter(),
                                    model,
                                    rect.left_center() + Vec2::new(16., 0.),
                                    0.8,
                                );
                                ui.painter().text(
                                    rect.left_center() + Vec2::new(34., 0.),
                                    egui::Align2::LEFT_CENTER,
                                    model.label(),
                                    egui::FontId::proportional(13.),
                                    ui.visuals().text_color(),
                                );
                                if r.drag_started() {
                                    self.drag_model = Some(model);
                                    self.placing = None;
                                }
                                if r.clicked() {
                                    self.placing = Some(model);
                                }
                            }
                        }
                        ui.add_space(6.);
                        ui.separator();
                        ui.heading(self.tr("Лаборатории", "Labs"));
                        egui::ComboBox::from_id_salt("labs")
                            .selected_text(beta_labs::CATALOG[self.lab_index].0)
                            .show_ui(ui, |ui| {
                                for (i, (id, title)) in beta_labs::CATALOG.iter().enumerate() {
                                    ui.selectable_value(
                                        &mut self.lab_index,
                                        i,
                                        format!("{id} {title}"),
                                    );
                                }
                            });
                        if ui
                            .button(self.tr("Начать (заменить сеть)", "Start (replace network)"))
                            .clicked()
                        {
                            let i = self.lab_index;
                            let r = beta_labs::starter(i).and_then(|l| {
                                self.lab_report = l.instructions;
                                Desktop::from_project(l.starter)
                            });
                            if let Some(d) = self.result(r) {
                                self.doc = d;
                                self.history = History::default();
                                self.clear_ui();
                                self.lab_loaded = Some(i);
                            }
                        }
                        if let Some(i) = self.lab_loaded {
                            if ui.button(self.tr("Проверить", "Grade")).clicked() {
                                self.playing = false;
                                self.submit(Action::Grade(i));
                            }
                            if self.busy {
                                return;
                            }
                            ui.small(&self.lab_report);
                        }
                        ui.separator();
                        if let Some(m) = self.placing {
                            ui.label(m.label());
                            if ui
                                .button(self.tr("Отмена размещения", "Cancel placement"))
                                .clicked()
                            {
                                self.placing = None;
                            }
                        }
                    });
            });
    }
    fn properties(&mut self, ctx: &egui::Context, snap: &SimulationSnapshot) {
        egui::SidePanel::right("properties")
            .default_width(236.0)
            .width_range(200.0..=360.0)
            .show(ctx, |ui| {
                ui.heading(if self.selected.is_some() {
                    self.tr("Устройство", "Device")
                } else {
                    self.tr("Обзор сети", "Network overview")
                });
                ui.separator();
                egui::ScrollArea::vertical().show(ui, |ui| {
                    let Some(id) = self.selected else {
                        ui.label(format!(
                            "{}   {}",
                            self.tr("Устройства", "Devices"),
                            self.doc.nodes().len()
                        ));
                        ui.label(format!(
                            "{}   {}",
                            self.tr("Кабели", "Cables"),
                            self.doc.cables().len()
                        ));
                        ui.separator();
                        let mut selected = None;
                        for n in self.doc.nodes() {
                            if ui.selectable_label(false, &n.hostname).clicked() {
                                selected = Some(n.id);
                            }
                        }
                        if let Some(id) = selected {
                            self.select(id);
                        }
                        if self.doc.nodes().is_empty() {
                            ui.colored_label(
                                theme::MUTED,
                                self.tr(
                                    "Здесь появятся устройства вашей сети.",
                                    "Devices in your topology will appear here.",
                                ),
                            );
                        }
                        return;
                    };
                    let Some(n) = self.doc.node(id).cloned() else {
                        self.selected = None;
                        return;
                    };
                    ui.heading(&n.hostname);
                    ui.colored_label(theme::MUTED, n.model.label());
                    if ui
                        .add(
                            egui::Button::new(
                                egui::RichText::new(self.tr("Открыть CLI", "Open CLI"))
                                    .strong()
                                    .color(theme::CANVAS),
                            )
                            .fill(theme::MINT)
                            .min_size(Vec2::new(ui.available_width(), 31.)),
                        )
                        .clicked()
                    {
                        self.open_terminal(ctx, id);
                    }
                    ui.separator();
                    let powered = snap
                        .devices
                        .iter()
                        .find(|d| Some(d.id) == self.doc.engine_id(id))
                        .is_some_and(|d| d.power == PowerState::On);
                    if ui
                        .button(if powered {
                            self.tr("Выключить", "Power off")
                        } else {
                            self.tr("Включить", "Power on")
                        })
                        .clicked()
                    {
                        let r = self.doc.power(id, !powered);
                        self.result(r);
                    }
                    if ui
                        .button(self.tr("Удалить устройство", "Delete device"))
                        .clicked()
                    {
                        if !self.checkpoint() {
                            return;
                        }
                        let r = self.doc.remove(id);
                        if self.result(r).is_some() {
                            self.selected = None;
                            self.pending = None;
                            self.terminals.remove(&id);
                        }
                        return;
                    }
                    ui.separator();
                    ui.label(self.tr("Порт для кабеля", "Cable port"));
                    let names = Desktop::port_names(n.model);
                    egui::ComboBox::from_id_salt(("port", id))
                        .selected_text(&self.selected_port)
                        .show_ui(ui, |ui| {
                            for name in &names {
                                let e = Endpoint {
                                    node: id,
                                    port: name.clone(),
                                };
                                let p = self.doc.port(&e);
                                let busy = snap
                                    .links
                                    .iter()
                                    .any(|(_, l)| p.is_some_and(|p| l.endpoints.contains(&p)));
                                let admin = p.is_some_and(|p| !snap.admin_down.contains(&p));
                                let label = format!(
                                    "{name} {} {}",
                                    if busy { "[linked]" } else { "" },
                                    if admin { "" } else { "[shutdown]" }
                                );
                                ui.selectable_value(&mut self.selected_port, name.clone(), label);
                            }
                        });
                    if ui
                        .button(self.tr("Выбрать конец кабеля", "Select cable endpoint"))
                        .clicked()
                    {
                        let e = Endpoint {
                            node: id,
                            port: self.selected_port.clone(),
                        };
                        if let Some(a) = self.pending.clone() {
                            if !self.checkpoint() {
                                return;
                            }
                            let r = self.doc.connect(a, e);
                            if self.result(r).is_some() {
                                self.pending = None;
                            }
                        } else {
                            self.pending = Some(e);
                        }
                    }
                    if let Some(a) = &self.pending {
                        ui.label(format!("→ {} / {}", a.node, a.port));
                        if ui
                            .button(self.tr("Отмена кабеля", "Cancel cable"))
                            .clicked()
                        {
                            self.pending = None;
                        }
                    }
                    let cables: Vec<_> = self
                        .doc
                        .cables()
                        .iter()
                        .enumerate()
                        .filter(|(_, c)| c.ends.iter().any(|e| e.node == id))
                        .map(|(i, c)| (i, c.clone()))
                        .collect();
                    for (i, c) in cables {
                        ui.horizontal(|ui| {
                            ui.small(format!(
                                "{}:{} ↔ {}:{}",
                                c.ends[0].node, c.ends[0].port, c.ends[1].node, c.ends[1].port
                            ));
                            if ui.small_button("×").clicked() && self.checkpoint() {
                                let r = self.doc.disconnect(i);
                                self.result(r);
                            }
                        });
                    }
                    if n.model.host() {
                        ui.separator();
                        ui.label("IPv4");
                        ui.text_edit_singleline(&mut self.ip);
                        ui.add(egui::Slider::new(&mut self.prefix, 0..=32).text("CIDR"));
                        ui.label(self.tr("Шлюз (необязательно)", "Gateway (optional)"));
                        ui.text_edit_singleline(&mut self.gateway);
                        if ui.button(self.tr("Применить IP", "Apply IP")).clicked() {
                            let r = (|| {
                                let ip = self
                                    .ip
                                    .parse()
                                    .map_err(|_| "Invalid IPv4 address".to_string())?;
                                let gateway = if self.gateway.trim().is_empty() {
                                    None
                                } else {
                                    Some(
                                        self.gateway
                                            .parse()
                                            .map_err(|_| "Invalid gateway".to_string())?,
                                    )
                                };
                                self.doc.configure_host(
                                    id,
                                    HostConfig {
                                        ip,
                                        prefix: self.prefix,
                                        gateway,
                                    },
                                )
                            })();
                            self.result(r);
                        }
                    }
                    if n.model.host() || matches!(n.model, Model::CiscoRouter | Model::EltexRouter)
                    {
                        ui.separator();
                        ui.label("ICMP ping");
                        ui.text_edit_singleline(&mut self.ping);
                        if ui
                            .button(self.tr("Отправить пакет", "Send packet"))
                            .clicked()
                        {
                            let r = self
                                .ping
                                .parse()
                                .map_err(|_| "Invalid IPv4 address".to_string())
                                .and_then(|ip| self.doc.ping(id, ip));
                            if let Some(token) = self.result(r) {
                                self.status = format!("Probe #{token}");
                            }
                        }
                        if let Some(ipnode) = snap
                            .l3
                            .nodes
                            .iter()
                            .find(|n| Some(n.device) == self.doc.engine_id(id))
                        {
                            for p in ipnode.probes.iter().rev().take(5) {
                                ui.small(format!("{}: {:?}", p.destination, p.status));
                            }
                        }
                    }
                    if n.model.ap() {
                        self.ap_panel(ui, id);
                    }
                    if self.busy {
                        return;
                    }
                    if n.model == Model::Laptop {
                        self.wifi_panel(ui, id);
                    }
                    self.service_panel(ui, id, n.model);
                });
            });
    }
    fn packets(&mut self, ctx: &egui::Context) {
        let mut open = self.inspect;
        if !open {
            return;
        }
        egui::Window::new("Packet Inspector / PCAP")
            .open(&mut open)
            .show(ctx, |ui| {
                let capture = self.doc.capture();
                ui.label(format!(
                    "{} records; {} evicted",
                    capture.records().len(),
                    capture.dropped()
                ));
                ui.text_edit_singleline(&mut self.capture_path);
                if ui.button("Export PCAP").clicked() {
                    match std::fs::File::create(&self.capture_path).and_then(|f| {
                        netsim_capture::write_pcap(f, capture.records().iter().cloned())
                    }) {
                        Ok(()) => self.status = "PCAP saved".into(),
                        Err(e) => self.status = e.to_string(),
                    }
                }
                if !capture.records().is_empty() {
                    self.packet_index = self.packet_index.min(capture.records().len() - 1);
                    ui.add(egui::Slider::new(
                        &mut self.packet_index,
                        0..=capture.records().len() - 1,
                    ));
                    if let Some(r) = capture.records().get(self.packet_index) {
                        for s in netsim_capture::inspect(r) {
                            ui.label(s);
                        }
                        ui.monospace(
                            r.bytes
                                .iter()
                                .map(|b| format!("{b:02x}"))
                                .collect::<Vec<_>>()
                                .join(" "),
                        );
                    }
                }
            });
        self.inspect = open;
    }
    fn events(&self, ctx: &egui::Context, trace: &[TraceEntry]) {
        egui::TopBottomPanel::bottom("events")
            .resizable(true)
            .default_height(105.0)
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    ui.strong(self.tr("Журнал событий", "Event trace"));
                    ui.colored_label(theme::MUTED, trace.len().to_string());
                });
                ui.separator();
                egui::ScrollArea::vertical()
                    .auto_shrink([false, false])
                    .stick_to_bottom(true)
                    .show(ui, |ui| {
                        if trace.is_empty() {
                            ui.colored_label(
                                theme::MUTED,
                                self.tr("Событий пока нет", "No events yet"),
                            );
                        }
                        for e in trace.iter().rev().take(150).rev() {
                            ui.label(
                                egui::RichText::new(format!(
                                    "{:>14} ns | dev {:>4} | {:?} | {:?}",
                                    e.at, e.device.0, e.action, e.outcome
                                ))
                                .monospace()
                                .small(),
                            );
                        }
                    });
            });
    }
    fn canvas(&mut self, ctx: &egui::Context, snap: &SimulationSnapshot) {
        egui::CentralPanel::default().show(ctx, |ui| {
            ui.horizontal_wrapped(|ui| {
                ui.heading(self.tr("Топология", "Topology"));
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if ui.small_button(self.tr("Сброс", "Reset")).clicked() {
                        self.zoom = 1.;
                        self.pan = Vec2::ZERO;
                    }
                    if ui.small_button("+").clicked() {
                        self.zoom = (self.zoom * 1.2).min(2.5);
                    }
                    ui.monospace(format!("{:.0}%", self.zoom * 100.));
                    if ui.small_button("−").clicked() {
                        self.zoom = (self.zoom / 1.2).max(0.4);
                    }
                });
            });
            let (rect, background) =
                ui.allocate_exact_size(ui.available_size(), Sense::click_and_drag());
            let painter = ui.painter_at(rect);
            painter.rect_filled(rect, 8., theme::CANVAS);
            let center = rect.center() + self.pan;
            let zoom = self.zoom;
            let screen = |p: [f32; 2]| center + Vec2::new(p[0], p[1]) * zoom;
            let world = |p: Pos2| Pos2::new((p.x - center.x) / zoom, (p.y - center.y) / zoom);
            let nodes = self.doc.nodes().to_vec();
            let mut node_hit = false;
            let mut move_action = None;
            let mut select_action = None;
            let step = 26. * zoom.max(0.7);
            let mut x = rect.left() + (center.x - rect.left()).rem_euclid(step);
            while x < rect.right() {
                let mut y = rect.top() + (center.y - rect.top()).rem_euclid(step);
                while y < rect.bottom() {
                    painter.circle_filled(Pos2::new(x, y), 1., theme::BORDER);
                    y += step;
                }
                x += step;
            }
            if nodes.is_empty() && self.placing.is_none() && self.drag_model.is_none() {
                let c = rect.center();
                let plate = Rect::from_center_size(c, Vec2::new(295., 104.));
                painter.rect_filled(plate, 10., theme::PANEL);
                painter.rect_stroke(
                    plate,
                    10.,
                    Stroke::new(1., theme::BORDER),
                    egui::StrokeKind::Inside,
                );
                theme::icon(&painter, Model::CiscoRouter, c - Vec2::new(0., 24.), 1.1);
                painter.text(
                    c,
                    egui::Align2::CENTER_CENTER,
                    self.tr("Добавьте первое устройство", "Add your first device"),
                    egui::FontId::proportional(18.),
                    Color32::WHITE,
                );
                painter.text(
                    c + Vec2::new(0., 24.),
                    egui::Align2::CENTER_CENTER,
                    self.tr(
                        "Перетащите модель из каталога на поле",
                        "Drag a model from the library to the canvas",
                    ),
                    egui::FontId::proportional(13.),
                    theme::MUTED,
                );
            }
            for c in self.doc.cables() {
                let Some(a) = self.doc.node(c.ends[0].node) else {
                    continue;
                };
                let Some(b) = self.doc.node(c.ends[1].node) else {
                    continue;
                };
                let p = screen(a.position);
                let q = screen(b.position);
                let up = a.powered
                    && b.powered
                    && c.ends.iter().all(|e| {
                        self.doc
                            .port(e)
                            .is_some_and(|id| !snap.admin_down.contains(&id))
                    });
                let col = if up {
                    Color32::from_rgb(80, 205, 140)
                } else {
                    Color32::from_rgb(210, 95, 90)
                };
                painter.line_segment([p, q], Stroke::new(2.0, col));
                let mid = p + (q - p) * 0.5;
                painter.text(
                    mid + Vec2::new(0.0, -9.0),
                    egui::Align2::CENTER_BOTTOM,
                    format!("{} ↔ {}", c.ends[0].port, c.ends[1].port),
                    egui::FontId::proportional(10.0),
                    Color32::LIGHT_GRAY,
                );
                if let Some(link) = self.doc.link_id(c, snap) {
                    for pulse in self.pulses.iter().filter(|pulse| pulse.link == link) {
                        let t = (pulse.start.elapsed().as_secs_f32() / 0.65).clamp(0.0, 1.0);
                        let pos = if self.doc.port(&c.ends[0]) == Some(pulse.source) {
                            p + (q - p) * t
                        } else {
                            q + (p - q) * t
                        };
                        painter.circle_filled(pos, 5.0, Color32::YELLOW);
                    }
                }
            }
            for association in self.doc.associations() {
                let (Some(a), Some(b)) = (
                    self.doc.node(association.ap),
                    self.doc.node(association.client),
                ) else {
                    continue;
                };
                let p = screen(a.position);
                let q = screen(b.position);
                for i in 0..10 {
                    let t = i as f32 / 10.0;
                    painter.line_segment(
                        [p + (q - p) * t, p + (q - p) * (t + 0.055)],
                        Stroke::new(2.0, Color32::LIGHT_BLUE),
                    );
                }
                painter.text(
                    p + (q - p) * 0.5,
                    egui::Align2::CENTER_BOTTOM,
                    format!(
                        "Wi-Fi VLAN {} / {} dBm",
                        association.vlan, association.signal_dbm
                    ),
                    egui::FontId::proportional(10.0),
                    Color32::LIGHT_BLUE,
                );
                for pulse in self
                    .pulses
                    .iter()
                    .filter(|pulse| pulse.link == association.link)
                {
                    let t = (pulse.start.elapsed().as_secs_f32() / 0.65).clamp(0.0, 1.0);
                    let client = self.doc.port(&Endpoint {
                        node: association.client,
                        port: "eth0".into(),
                    });
                    let pos = if client == Some(pulse.source) {
                        q + (p - q) * t
                    } else {
                        p + (q - p) * t
                    };
                    painter.circle_filled(pos, 5.0, Color32::YELLOW);
                }
            }
            for n in &nodes {
                let pos = screen(n.position);
                let r = Rect::from_center_size(pos, Vec2::new(112.0, 54.0) * zoom);
                let response =
                    ui.interact(r, egui::Id::new(("node", n.id)), Sense::click_and_drag());
                node_hit |= response.hovered() || response.dragged() || response.clicked();
                let response = response.on_hover_text(
                    self.tr("Двойной щелчок — открыть CLI", "Double-click to open CLI"),
                );
                if response.double_clicked() {
                    self.open_terminal(ctx, n.id);
                }
                if response.clicked() || response.drag_started() {
                    select_action = Some(n.id);
                }
                if response.dragged() {
                    let delta = ctx.input(|i| i.pointer.delta()) / zoom;
                    move_action = Some((n.id, [n.position[0] + delta.x, n.position[1] + delta.y]));
                }
                let selected = self.selected == Some(n.id);
                let cv = painter.with_clip_rect(r.intersect(rect));
                cv.rect_filled(r, 7., theme::CARD);
                cv.rect_stroke(
                    r,
                    7.,
                    Stroke::new(
                        if selected { 2. } else { 1. },
                        if selected { theme::MINT } else { theme::BORDER },
                    ),
                    egui::StrokeKind::Inside,
                );
                theme::icon(
                    &cv,
                    n.model,
                    r.left_top() + Vec2::new(17., 19.) * zoom,
                    zoom,
                );
                cv.text(
                    r.left_top() + Vec2::new(33., 19.) * zoom,
                    egui::Align2::LEFT_CENTER,
                    &n.hostname,
                    egui::FontId::proportional(14. * zoom),
                    Color32::WHITE,
                );
                cv.text(
                    r.left_bottom() + Vec2::new(8., -12.) * zoom,
                    egui::Align2::LEFT_CENTER,
                    n.model.label(),
                    egui::FontId::proportional(10. * zoom),
                    theme::MUTED,
                );
                cv.circle_filled(
                    r.right_top() + Vec2::new(-8., 8.) * zoom,
                    3. * zoom,
                    if n.powered { theme::MINT } else { theme::OFF },
                );
            }
            if let Some(id) = select_action {
                self.select(id);
            }
            if let Some((id, p)) = move_action {
                if !self.drag_checkpoint {
                    self.drag_checkpoint = self.checkpoint();
                }
                if self.drag_checkpoint {
                    let r = self.doc.move_node(id, p);
                    self.result(r);
                }
            }
            if background.dragged() && !node_hit && self.drag_model.is_none() {
                self.pan += ctx.input(|i| i.pointer.delta());
            }
            if ctx.input(|i| i.pointer.any_released()) {
                self.drag_checkpoint = false;
                if let Some(model) = self.drag_model.take() {
                    if let Some(pos) = ctx
                        .input(|i| i.pointer.latest_pos())
                        .filter(|p| rect.contains(*p))
                    {
                        self.add(model, world(pos));
                    }
                }
            }
            if background.clicked() && !node_hit {
                if let (Some(m), Some(p)) = (self.placing.take(), background.interact_pointer_pos())
                {
                    self.add(m, world(p));
                } else {
                    self.selected = None;
                }
            }
            if ctx.input(|i| i.key_pressed(egui::Key::Escape)) {
                self.placing = None;
                self.drag_model = None;
                self.pending = None;
            }
        });
    }
    fn editor(&mut self, ctx: &egui::Context) {
        let snap = self.doc.snapshot();
        let trace = self.doc.trace();
        self.update_pulses(&trace);
        self.top(ctx, &snap);
        if self.busy {
            return;
        }
        self.catalog(ctx);
        if self.busy {
            return;
        }
        self.events(ctx, &trace.entries);
        self.properties(ctx, &snap);
        if self.busy {
            return;
        }
        self.canvas(ctx, &snap);
        self.packets(ctx);
    }
}
impl eframe::App for Studio {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        if self.worker_failed {
            egui::CentralPanel::default().show(ctx, |ui| {
                ui.heading("Simulation stopped / Симуляция остановлена");
                ui.label(&self.status);
                ui.label("Restart and reopen the last saved project. Unsaved state may be lost.");
                ui.label("Перезапустите программу и откройте последний сохранённый проект.");
            });
            return;
        }
        let now = Instant::now();
        let dt = now.duration_since(self.last);
        self.last = now;
        if self.busy {
            match self.worker.poll() {
                Ok(Some((d, r))) => {
                    self.doc = d;
                    self.busy = false;
                    if let (Some(id), Err(err)) = (self.pending_cli.take(), &r) {
                        if let Some(terminal) = self.terminals.get_mut(&id) {
                            terminal.append(&format!("% {err}"));
                        }
                    }
                    if let Some(reply) = self.result(r) {
                        match reply {
                            Reply::Done => {}
                            Reply::Grade(report) => self.lab_report = report,
                            Reply::Cli { node, output } => {
                                if let Some(terminal) = self.terminals.get_mut(&node) {
                                    terminal.append(&output);
                                }
                            }
                        }
                    }
                }
                Ok(None) => {
                    egui::CentralPanel::default().show(ctx, |ui| {
                        ui.spinner();
                        ui.label("Simulation worker");
                    });
                    self.terminal_windows(ctx);
                    ctx.request_repaint_after(Duration::from_millis(16));
                    return;
                }
                Err(e) => {
                    self.status = e;
                    self.playing = false;
                    self.busy = false;
                    self.worker_failed = true;
                    ctx.request_repaint();
                    return;
                }
            }
        }
        self.editor(ctx);
        self.terminal_windows(ctx);
        if !self.busy && self.playing && self.mode == Mode::RealTime {
            let ns = (dt.as_secs_f64().min(0.1) * 1e9 * f64::from(self.speed)) as u64;
            self.submit(Action::Advance(ns));
        }
        if self.busy || self.playing || !self.pulses.is_empty() {
            ctx.request_repaint_after(Duration::from_millis(16));
        } else {
            ctx.request_repaint_after(Duration::from_millis(150));
        }
        if let Some(frames) = self.smoke_frames.as_mut() {
            *frames += 1;
            if *frames >= 2 {
                ctx.send_viewport_cmd(egui::ViewportCommand::Close);
            } else {
                ctx.request_repaint();
            }
        }
        // Commands handled by UI panels update the next frame's immutable snapshot.
        if ctx.input(|i| i.pointer.any_released() || i.key_pressed(egui::Key::Enter)) {
            ctx.request_repaint();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use eframe::App;

    #[test]
    fn renders_wireless_lab_and_inspector_in_both_languages() {
        let mut studio = Studio::new();
        let project = netsim_storage::Project::decode(include_bytes!(
            "../../../examples/wireless-dhcp.netsim"
        ))
        .unwrap();
        studio.doc = Desktop::from_project(project).unwrap();
        studio.select(3);
        studio.inspect = true;
        let context = egui::Context::default();
        let mut frame = eframe::Frame::_new_kittest();
        for russian in [true, false] {
            studio.ru = russian;
            let output = context.run(
                egui::RawInput {
                    screen_rect: Some(Rect::from_min_size(Pos2::ZERO, Vec2::new(1200., 800.))),
                    ..Default::default()
                },
                |ctx| studio.update(ctx, &mut frame),
            );
            assert!(
                !context
                    .tessellate(output.shapes, output.pixels_per_point)
                    .is_empty()
            );
            assert_eq!(studio.doc.associations().len(), 1);
        }
    }
}
