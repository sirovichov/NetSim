use super::*;
use egui::{RichText, ViewportBuilder, ViewportClass, ViewportCommand, ViewportId};

pub(super) struct Terminal {
    name: String,
    model: Model,
    prompt: String,
    input: String,
    lines: Vec<String>,
    open: bool,
    focus_input: bool,
}

impl Terminal {
    pub(super) fn append(&mut self, text: &str) {
        self.lines.extend(
            text.lines()
                .take(200)
                .map(|line| line.chars().take(500).collect()),
        );
        self.lines.drain(..self.lines.len().saturating_sub(500));
    }

    fn show(
        &mut self,
        ui: &mut egui::Ui,
        ru: bool,
        available: bool,
        doc: &Desktop,
        id: u64,
    ) -> Option<String> {
        ui.horizontal(|ui| {
            let (rect, _) = ui.allocate_exact_size(Vec2::splat(32.), Sense::hover());
            ui.painter().rect_filled(rect, 7., theme::CARD);
            theme::icon(ui.painter(), self.model, rect.center(), 1.);
            ui.vertical(|ui| {
                ui.strong(&self.name);
                ui.small(self.model.label());
            });
        });
        ui.separator();
        let height = (ui.available_height() - 77.).max(20.);
        egui::ScrollArea::vertical()
            .id_salt(("output", id))
            .max_height(height)
            .auto_shrink([false, false])
            .stick_to_bottom(true)
            .show(ui, |ui| {
                for line in &self.lines {
                    ui.label(RichText::new(line).monospace());
                }
            });
        ui.separator();
        let mut send = false;
        ui.horizontal(|ui| {
            ui.label(RichText::new(&self.prompt).monospace().color(theme::MINT));
            let field = ui.add(
                egui::TextEdit::singleline(&mut self.input)
                    .id_salt(("command", id))
                    .font(egui::TextStyle::Monospace)
                    .desired_width(ui.available_width()),
            );
            if std::mem::take(&mut self.focus_input) {
                field.request_focus();
            }
            if field.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)) {
                send = available;
                field.request_focus();
            }
        });
        let mut help = false;
        ui.horizontal(|ui| {
            ui.add_enabled_ui(available, |ui| {
                send |= ui.button(if ru { "Выполнить" } else { "Run" }).clicked();
                help = ui
                    .button("?")
                    .on_hover_text(if ru { "Справка" } else { "Help" })
                    .clicked();
                if matches!(self.model, Model::CiscoRouter | Model::CiscoSwitch)
                    && ui.button("Tab").clicked()
                {
                    if let Some(line) = doc.completion(id, &self.input) {
                        self.input = line;
                    }
                    self.focus_input = true;
                }
            });
            if !available {
                ui.spinner();
            }
        });
        if !(help || send) {
            return None;
        }
        self.focus_input = true;
        if self.input.len() + usize::from(help) > 4096 {
            self.append(if ru {
                "Команда слишком длинная"
            } else {
                "Command too long"
            });
            return None;
        }
        let cmd = if help {
            format!("{}?", self.input)
        } else {
            std::mem::take(&mut self.input)
        };
        self.append(&format!("{} {cmd}", self.prompt));
        Some(cmd)
    }
}

impl Studio {
    fn terminal_id(id: u64) -> ViewportId {
        ViewportId::from_hash_of(("device-terminal", id))
    }

    pub(super) fn open_terminal(&mut self, ctx: &egui::Context, id: u64) {
        let Some(node) = self.doc.node(id) else {
            return;
        };
        let terminal = self.terminals.entry(id).or_insert_with(|| Terminal {
            name: node.hostname.clone(),
            model: node.model,
            prompt: String::new(),
            input: String::new(),
            lines: Vec::new(),
            open: false,
            focus_input: false,
        });
        if terminal.open {
            ctx.send_viewport_cmd_to(Self::terminal_id(id), ViewportCommand::Minimized(false));
            ctx.send_viewport_cmd_to(Self::terminal_id(id), ViewportCommand::Focus);
        }
        terminal.open = true;
        terminal.focus_input = true;
    }

    pub(super) fn terminal_windows(&mut self, ctx: &egui::Context) {
        let mut command = None;
        for (&id, terminal) in &mut self.terminals {
            if !terminal.open {
                continue;
            }
            let available = !self.busy && command.is_none();
            if !self.busy {
                if let Some(node) = self.doc.node(id) {
                    terminal.name.clone_from(&node.hostname);
                }
                terminal.prompt = self.doc.prompt(id).unwrap_or_default();
            }
            let title = format!("{} · CLI | NetSim Studio", terminal.name);
            let builder = ViewportBuilder::default()
                .with_title(&title)
                .with_inner_size([640., 420.])
                .with_min_inner_size([360., 230.]);
            let viewport = Self::terminal_id(id);
            ctx.show_viewport_immediate(viewport, builder, |child, class| {
                let mut open = true;
                let mut content = |ui: &mut egui::Ui| {
                    if let Some(line) = terminal.show(ui, self.ru, available, &self.doc, id) {
                        command = Some(Action::Cli { node: id, line });
                    }
                };
                if class == ViewportClass::Embedded {
                    egui::Window::new(&title)
                        .id(viewport.0)
                        .open(&mut open)
                        .show(child, content);
                } else {
                    open = !child.input(|i| i.viewport().close_requested());
                    egui::CentralPanel::default()
                        .frame(egui::Frame::new().fill(theme::CANVAS).inner_margin(14))
                        .show(child, &mut content);
                }
                terminal.open = open;
            });
        }
        if let Some(action) = command {
            self.submit(action);
            ctx.request_repaint();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_model_has_an_independent_reopenable_console() {
        let mut studio = Studio::new();
        let ctx = egui::Context::default();
        let mut ids = Vec::new();
        for model in Model::ALL {
            let id = studio.doc.add(model, [0., 0.]).unwrap();
            studio.open_terminal(&ctx, id);
            let term = studio.terminals.get_mut(&id).unwrap();
            assert_eq!(term.model, model);
            term.input = model.label().into();
            term.append(&format!("console {id}"));
            term.open = false;
            ids.push(id);
        }
        for id in ids {
            studio.open_terminal(&ctx, id);
            let term = &studio.terminals[&id];
            assert!(term.open);
            assert_eq!(term.input, term.model.label());
            assert_eq!(term.lines, [format!("console {id}")]);
        }
        studio.clear_ui();
        assert!(studio.terminals.is_empty());
    }
}
