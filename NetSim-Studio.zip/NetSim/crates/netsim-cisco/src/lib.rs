//! Cisco profile identities and educational IOS console.
pub mod ios;

use netsim_devices::DeviceDescriptor;

pub const PROFILES: &[DeviceDescriptor] = &[
    DeviceDescriptor {
        profile_id: "cisco.router.2911",
        profile_version: 1,
        vendor: "Cisco",
        model: "2911",
        firmware_reference: None,
    },
    DeviceDescriptor {
        profile_id: "cisco.switch.2960",
        profile_version: 1,
        vendor: "Cisco",
        model: "Catalyst 2960",
        firmware_reference: None,
    },
];
