use netsim_core::{MacAddress, PortId};
use netsim_engine::{InterfaceConfig, InterfaceKey, Ipv4Prefix, PortMode, Route, RouteOrigin};
use std::collections::{BTreeMap, BTreeSet};
use std::net::Ipv4Addr;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Model {
    Catalyst2960,
    Isr2911,
}

impl Model {
    pub fn profile(self) -> &'static str {
        match self {
            Self::Catalyst2960 => "cisco.switch.2960",
            Self::Isr2911 => "cisco.router.2911",
        }
    }
    pub fn is_switch(self) -> bool {
        self == Self::Catalyst2960
    }
    pub fn port_names(self) -> Vec<String> {
        if self.is_switch() {
            (1..=24)
                .map(|n| format!("FastEthernet0/{n}"))
                .chain((1..=2).map(|n| format!("GigabitEthernet0/{n}")))
                .collect()
        } else {
            (0..=2).map(|n| format!("GigabitEthernet0/{n}")).collect()
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Interface {
    pub port: PortId,
    pub parent: Option<String>,
    pub mac: MacAddress,
    pub shutdown: bool,
    pub description: String,
    pub ip: Option<(Ipv4Addr, u8)>,
    pub dot1q: Option<u16>,
    pub trunk: bool,
    pub access: u16,
    pub native: u16,
    pub allowed: BTreeSet<u16>,
}

impl Interface {
    pub fn new(port: PortId, mac: MacAddress, shutdown: bool) -> Self {
        Self {
            port,
            parent: None,
            mac,
            shutdown,
            description: String::new(),
            ip: None,
            dot1q: None,
            trunk: false,
            access: 1,
            native: 1,
            allowed: (1..=4094).collect(),
        }
    }
    pub fn mode(&self, vlans: &BTreeMap<u16, String>) -> PortMode {
        if self.trunk {
            PortMode::Trunk {
                native: Some(self.native),
                allowed: self
                    .allowed
                    .iter()
                    .filter(|v| vlans.contains_key(v))
                    .copied()
                    .collect(),
            }
        } else if vlans.contains_key(&self.access) {
            PortMode::Access(self.access)
        } else {
            PortMode::Trunk {
                native: None,
                allowed: BTreeSet::new(),
            }
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct StaticRoute {
    pub prefix: Ipv4Prefix,
    pub next_hop: Ipv4Addr,
    pub distance: u8,
}

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Config {
    pub hostname: String,
    pub interfaces: BTreeMap<String, Interface>,
    pub vlans: BTreeMap<u16, String>,
    pub routes: Vec<StaticRoute>,
}

pub fn mask(len: u8) -> Ipv4Addr {
    Ipv4Addr::from(if len == 0 { 0 } else { u32::MAX << (32 - len) })
}
pub fn prefix_len(text: &str) -> Option<u8> {
    let n = u32::from(text.parse::<Ipv4Addr>().ok()?);
    let len = n.leading_ones() as u8;
    (u32::from(mask(len)) == n).then_some(len)
}
pub fn vlan_id(text: &str) -> Option<u16> {
    text.parse::<u16>().ok().filter(|v| (1..=4094).contains(v))
}
pub fn vlan_list(text: &str) -> Option<BTreeSet<u16>> {
    let mut out = BTreeSet::new();
    for piece in text.split(',') {
        if let Some((lo, hi)) = piece.split_once('-') {
            let (lo, hi) = (vlan_id(lo)?, vlan_id(hi)?);
            if lo > hi {
                return None;
            }
            out.extend(lo..=hi);
        } else {
            out.insert(vlan_id(piece)?);
        }
    }
    Some(out)
}
pub fn list_text(list: &BTreeSet<u16>) -> String {
    let mut iter = list.iter().copied().peekable();
    let mut parts = Vec::new();
    while let Some(lo) = iter.next() {
        let mut hi = lo;
        while iter.peek() == Some(&(hi + 1)) {
            hi = iter.next().unwrap_or(hi);
        }
        parts.push(if lo == hi {
            lo.to_string()
        } else {
            format!("{lo}-{hi}")
        });
    }
    if parts.is_empty() {
        "none".into()
    } else {
        parts.join(",")
    }
}

impl Config {
    /// Only directly reachable next hops are installed; unresolved routes remain configured.
    pub fn router_data(&self) -> Result<(Vec<InterfaceConfig>, Vec<Route>), &'static str> {
        let mut interfaces = Vec::new();
        for i in self.interfaces.values() {
            let Some((address, prefix_len)) = i.ip else {
                continue;
            };
            if i.parent.is_some() && i.dot1q.is_none() {
                continue;
            }
            let config = InterfaceConfig {
                key: InterfaceKey {
                    port: i.port,
                    vlan: i.dot1q,
                },
                address,
                prefix_len,
                mac: i.mac,
            };
            if !config.valid() {
                return Err("Invalid IP address or mask");
            }
            if i.parent.is_some() && i.shutdown {
                continue;
            }
            interfaces.push(config);
        }
        let mut routes = Vec::new();
        for r in &self.routes {
            if let Some(i) = interfaces
                .iter()
                .filter(|i| {
                    i.address != r.next_hop
                        && i.prefix()
                            .is_some_and(|p| netsim_protocols::routing::usable(p, r.next_hop))
                })
                .min_by_key(|i| (std::cmp::Reverse(i.prefix_len), i.key))
            {
                routes.push(Route {
                    prefix: r.prefix,
                    interface: i.key,
                    next_hop: Some(r.next_hop),
                    distance: r.distance,
                    metric: 0,
                    origin: RouteOrigin::Static,
                });
            }
        }
        Ok((interfaces, routes))
    }

    pub fn render(&self, model: Model) -> String {
        let mut lines = vec![
            "!".into(),
            format!("hostname {}", self.hostname),
            "!".into(),
        ];
        if model.is_switch() {
            for (v, name) in self.vlans.iter().filter(|(v, _)| **v != 1) {
                lines.extend([format!("vlan {v}"), format!(" name {name}"), "!".into()]);
            }
        }
        for (name, i) in &self.interfaces {
            lines.push(format!("interface {name}"));
            if !i.description.is_empty() {
                lines.push(format!(" description {}", i.description));
            }
            if model.is_switch() {
                lines.push(format!(" switchport access vlan {}", i.access));
                lines.push(format!(" switchport trunk native vlan {}", i.native));
                lines.push(format!(
                    " switchport trunk allowed vlan {}",
                    list_text(&i.allowed)
                ));
                lines.push(format!(
                    " switchport mode {}",
                    if i.trunk { "trunk" } else { "access" }
                ));
            } else {
                if let Some(v) = i.dot1q {
                    lines.push(format!(" encapsulation dot1Q {v}"));
                }
                if let Some((ip, len)) = i.ip {
                    lines.push(format!(" ip address {ip} {}", mask(len)));
                }
            }
            lines.push(if i.shutdown {
                " shutdown".into()
            } else {
                " no shutdown".into()
            });
            lines.push("!".into());
        }
        for r in &self.routes {
            lines.push(format!(
                "ip route {} {} {} {}",
                r.prefix.network(),
                mask(r.prefix.length()),
                r.next_hop,
                r.distance
            ));
        }
        lines.push("end".into());
        lines.join("\n")
    }
}

impl Config {
    /// Imported configurations are data, never executed as console commands.
    pub(crate) fn remap(mut self, factory: &Config, model: Model) -> Result<Self, String> {
        let valid_vlan = |v: u16| (1..=4094).contains(&v);
        if self.hostname.is_empty()
            || self.hostname.len() > 63
            || !self
                .hostname
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
            || self.interfaces.len() > 256
            || self.routes.len() > 4096
            || !self.vlans.contains_key(&1)
            || self
                .vlans
                .iter()
                .any(|(v, n)| !valid_vlan(*v) || n.len() > 128 || n.chars().any(char::is_control))
            || factory
                .interfaces
                .keys()
                .any(|name| self.interfaces.get(name).is_none_or(|i| i.parent.is_some()))
        {
            return Err("Invalid saved configuration".into());
        }
        let mut tags = BTreeSet::new();
        let mut addresses = BTreeSet::new();
        for (name, i) in &mut self.interfaces {
            let physical = if let Some(parent) = &i.parent {
                if model.is_switch()
                    || !name.starts_with(&format!("{parent}."))
                    || name
                        .rsplit_once('.')
                        .and_then(|(_, v)| v.parse::<u16>().ok())
                        .is_none_or(|v| !valid_vlan(v))
                    || i.dot1q
                        .is_some_and(|v| !valid_vlan(v) || !tags.insert((parent.clone(), v)))
                {
                    return Err("Invalid saved subinterface".into());
                }
                factory.interfaces.get(parent)
            } else {
                if i.dot1q.is_some() {
                    return Err("Invalid physical VLAN tag".into());
                }
                factory.interfaces.get(name)
            }
            .ok_or("Unknown saved physical port")?;
            i.port = physical.port;
            i.mac = physical.mac;
            if !valid_vlan(i.access)
                || !valid_vlan(i.native)
                || i.allowed.iter().any(|v| !valid_vlan(*v))
                || i.description.len() > 4096
                || i.description.chars().any(char::is_control)
                || (model.is_switch() && i.ip.is_some())
            {
                return Err("Invalid saved interface".into());
            }
            if let Some((ip, len)) = i.ip {
                if len > 32
                    || !addresses.insert(ip)
                    || !(InterfaceConfig {
                        key: InterfaceKey {
                            port: i.port,
                            vlan: i.dot1q,
                        },
                        address: ip,
                        prefix_len: len,
                        mac: i.mac,
                    })
                    .valid()
                {
                    return Err("Invalid saved address".into());
                }
            }
        }
        if self.routes.iter().any(|r| {
            r.distance == 0 || r.distance == 255 || !netsim_protocols::routing::unicast(r.next_hop)
        }) || (model.is_switch() && !self.routes.is_empty())
        {
            return Err("Invalid saved route".into());
        }
        self.router_data().map_err(str::to_owned)?;
        Ok(self)
    }
}
