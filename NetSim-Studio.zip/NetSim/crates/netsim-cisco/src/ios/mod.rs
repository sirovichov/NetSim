//! Independent educational IOS console; no vendor firmware or host networking.
mod config;
pub mod parser;
pub use config::Model;
use config::{Config, Interface, StaticRoute, list_text, prefix_len, vlan_id, vlan_list};
use netsim_core::{DeviceId, EngineError, MacAddress, MediaKind, PortId, PowerState, SessionId};
use netsim_engine::{Engine, Ipv4Prefix, ProbeStatus, RouteOrigin};
use parser::{Mode, ParseError};
use std::collections::BTreeMap;
use std::fmt::Write as _;
use std::net::Ipv4Addr;

const SEC: u64 = 1_000_000_000;
const MAX_SESSIONS: usize = 64;

#[derive(Clone, Debug)]
struct Session {
    mode: Mode,
    interface: Option<String>,
    vlan: Option<u16>,
    history: Vec<String>,
}
impl Default for Session {
    fn default() -> Self {
        Self {
            mode: Mode::User,
            interface: None,
            vlan: None,
            history: Vec::new(),
        }
    }
}

pub struct CiscoDevice {
    id: DeviceId,
    model: Model,
    running: Config,
    factory: Config,
    startup: Option<Config>,
    sessions: BTreeMap<SessionId, Session>,
}

fn ip(s: &str) -> Result<Ipv4Addr, &'static str> {
    s.parse().map_err(|_| "Invalid IPv4 address")
}
fn vid(s: &str) -> Result<u16, &'static str> {
    vlan_id(s).ok_or("Invalid VLAN ID")
}
fn mask_len(s: &str) -> Result<u8, &'static str> {
    prefix_len(s).ok_or("Invalid subnet mask")
}
fn name_valid(s: &str) -> bool {
    !s.is_empty()
        && s.len() <= 63
        && s.bytes()
            .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
}
fn mac(port: PortId) -> MacAddress {
    let b = port.0.to_be_bytes();
    MacAddress([2, 0x43, b[4], b[5], b[6], b[7]])
}
fn invalid(e: &str) -> String {
    format!("% {e}")
}

impl CiscoDevice {
    /// Allocate physical ports and attach the existing L2/L3 components.
    /// Existing low-level draft-device factory is deliberately unchanged.
    pub fn create(engine: &mut Engine, model: Model, hostname: &str) -> Result<Self, EngineError> {
        if !name_valid(hostname) {
            return Err(EngineError::InvalidInput);
        }
        let id = engine.add_device(model.profile(), 1, hostname.into())?;
        let result = (|| {
            let mut interfaces = BTreeMap::new();
            for name in model.port_names() {
                let port = engine.add_port(id, MediaKind::Ethernet)?;
                interfaces.insert(name, Interface::new(port, mac(port), !model.is_switch()));
            }
            if model.is_switch() {
                let b = id.0.to_be_bytes();
                engine.configure_switch(
                    id,
                    32768,
                    MacAddress([2, 0x42, b[4], b[5], b[6], b[7]]),
                )?;
                for i in interfaces.values() {
                    engine.configure_switch_port(id, i.port, netsim_engine::PortMode::Access(1))?;
                }
            } else {
                engine.configure_router(id)?;
                for i in interfaces.values() {
                    engine.set_port_admin(i.port, false)?;
                }
            }
            let config = Config {
                hostname: hostname.into(),
                interfaces,
                vlans: [(1, "default".into())].into_iter().collect(),
                routes: Vec::new(),
            };
            engine.power_on(id)?;
            Ok(Self {
                id,
                model,
                factory: config.clone(),
                running: config,
                startup: None,
                sessions: BTreeMap::new(),
            })
        })();
        if result.is_err() {
            let _ = engine.remove_device(id);
        }
        result
    }

    pub fn export_config(&self) -> serde_json::Value {
        serde_json::json!({"running": self.running, "startup": self.startup})
    }
    /// Only for freshly created devices while opening a new project.
    pub fn import_config(
        &mut self,
        engine: &mut Engine,
        value: serde_json::Value,
    ) -> Result<(), String> {
        #[derive(serde::Deserialize)]
        #[serde(deny_unknown_fields)]
        struct Saved {
            running: Config,
            startup: Option<Config>,
        }
        let s: Saved = serde_json::from_value(value).map_err(|e| e.to_string())?;
        let running = s.running.remap(&self.factory, self.model)?;
        let startup = s
            .startup
            .map(|c| c.remap(&self.factory, self.model))
            .transpose()?;
        self.commit(engine, running)?;
        self.startup = startup;
        self.sessions.clear();
        Ok(())
    }
    pub fn id(&self) -> DeviceId {
        self.id
    }
    pub fn port(&self, name: &str) -> Option<PortId> {
        self.resolve_interface(name)
            .and_then(|n| self.running.interfaces.get(&n))
            .map(|i| i.port)
    }
    pub fn prompt(&self, session: SessionId) -> String {
        let mode = self.sessions.get(&session).map_or(Mode::User, |s| s.mode);
        format!(
            "{}{}",
            self.running.hostname,
            match mode {
                Mode::User => ">",
                Mode::Privileged => "#",
                Mode::Global => "(config)#",
                Mode::Interface => "(config-if)#",
                Mode::Vlan => "(config-vlan)#",
            }
        )
    }
    pub fn running_config(&self) -> String {
        self.running.render(self.model)
    }
    pub fn startup_config(&self) -> Option<String> {
        self.startup.as_ref().map(|c| c.render(self.model))
    }
    pub fn close_session(&mut self, session: SessionId) {
        self.sessions.remove(&session);
    }

    fn resolve_interface(&self, input: &str) -> Option<String> {
        let input = input.to_ascii_lowercase();
        let (kind, suffix) = input.split_at(input.find(|c: char| c.is_ascii_digit())?);
        if kind.is_empty() {
            return None;
        }
        let mut matches = self.running.interfaces.keys().filter(|name| {
            let full = name.to_ascii_lowercase();
            full.find(|c: char| c.is_ascii_digit())
                .is_some_and(|n| full[..n].starts_with(kind) && &full[n..] == suffix)
        });
        let name = matches.next()?.clone();
        if matches.next().is_some() {
            None
        } else {
            Some(name)
        }
    }

    /// Suggestions are context-sensitive; interface arguments expand to real port names.
    pub fn complete(&self, session: SessionId, line: &str) -> Vec<String> {
        let mode = self.sessions.get(&session).map_or(Mode::User, |s| s.mode);
        let mut choices = parser::complete(mode, self.model.is_switch(), line);
        if choices.iter().any(|c| c == "<interface>") {
            let fragment = if line.ends_with(char::is_whitespace) {
                ""
            } else {
                line.split_whitespace().last().unwrap_or("")
            };
            let fragment = fragment.to_ascii_lowercase();
            let mut names: Vec<_> = self
                .running
                .interfaces
                .keys()
                .filter(|n| {
                    let lower = n.to_ascii_lowercase();
                    if lower.starts_with(&fragment) {
                        return true;
                    }
                    let Some(i) = fragment.find(|c: char| c.is_ascii_digit()) else {
                        return false;
                    };
                    let Some(j) = lower.find(|c: char| c.is_ascii_digit()) else {
                        return false;
                    };
                    lower[..j].starts_with(&fragment[..i]) && lower[j..].starts_with(&fragment[i..])
                })
                .cloned()
                .collect();
            if !names.is_empty() {
                choices.retain(|c| c != "<interface>");
                choices.append(&mut names);
            }
        }
        choices
    }

    /// Return a completed line when the current fragment has one literal match.
    pub fn complete_line(&self, session: SessionId, line: &str) -> Option<String> {
        let options = self.complete(session, line);
        let mut literals = options.iter().filter(|s| !s.starts_with('<'));
        let word = literals.next()?;
        if literals.next().is_some() {
            return None;
        }
        let offset = line.rfind(char::is_whitespace).map_or(0, |i| {
            i + line[i..].chars().next().map_or(0, char::len_utf8)
        });
        Some(format!("{}{word} ", &line[..offset]))
    }

    /// A management command is applied at the current virtual event boundary.
    /// Session state belongs to the console; forwarding state belongs to Engine.
    pub fn execute(&mut self, engine: &mut Engine, session: SessionId, line: &str) -> String {
        if line.len() > 4096 {
            return invalid("Command too long");
        }
        if !engine
            .snapshot()
            .devices
            .iter()
            .any(|d| d.id == self.id && d.power == PowerState::On)
        {
            return invalid("Device is powered off or removed");
        }
        if line.trim().is_empty() {
            return String::new();
        }
        if line.trim().eq_ignore_ascii_case("help") {
            return self.complete(session, "").join("\n");
        }
        if line.chars().any(|c| c.is_control() && c != '\t') {
            return invalid("Invalid control character");
        }
        if let Some(prefix) = line.strip_suffix('?') {
            return self.complete(session, prefix).join("\n");
        }
        if let Some(prefix) = line.strip_suffix('\t') {
            return self
                .complete_line(session, prefix)
                .unwrap_or_else(|| self.complete(session, prefix).join("\n"));
        }
        if !self.sessions.contains_key(&session) && self.sessions.len() >= MAX_SESSIONS {
            return invalid("Too many console sessions");
        }
        let mut state = self.sessions.remove(&session).unwrap_or_default();
        let line = line.trim();
        if state.history.len() == 100 {
            state.history.remove(0);
        }
        state.history.push(line.into());
        // IOS accepts a space between type and number; normalize before parsing.
        let mut words: Vec<_> = line.split_whitespace().collect();
        let do_exec = matches!(state.mode, Mode::Global | Mode::Interface | Mode::Vlan)
            && words.first().is_some_and(|w| w.eq_ignore_ascii_case("do"));
        if do_exec {
            words.remove(0);
        }
        let mut normalized = words.join(" ");
        for (index, word) in words.iter().enumerate() {
            if index > 0
                && "interfaces".starts_with(&words[index - 1].to_ascii_lowercase())
                && words
                    .get(index + 1)
                    .is_some_and(|n| n.chars().next().is_some_and(|c| c.is_ascii_digit()))
                && word.chars().all(|c| c.is_ascii_alphabetic())
            {
                let mut joined = words[..index].join(" ");
                joined.push(' ');
                joined.push_str(word);
                joined.push_str(words[index + 1]);
                if index + 2 < words.len() {
                    joined.push(' ');
                    joined.push_str(&words[index + 2..].join(" "));
                }
                normalized = joined;
                break;
            }
        }
        let mode = if do_exec {
            Mode::Privileged
        } else {
            state.mode
        };
        let mut parsed = parser::parse(mode, self.model.is_switch(), &normalized);
        // Description is a free-text tail.
        if mode == Mode::Interface
            && words.len() > 2
            && "description".starts_with(&words[0].to_ascii_lowercase())
        {
            parsed = Ok(vec!["description".into(), words[1..].join(" ")]);
        }
        let result = match parsed {
            Ok(cmd)
                if do_exec
                    && !matches!(
                        cmd.first().map(String::as_str),
                        Some("show" | "ping" | "traceroute")
                    ) =>
            {
                invalid("Only show, ping and traceroute are supported with do")
            }
            Ok(cmd) => self
                .apply(engine, &mut state, &cmd)
                .unwrap_or_else(|e| invalid(&e)),
            Err(ParseError::Ambiguous) => invalid("Ambiguous command"),
            Err(ParseError::Incomplete) => invalid("Incomplete command."),
            Err(ParseError::Invalid) => invalid("Invalid input detected."),
        };
        self.sessions.insert(session, state);
        result
    }

    fn commit(&mut self, engine: &mut Engine, candidate: Config) -> Result<(), String> {
        // Reject missing physical ports before any mutation.
        let snap = engine.snapshot();
        if candidate.interfaces.values().any(|i| {
            !snap
                .ports
                .iter()
                .any(|p| p.id == i.port && p.device == self.id)
        }) {
            return Err("Missing physical port".into());
        }
        if self.model.is_switch() {
            for (name, i) in &candidate.interfaces {
                let mode = i.mode(&candidate.vlans);
                if self
                    .running
                    .interfaces
                    .get(name)
                    .is_none_or(|old| old.mode(&self.running.vlans) != mode)
                {
                    engine
                        .set_switch_port_mode(self.id, i.port, mode)
                        .map_err(|e| e.to_string())?;
                }
            }
        } else {
            let mut keys = std::collections::BTreeSet::new();
            let mut addresses = std::collections::BTreeSet::new();
            for i in candidate.interfaces.values() {
                if let Some(v) = i.dot1q {
                    if !keys.insert((i.port, v)) {
                        return Err("Duplicate dot1Q encapsulation on parent".into());
                    }
                }
                if let Some((address, _)) = i.ip {
                    if !addresses.insert(address) {
                        return Err("Duplicate local IP address".into());
                    }
                }
            }
            let data = candidate.router_data().map_err(str::to_owned)?;
            let old = self.running.router_data().map_err(str::to_owned)?;
            if data != old {
                engine
                    .replace_router_config(self.id, &data.0, &data.1)
                    .map_err(|e| e.to_string())?;
            }
        }
        for i in candidate.interfaces.values().filter(|i| i.parent.is_none()) {
            engine
                .set_port_admin(i.port, !i.shutdown)
                .map_err(|e| e.to_string())?;
        }
        engine
            .set_hostname(self.id, candidate.hostname.clone())
            .map_err(|e| e.to_string())?;
        self.running = candidate;
        Ok(())
    }

    fn apply(
        &mut self,
        engine: &mut Engine,
        state: &mut Session,
        cmd: &[String],
    ) -> Result<String, String> {
        let args: Vec<_> = cmd.iter().map(String::as_str).collect();
        let a = args.as_slice();
        match a {
            ["enable"] => state.mode = Mode::Privileged,
            ["disable"] => state.mode = Mode::User,
            ["configure", "terminal"] => {
                state.mode = Mode::Global;
                return Ok("Enter configuration commands, one per line. End with CNTL/Z.".into());
            }
            ["end"] => {
                state.mode = Mode::Privileged;
                state.interface = None;
                state.vlan = None;
            }
            ["exit"] => {
                state.mode = match state.mode {
                    Mode::Interface | Mode::Vlan => Mode::Global,
                    Mode::Global => Mode::Privileged,
                    _ => Mode::User,
                };
                state.interface = None;
                state.vlan = None;
            }
            ["copy", "running-config", "startup-config"] | ["write", "memory"] => {
                self.startup = Some(self.running.clone());
                return Ok("Building configuration...\n[OK]".into());
            }
            ["erase", "startup-config"] => {
                self.startup = None;
                return Ok("Startup configuration erased.".into());
            }
            ["reload"] => {
                let config = self.startup.clone().unwrap_or_else(|| self.factory.clone());
                self.commit(engine, config)?;
                engine.power_off(self.id).map_err(|e| e.to_string())?;
                engine.power_on(self.id).map_err(|e| e.to_string())?;
                self.sessions.clear();
                *state = Session::default();
                return Ok("Reload complete.".into());
            }
            ["show", ..] => return self.show(engine, state, a),
            ["ping", target] => {
                if self.model.is_switch() {
                    return Err("Switch SVI is not implemented in this release".into());
                }
                let target = ip(target)?;
                let mut result = String::new();
                let mut successes = 0;
                for _ in 0..5 {
                    let token = engine
                        .ping(self.id, target, 64, 2 * SEC)
                        .map_err(|e| e.to_string())?;
                    let deadline = engine
                        .now()
                        .checked_add(2 * SEC)
                        .ok_or("Virtual time overflow")?;
                    let report = engine
                        .run_until(deadline, 100_000)
                        .map_err(|e| e.to_string())?;
                    if report.faulted || report.budget_exhausted {
                        return Err("Simulation budget exhausted or faulted".into());
                    }
                    match engine.probe(self.id, token).map(|p| p.status) {
                        Some(ProbeStatus::Reply { .. }) => {
                            result.push('!');
                            successes += 1;
                        }
                        Some(ProbeStatus::Unreachable { .. } | ProbeStatus::NoRoute) => {
                            result.push('U')
                        }
                        _ => result.push('.'),
                    }
                }
                return Ok(format!(
                    "Sending 5 ICMP Echos to {target}:\n{result}\nSuccess rate is {} percent ({successes}/5)",
                    successes * 20
                ));
            }
            ["traceroute", target] => {
                if self.model.is_switch() {
                    return Err("Switch SVI is not implemented in this release".into());
                }
                let hops = engine
                    .traceroute(self.id, ip(target)?, 30, 2 * SEC, 100_000)
                    .map_err(|e| e.to_string())?;
                return Ok(hops
                    .iter()
                    .map(|p| format!("{} {:?}", p.ttl, p.status))
                    .collect::<Vec<_>>()
                    .join("\n"));
            }
            ["interface", input] => {
                let name = if let Some(name) = self.resolve_interface(input) {
                    name
                } else if !self.model.is_switch() {
                    let (parent, suffix) = input.rsplit_once('.').ok_or("Invalid interface")?;
                    let parent = self.resolve_interface(parent).ok_or("Invalid interface")?;
                    let number: u32 = suffix.parse().map_err(|_| "Invalid subinterface")?;
                    if number == 0 || number > 4_294_967 {
                        return Err("Invalid subinterface".into());
                    }
                    let name = format!("{parent}.{number}");
                    let mut candidate = self.running.clone();
                    if candidate.interfaces.len() >= 256 {
                        return Err("Interface limit reached".into());
                    }
                    let mut i = candidate.interfaces[&parent].clone();
                    if i.parent.is_some() {
                        return Err("Invalid parent interface".into());
                    }
                    i.parent = Some(parent);
                    i.ip = None;
                    i.dot1q = None;
                    i.shutdown = false;
                    i.description.clear();
                    candidate.interfaces.insert(name.clone(), i);
                    self.commit(engine, candidate)?;
                    name
                } else {
                    return Err("Invalid interface".into());
                };
                state.interface = Some(name);
                state.mode = Mode::Interface;
            }
            ["vlan", value] => {
                let v = vid(value)?;
                let mut candidate = self.running.clone();
                candidate
                    .vlans
                    .entry(v)
                    .or_insert_with(|| format!("VLAN{v:04}"));
                self.commit(engine, candidate)?;
                state.vlan = Some(v);
                state.mode = Mode::Vlan;
            }
            _ => {
                let mut c = self.running.clone();
                match a {
                    ["hostname", name] => {
                        if !name_valid(name) {
                            return Err("Invalid hostname".into());
                        }
                        c.hostname = (*name).into();
                    }
                    ["no", "vlan", value] => {
                        let v = vid(value)?;
                        if v == 1 {
                            return Err("Cannot delete default VLAN".into());
                        }
                        c.vlans.remove(&v);
                    }
                    ["name", name] if name_valid(name) => {
                        let v = state.vlan.ok_or("No VLAN selected")?;
                        if v == 1 {
                            return Err("Cannot rename default VLAN".into());
                        }
                        *c.vlans.get_mut(&v).ok_or("VLAN does not exist")? = (*name).into();
                    }
                    ["ip", "route", ..] | ["no", "ip", "route", ..] => {
                        let no = a[0] == "no";
                        let start = if no { 3 } else { 2 };
                        let address = ip(a[start])?;
                        let prefix = Ipv4Prefix::new(address, mask_len(a[start + 1])?)
                            .ok_or("Invalid prefix")?;
                        if prefix.network() != address {
                            return Err("Inconsistent address and mask".into());
                        }
                        let next_hop = ip(a[start + 2])?;
                        if !netsim_protocols::routing::unicast(next_hop) {
                            return Err("Invalid next hop".into());
                        }
                        let distance: u8 = a
                            .get(start + 3)
                            .map_or(Ok(1), |s| s.parse())
                            .map_err(|_| "Invalid distance")?;
                        if distance == 0 || distance == 255 {
                            return Err("Invalid distance".into());
                        }
                        let route = StaticRoute {
                            prefix,
                            next_hop,
                            distance,
                        };
                        if no {
                            c.routes.retain(|r| *r != route);
                        } else if !c.routes.contains(&route) {
                            if c.routes.len() >= 4096 {
                                return Err("Route limit reached".into());
                            }
                            c.routes.push(route);
                        }
                    }
                    _ => {
                        let name = state
                            .interface
                            .as_ref()
                            .ok_or("Invalid configuration command")?;
                        let i = c
                            .interfaces
                            .get_mut(name)
                            .ok_or("Interface no longer exists")?;
                        match a {
                            ["shutdown"] => i.shutdown = true,
                            ["no", "shutdown"] => i.shutdown = false,
                            ["description", text] => i.description = (*text).into(),
                            ["no", "description"] => i.description.clear(),
                            ["ip", "address", address, mask] => {
                                if i.parent.is_some() && i.dot1q.is_none() {
                                    return Err("Configure encapsulation dot1Q first".into());
                                }
                                let address = ip(address)?;
                                let len = mask_len(mask)?;
                                let config = netsim_engine::InterfaceConfig {
                                    key: netsim_engine::InterfaceKey {
                                        port: i.port,
                                        vlan: i.dot1q,
                                    },
                                    address,
                                    prefix_len: len,
                                    mac: i.mac,
                                };
                                if !config.valid() {
                                    return Err("Invalid IP address or mask".into());
                                }
                                i.ip = Some((address, len));
                            }
                            ["no", "ip", "address"] => i.ip = None,
                            ["encapsulation", "dot1q", value] if i.parent.is_some() => {
                                i.dot1q = Some(vid(value)?)
                            }
                            ["switchport", "mode", "access"] => i.trunk = false,
                            ["switchport", "mode", "trunk"] => i.trunk = true,
                            ["switchport", "access", "vlan", value] => {
                                i.access = vid(value)?;
                                c.vlans
                                    .entry(i.access)
                                    .or_insert_with(|| format!("VLAN{:04}", i.access));
                            }
                            ["switchport", "trunk", "native", "vlan", value] => {
                                i.native = vid(value)?
                            }
                            ["switchport", "trunk", "allowed", "vlan", "all"]
                            | ["no", "switchport", "trunk", "allowed", "vlan"] => {
                                i.allowed = (1..=4094).collect()
                            }
                            ["switchport", "trunk", "allowed", "vlan", "none"] => i.allowed.clear(),
                            ["switchport", "trunk", "allowed", "vlan", values] => {
                                i.allowed = vlan_list(values).ok_or("Invalid VLAN list")?
                            }
                            ["switchport", "trunk", "allowed", "vlan", "add", values] => i
                                .allowed
                                .extend(vlan_list(values).ok_or("Invalid VLAN list")?),
                            ["switchport", "trunk", "allowed", "vlan", "remove", values] => {
                                let remove = vlan_list(values).ok_or("Invalid VLAN list")?;
                                i.allowed.retain(|v| !remove.contains(v));
                            }
                            _ => return Err("Invalid configuration command".into()),
                        }
                    }
                }
                self.commit(engine, c)?;
            }
        }
        Ok(String::new())
    }

    fn show(&self, engine: &Engine, state: &Session, a: &[&str]) -> Result<String, String> {
        let snap = engine.snapshot();
        let bridge = snap
            .l2
            .switches
            .iter()
            .find(|(id, _)| *id == self.id)
            .map(|(_, b)| b);
        let node = snap.l3.nodes.iter().find(|n| n.device == self.id);
        let name_for = |port| {
            self.running
                .interfaces
                .iter()
                .find(|(_, i)| i.port == port && i.parent.is_none())
                .map_or("?", |(n, _)| n.as_str())
        };
        let mut out = String::new();
        match a {
            ["show", "running-config"] => {
                return Ok(format!(
                    "Building configuration...\n{}",
                    self.running_config()
                ));
            }
            ["show", "startup-config"] => {
                return Ok(self
                    .startup_config()
                    .unwrap_or_else(|| "startup-config is not present".into()));
            }
            ["show", "history"] => return Ok(state.history.join("\n")),
            ["show", "version"] => {
                return Ok(format!(
                    "NetSim Studio educational IOS-like simulation\nCisco {}\nNot an original Cisco IOS image",
                    if self.model.is_switch() {
                        "Catalyst 2960"
                    } else {
                        "ISR 2911"
                    }
                ));
            }
            ["show", "ip", "interface", "brief"]
            | ["show", "interfaces"]
            | ["show", "interfaces", _]
                if a != ["show", "interfaces", "trunk"] =>
            {
                let selected = if a.len() == 3 {
                    Some(self.resolve_interface(a[2]).ok_or("Invalid interface")?)
                } else {
                    None
                };
                let _ = writeln!(
                    out,
                    "{:<28} {:<15} {:<24} Protocol",
                    "Interface", "IP-Address", "Status"
                );
                for (n, i) in self
                    .running
                    .interfaces
                    .iter()
                    .filter(|(n, _)| selected.as_ref().is_none_or(|s| *n == s))
                {
                    let admin = !i.shutdown && engine.port_admin_up(i.port);
                    let up = admin && engine.port_oper_up(i.port);
                    let _ = writeln!(
                        out,
                        "{n:<28} {:<15} {:<24} {}",
                        i.ip.map_or("unassigned".into(), |(ip, _)| ip.to_string()),
                        if !admin {
                            "administratively down"
                        } else if up {
                            "up"
                        } else {
                            "down"
                        },
                        if up { "up" } else { "down" }
                    );
                }
            }
            ["show", "ip", "route"] => {
                let node = node.ok_or("No IPv4 router")?;
                let _ = writeln!(out, "Codes: C - connected, S - static");
                let active: Vec<_> = node
                    .routes
                    .iter()
                    .filter(|r| engine.port_oper_up(r.interface.port))
                    .collect();
                let preferred = |r: &&netsim_engine::Route| {
                    !active.iter().any(|other| {
                        other.prefix == r.prefix
                            && (
                                other.distance,
                                other.metric,
                                other.interface,
                                other.next_hop,
                            ) < (r.distance, r.metric, r.interface, r.next_hop)
                    })
                };
                let default = active
                    .iter()
                    .copied()
                    .filter(preferred)
                    .find(|r| r.prefix.length() == 0);
                let _ = writeln!(
                    out,
                    "{}",
                    default
                        .and_then(|r| r.next_hop)
                        .map_or("Gateway of last resort is not set".into(), |ip| format!(
                            "Gateway of last resort is {ip} to network 0.0.0.0"
                        ))
                );
                for r in active.iter().copied().filter(preferred) {
                    let name = self
                        .running
                        .interfaces
                        .iter()
                        .find(|(_, i)| i.port == r.interface.port && i.dot1q == r.interface.vlan)
                        .map_or("?", |(n, _)| n.as_str());
                    let prefix = format!("{}/{}", r.prefix.network(), r.prefix.length());
                    if r.origin == RouteOrigin::Connected {
                        let _ = writeln!(out, "C    {prefix} is directly connected, {name}");
                    } else if let Some(hop) = r.next_hop {
                        let _ = writeln!(
                            out,
                            "{}   {prefix} [{}/{}] via {hop}",
                            if r.origin == RouteOrigin::Ospf {
                                "O "
                            } else if r.prefix.length() == 0 {
                                "S*"
                            } else {
                                "S "
                            },
                            r.distance,
                            r.metric
                        );
                    }
                }
            }
            ["show", "ip", "arp"] | ["show", "arp"] => {
                let _ = writeln!(out, "Address          Hardware Addr       Interface");
                for i in &node.ok_or("No IPv4 router")?.interfaces {
                    for (ip, mac, _) in &i.arp {
                        let _ = writeln!(
                            out,
                            "{ip:<16} {} {}",
                            mac_text(*mac),
                            name_for(i.config.key.port)
                        );
                    }
                }
            }
            ["show", "vlan"] | ["show", "vlan", "brief"] => {
                let _ = writeln!(out, "VLAN Name                             Status    Ports");
                for (v, name) in &self.running.vlans {
                    let ports = self
                        .running
                        .interfaces
                        .iter()
                        .filter(|(_, i)| !i.trunk && i.access == *v)
                        .map(|(n, _)| n.as_str())
                        .collect::<Vec<_>>()
                        .join(", ");
                    let _ = writeln!(out, "{v:<4} {name:<32} active    {ports}");
                }
            }
            ["show", "mac", "address-table"] => {
                let _ = writeln!(out, "Vlan    Mac Address       Type       Ports");
                for (v, m, p, _) in &bridge.ok_or("No bridge")?.macs {
                    let _ = writeln!(
                        out,
                        "{v:<7} {:<17} DYNAMIC    {}",
                        mac_text(*m),
                        name_for(*p)
                    );
                }
            }
            ["show", "spanning-tree"] => {
                let b = bridge.ok_or("No bridge")?;
                let _ = writeln!(
                    out,
                    "Common spanning tree (educational 802.1D subset)\nRoot ID {:016x}\nBridge ID {:016x}\nInterface Role State",
                    b.root.0, b.bridge.0
                );
                for (p, r, s) in &b.ports {
                    let _ = writeln!(out, "{} {:?} {:?}", name_for(*p), r, s);
                }
            }
            ["show", "interfaces", "trunk"] => {
                let _ = writeln!(
                    out,
                    "Port                         Status       Native vlan   Allowed"
                );
                for (n, i) in self.running.interfaces.iter().filter(|(_, i)| i.trunk) {
                    let _ = writeln!(
                        out,
                        "{n:<28} {:<12} {:<13} {}",
                        if engine.port_oper_up(i.port) {
                            "trunking"
                        } else {
                            "down"
                        },
                        i.native,
                        list_text(&i.allowed)
                    );
                }
            }
            ["show", "interfaces", input, "switchport"] => {
                let name = self.resolve_interface(input).ok_or("Invalid interface")?;
                let i = &self.running.interfaces[&name];
                let mode = if i.trunk { "trunk" } else { "static access" };
                let _ = writeln!(
                    out,
                    "Name: {name}\nSwitchport: Enabled\nAdministrative Mode: {mode}\nOperational Mode: {}\nAccess Mode VLAN: {}\nTrunking Native Mode VLAN: {}\nTrunking VLANs Enabled: {}",
                    if engine.port_oper_up(i.port) {
                        mode
                    } else {
                        "down"
                    },
                    i.access,
                    i.native,
                    list_text(&i.allowed)
                );
            }
            _ => return Err("Unsupported show command".into()),
        }
        Ok(out.trim_end().into())
    }
}

fn mac_text(mac: MacAddress) -> String {
    let [a, b, c, d, e, f] = mac.0;
    format!("{a:02x}{b:02x}.{c:02x}{d:02x}.{e:02x}{f:02x}")
}
