//! One grammar drives execution, abbreviation resolution and context help.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Mode {
    User,
    Privileged,
    Global,
    Interface,
    Vlan,
}

const USER: &[&str] = &[
    "enable",
    "exit",
    "show version",
    "show interfaces",
    "show ip interface brief",
    "ping <ip>",
    "traceroute <ip>",
];
const PRIV: &[&str] = &[
    "disable",
    "exit",
    "configure terminal",
    "show version",
    "show interfaces",
    "show interfaces <interface>",
    "show ip interface brief",
    "show running-config",
    "show startup-config",
    "show history",
    "copy running-config startup-config",
    "write memory",
    "erase startup-config",
    "reload",
    "ping <ip>",
    "traceroute <ip>",
];
const SW_SHOW: &[&str] = &[
    "show vlan",
    "show vlan brief",
    "show mac address-table",
    "show spanning-tree",
    "show interfaces trunk",
    "show interfaces <interface> switchport",
];
const RT_SHOW: &[&str] = &["show ip route", "show ip arp", "show arp"];
const GLOBAL: &[&str] = &["hostname <name>", "interface <interface>", "exit", "end"];
const SW_GLOBAL: &[&str] = &["vlan <id>", "no vlan <id>"];
const RT_GLOBAL: &[&str] = &[
    "ip route <ip> <mask> <ip>",
    "ip route <ip> <mask> <ip> <distance>",
    "no ip route <ip> <mask> <ip>",
    "no ip route <ip> <mask> <ip> <distance>",
];
const IFACE: &[&str] = &[
    "shutdown",
    "no shutdown",
    "description <text>",
    "no description",
    "exit",
    "end",
];
const SW_IFACE: &[&str] = &[
    "switchport mode access",
    "switchport mode trunk",
    "switchport access vlan <id>",
    "switchport trunk native vlan <id>",
    "switchport trunk allowed vlan <list>",
    "switchport trunk allowed vlan all",
    "switchport trunk allowed vlan none",
    "switchport trunk allowed vlan add <list>",
    "switchport trunk allowed vlan remove <list>",
    "no switchport trunk allowed vlan",
];
const RT_IFACE: &[&str] = &[
    "ip address <ip> <mask>",
    "no ip address",
    "encapsulation dot1q <id>",
];
const VLAN: &[&str] = &["name <name>", "exit", "end"];

fn grammar(mode: Mode, switch: bool) -> Vec<Vec<&'static str>> {
    let mut patterns = match mode {
        Mode::User => USER.to_vec(),
        Mode::Privileged => PRIV.to_vec(),
        Mode::Global => GLOBAL.to_vec(),
        Mode::Interface => IFACE.to_vec(),
        Mode::Vlan => VLAN.to_vec(),
    };
    patterns.extend_from_slice(match mode {
        Mode::User | Mode::Privileged if switch => SW_SHOW,
        Mode::User | Mode::Privileged => RT_SHOW,
        Mode::Global if switch => SW_GLOBAL,
        Mode::Global => RT_GLOBAL,
        Mode::Interface if switch => SW_IFACE,
        Mode::Interface => RT_IFACE,
        _ => &[],
    });
    patterns
        .into_iter()
        .map(|p| p.split_whitespace().collect())
        .collect()
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ParseError {
    Invalid,
    Ambiguous,
    Incomplete,
}

fn candidates<'a>(patterns: &[Vec<&'a str>], index: usize, word: &str) -> Vec<&'a str> {
    let word = word.to_ascii_lowercase();
    let mut result: Vec<_> = patterns
        .iter()
        .filter_map(|p| p.get(index).copied())
        .filter(|t| !t.starts_with('<') && t.starts_with(&word))
        .collect();
    result.sort_unstable();
    result.dedup();
    if let Some(exact) = result.iter().copied().find(|t| *t == word.as_str()) {
        return vec![exact];
    }
    if result.is_empty() {
        result = patterns
            .iter()
            .filter_map(|p| p.get(index).copied())
            .filter(|t| t.starts_with('<'))
            .collect();
        result.sort_unstable();
        result.dedup();
    }
    result
}

fn advance(
    patterns: &mut Vec<Vec<&'static str>>,
    index: usize,
    word: &str,
) -> Result<String, ParseError> {
    let options = candidates(patterns, index, word);
    if options.len() > 1 {
        return Err(ParseError::Ambiguous);
    }
    let token = *options.first().ok_or(ParseError::Invalid)?;
    patterns.retain(|p| p.get(index) == Some(&token));
    Ok(if token.starts_with('<') {
        word.to_owned()
    } else {
        token.to_owned()
    })
}

pub fn parse(mode: Mode, switch: bool, line: &str) -> Result<Vec<String>, ParseError> {
    let mut patterns = grammar(mode, switch);
    let mut result = Vec::new();
    for (i, word) in line.split_whitespace().enumerate() {
        result.push(advance(&mut patterns, i, word)?);
    }
    if patterns.iter().any(|p| p.len() == result.len()) {
        Ok(result)
    } else {
        Err(ParseError::Incomplete)
    }
}

pub fn complete(mode: Mode, switch: bool, line: &str) -> Vec<String> {
    let mut patterns = grammar(mode, switch);
    let mut words: Vec<_> = line.split_whitespace().collect();
    let fragment = if line.ends_with(char::is_whitespace) {
        ""
    } else {
        words.pop().unwrap_or("")
    };
    for (i, word) in words.iter().enumerate() {
        if advance(&mut patterns, i, word).is_err() {
            return Vec::new();
        }
    }
    let mut result: Vec<_> = candidates(&patterns, words.len(), fragment)
        .into_iter()
        .map(str::to_owned)
        .collect();
    if fragment.is_empty() {
        // Include argument placeholders even if literal alternatives exist.
        result.extend(
            patterns
                .iter()
                .filter_map(|p| p.get(words.len()))
                .filter(|p| p.starts_with('<'))
                .map(|p| (*p).to_owned()),
        );
        if patterns.iter().any(|p| p.len() == words.len()) {
            result.push("<cr>".into());
        }
    }
    result.sort();
    result.dedup();
    result
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn abbreviations_and_context() {
        assert_eq!(
            parse(Mode::Privileged, false, "conf t").unwrap(),
            ["configure", "terminal"]
        );
        assert_eq!(parse(Mode::User, false, "conf t"), Err(ParseError::Invalid));
        assert_eq!(
            parse(Mode::Privileged, false, "show ip"),
            Err(ParseError::Incomplete)
        );
        assert_eq!(
            parse(Mode::Privileged, false, "show i"),
            Err(ParseError::Ambiguous)
        );
        assert_eq!(complete(Mode::Privileged, false, "conf "), ["terminal"]);
    }
}
