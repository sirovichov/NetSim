//! Protocol primitives and L2 learning bridge.
pub mod arp;
pub mod bridge;
pub mod routing;

use std::net::Ipv4Addr;

#[derive(Clone, Copy, Debug, PartialEq, Eq, serde::Serialize)]
pub struct Ipv4Prefix {
    network: u32,
    length: u8,
}

impl Ipv4Prefix {
    pub fn new(address: Ipv4Addr, length: u8) -> Option<Self> {
        if length > 32 {
            return None;
        }
        Some(Self {
            network: u32::from(address) & Self::mask(length),
            length,
        })
    }

    fn mask(length: u8) -> u32 {
        if length == 0 {
            0
        } else {
            u32::MAX << (32 - length)
        }
    }

    pub fn contains(self, address: Ipv4Addr) -> bool {
        u32::from(address) & Self::mask(self.length) == self.network
    }

    pub fn network(self) -> Ipv4Addr {
        Ipv4Addr::from(self.network)
    }

    pub fn length(self) -> u8 {
        self.length
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn prefix_boundaries() {
        let address = Ipv4Addr::new(192, 168, 1, 7);
        let prefix = Ipv4Prefix::new(address, 24).unwrap();
        assert!(prefix.contains(Ipv4Addr::new(192, 168, 1, 255)));
        assert!(!prefix.contains(Ipv4Addr::new(192, 168, 2, 1)));
        assert!(
            Ipv4Prefix::new(address, 0)
                .unwrap()
                .contains(Ipv4Addr::LOCALHOST)
        );
        assert!(
            !Ipv4Prefix::new(address, 32)
                .unwrap()
                .contains(Ipv4Addr::LOCALHOST)
        );
        assert!(Ipv4Prefix::new(address, 33).is_none());
    }
}

impl<'de> serde::Deserialize<'de> for Ipv4Prefix {
    fn deserialize<D: serde::Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        #[derive(serde::Deserialize)]
        #[serde(deny_unknown_fields)]
        struct Repr {
            network: u32,
            length: u8,
        }
        let r = <Repr as serde::Deserialize>::deserialize(d)?;
        Self::new(Ipv4Addr::from(r.network), r.length)
            .filter(|p| p.network == r.network)
            .ok_or_else(|| serde::de::Error::custom("invalid IPv4 prefix"))
    }
}

pub mod ospf;
