//! Per-device IPv4 RIB; deterministic longest-prefix match.
use crate::Ipv4Prefix;
use netsim_types::PortId;
use std::net::Ipv4Addr;

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct InterfaceKey {
    pub port: PortId,
    /// None = untagged, Some(1..=4094) = tagged router subinterface.
    pub vlan: Option<u16>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct InterfaceConfig {
    pub key: InterfaceKey,
    pub address: Ipv4Addr,
    pub prefix_len: u8,
    pub mac: netsim_types::MacAddress,
}

impl InterfaceConfig {
    pub fn prefix(self) -> Option<Ipv4Prefix> {
        Ipv4Prefix::new(self.address, self.prefix_len)
    }

    pub fn valid(self) -> bool {
        unicast(self.address)
            && self.prefix().is_some_and(|p| usable(p, self.address))
            && self.key.vlan.is_none_or(|v| (1..=4094).contains(&v))
            && !self.mac.is_multicast()
            && self.mac.0 != [0; 6]
    }
}

pub fn unicast(ip: Ipv4Addr) -> bool {
    !ip.is_unspecified()
        && !ip.is_multicast()
        && !ip.is_broadcast()
        && !ip.is_loopback()
        && ip.octets()[0] != 0
        && ip.octets()[0] < 240
}

/// /31 links use both addresses (RFC 3021); /32 host routes are valid.
pub fn usable(prefix: Ipv4Prefix, ip: Ipv4Addr) -> bool {
    if !prefix.contains(ip) || !unicast(ip) {
        return false;
    }
    if prefix.length() >= 31 {
        return true;
    }
    let broadcast = u32::from(prefix.network())
        | (if prefix.length() == 0 {
            u32::MAX
        } else {
            u32::MAX >> prefix.length()
        });
    ip != prefix.network() && u32::from(ip) != broadcast
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RouteOrigin {
    Connected,
    Static,
    Ospf,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Route {
    pub prefix: Ipv4Prefix,
    pub interface: InterfaceKey,
    pub next_hop: Option<Ipv4Addr>,
    pub distance: u8,
    pub metric: u32,
    pub origin: RouteOrigin,
}

/// More specific first; then administrative distance, metric and stable interface order.
pub fn lookup(
    routes: &[Route],
    destination: Ipv4Addr,
    active: impl Fn(InterfaceKey) -> bool,
) -> Option<Route> {
    routes
        .iter()
        .filter(|r| r.prefix.contains(destination) && active(r.interface))
        .min_by_key(|r| {
            (
                std::cmp::Reverse(r.prefix.length()),
                r.distance,
                r.metric,
                r.interface,
                r.next_hop,
            )
        })
        .copied()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn lpm_and_distance_and_inactive_port() {
        let ip = Ipv4Addr::new(10, 1, 2, 3);
        let mk = |len, port, distance| Route {
            prefix: Ipv4Prefix::new(ip, len).unwrap(),
            interface: InterfaceKey {
                port: PortId(port),
                vlan: None,
            },
            next_hop: None,
            distance,
            metric: 0,
            origin: RouteOrigin::Static,
        };
        let routes = [mk(0, 1, 1), mk(16, 2, 1), mk(24, 3, 10), mk(24, 4, 1)];
        assert_eq!(lookup(&routes, ip, |_| true), Some(routes[3]));
        assert_eq!(lookup(&routes, ip, |k| k.port.0 < 4), Some(routes[2]));
        assert_eq!(lookup(&routes, ip, |k| k.port.0 == 1), Some(routes[0]));
        assert_eq!(lookup(&routes, ip, |_| false), None);
    }
}
