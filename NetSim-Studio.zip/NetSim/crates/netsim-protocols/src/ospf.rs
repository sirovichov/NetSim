//! Area 0 teaching link-state model. Uses local LSDB and bidirectional graph,
//! not the global simulator topology. Not RFC 2328 wire-compatible.
use crate::Ipv4Prefix;
use std::{
    collections::{BTreeMap, BTreeSet},
    net::Ipv4Addr,
};
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Lsa {
    pub router: Ipv4Addr,
    pub sequence: u64,
    pub neighbors: Vec<Ipv4Addr>,
    pub prefixes: Vec<Ipv4Prefix>,
}
impl Lsa {
    pub fn encode(&self) -> Option<Vec<u8>> {
        if self.neighbors.len() > 64 || self.prefixes.len() > 64 {
            return None;
        }
        let mut b = b"NSO1".to_vec();
        b.extend(self.router.octets());
        b.extend(self.sequence.to_be_bytes());
        b.push(self.neighbors.len() as u8);
        b.push(self.prefixes.len() as u8);
        for n in &self.neighbors {
            b.extend(n.octets());
        }
        for p in &self.prefixes {
            b.extend(p.network().octets());
            b.push(p.length());
        }
        Some(b)
    }
    pub fn decode(b: &[u8]) -> Option<Self> {
        if b.len() < 18 || &b[..4] != b"NSO1" {
            return None;
        }
        let n = usize::from(b[16]);
        let m = usize::from(b[17]);
        if n > 64 || m > 64 || b.len() != 18 + 4 * n + 5 * m {
            return None;
        }
        let router = Ipv4Addr::from(<[u8; 4]>::try_from(&b[4..8]).ok()?);
        let sequence = u64::from_be_bytes(b[8..16].try_into().ok()?);
        let neighbors = b[18..18 + 4 * n]
            .chunks_exact(4)
            .map(|v| Ipv4Addr::new(v[0], v[1], v[2], v[3]))
            .collect();
        let prefixes = b[18 + 4 * n..]
            .chunks_exact(5)
            .map(|v| Ipv4Prefix::new(Ipv4Addr::new(v[0], v[1], v[2], v[3]), v[4]))
            .collect::<Option<Vec<_>>>()?;
        Some(Self {
            router,
            sequence,
            neighbors,
            prefixes,
        })
    }
}
/// Unit-cost Dijkstra with deterministic router-ID tie-breaking.
pub fn spf(root: Ipv4Addr, db: &BTreeMap<Ipv4Addr, Lsa>) -> BTreeMap<Ipv4Addr, (u32, Ipv4Addr)> {
    let mut paths = BTreeMap::from([(root, (0u32, root))]);
    let mut done = BTreeSet::new();
    loop {
        let Some((r, path)) = paths
            .iter()
            .filter(|entry| !done.contains(entry.0))
            .min_by_key(|entry| (*entry.1, *entry.0))
        else {
            break;
        };
        let (r, (cost, first)) = (*r, *path);
        done.insert(r);
        let Some(lsa) = db.get(&r) else {
            continue;
        };
        for n in &lsa.neighbors {
            if !db.get(n).is_some_and(|l| l.neighbors.contains(&r)) || done.contains(n) {
                continue;
            }
            let candidate = (cost + 1, if r == root { *n } else { first });
            if paths.get(n).is_none_or(|old| candidate < *old) {
                paths.insert(*n, candidate);
            }
        }
    }
    paths.remove(&root);
    paths
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn reciprocal_edges_only() {
        let a = Ipv4Addr::new(1, 1, 1, 1);
        let b = Ipv4Addr::new(2, 2, 2, 2);
        let mut db = BTreeMap::from([
            (
                a,
                Lsa {
                    router: a,
                    sequence: 1,
                    neighbors: vec![b],
                    prefixes: vec![],
                },
            ),
            (
                b,
                Lsa {
                    router: b,
                    sequence: 1,
                    neighbors: vec![],
                    prefixes: vec![],
                },
            ),
        ]);
        assert!(spf(a, &db).is_empty());
        db.get_mut(&b).unwrap().neighbors.push(a);
        assert_eq!(spf(a, &db)[&b], (1, b));
        assert_eq!(Lsa::decode(&db[&a].encode().unwrap()), Some(db[&a].clone()));
    }
}
