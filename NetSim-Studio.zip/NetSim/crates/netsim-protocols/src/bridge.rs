//! Learning bridge, VLAN admission and a single-tree 802.1D-inspired STP subset.
use netsim_packet::ethernet::{EthernetFrame, STP_MAC, Tag};
use netsim_types::{MacAddress, PortId, SimTime};
use std::collections::{BTreeMap, BTreeSet};

pub const HELLO: SimTime = 2_000_000_000;
pub const MAX_AGE: SimTime = 20_000_000_000;
pub const FORWARD_DELAY: SimTime = 15_000_000_000;
pub const MAC_TTL: SimTime = 300_000_000_000;
const COST: u32 = 19;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum PortMode {
    Access(u16),
    Trunk {
        native: Option<u16>,
        allowed: BTreeSet<u16>,
    },
}

impl PortMode {
    pub fn valid(&self) -> bool {
        let valid = |v: u16| (1..=4094).contains(&v);
        match self {
            Self::Access(v) => valid(*v),
            Self::Trunk { native, allowed } => {
                allowed.iter().all(|v| valid(*v)) && native.is_none_or(valid)
            }
        }
    }

    pub fn ingress(&self, tag: Option<Tag>) -> Option<u16> {
        match self {
            Self::Access(v) if tag.is_none_or(|t| t.vid == 0) => Some(*v),
            Self::Access(_) => None,
            Self::Trunk { native, allowed } => {
                let v = tag.filter(|t| t.vid != 0).map(|t| t.vid).or(*native)?;
                allowed.contains(&v).then_some(v)
            }
        }
    }

    pub fn egress(&self, vlan: u16, original: Option<Tag>) -> Option<Option<Tag>> {
        match self {
            Self::Access(v) if *v == vlan => Some(None),
            Self::Trunk { native, allowed } if allowed.contains(&vlan) => {
                if *native == Some(vlan) {
                    Some(None)
                } else {
                    Some(Some(Tag {
                        vid: vlan,
                        pcp: original.map_or(0, |t| t.pcp),
                        dei: original.is_some_and(|t| t.dei),
                    }))
                }
            }
            _ => None,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct BridgeId(pub u64);

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
struct Vector {
    root: BridgeId,
    cost: u32,
    bridge: BridgeId,
    port: u16,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Bpdu {
    vector: Vector,
    age: u16,
}

impl Bpdu {
    fn frame(self, mac: MacAddress) -> EthernetFrame {
        let mut p = vec![0x42, 0x42, 3, 0, 0, 0, 0, 0]; // LLC, protocol, version, type, flags
        p.extend_from_slice(&self.vector.root.0.to_be_bytes());
        p.extend_from_slice(&self.vector.cost.to_be_bytes());
        p.extend_from_slice(&self.vector.bridge.0.to_be_bytes());
        p.extend_from_slice(&self.vector.port.to_be_bytes());
        for t in [self.age, 20 * 256, 2 * 256, 15 * 256] {
            p.extend_from_slice(&t.to_be_bytes());
        }
        EthernetFrame {
            dst: STP_MAC,
            src: mac,
            tag: None,
            kind: p.len() as u16,
            payload: p,
        }
    }

    fn decode(f: &EthernetFrame) -> Option<Self> {
        let p = &f.payload;
        if f.dst != STP_MAC
            || f.tag.is_some()
            || f.kind != 38
            || p.len() != 38
            || p[..7] != [0x42, 0x42, 3, 0, 0, 0, 0]
        {
            return None;
        }
        let word = |i: usize| u16::from_be_bytes([p[i], p[i + 1]]);
        if word(32) != 20 * 256
            || word(34) != 2 * 256
            || word(36) != 15 * 256
            || word(30) >= 20 * 256
        {
            return None;
        }
        let vector = Vector {
            root: BridgeId(u64::from_be_bytes(p[8..16].try_into().ok()?)),
            cost: u32::from_be_bytes(p[16..20].try_into().ok()?),
            bridge: BridgeId(u64::from_be_bytes(p[20..28].try_into().ok()?)),
            port: word(28),
        };
        if vector.root > vector.bridge || vector.port == 0 {
            return None;
        }
        Some(Self {
            vector,
            age: word(30),
        })
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Role {
    Disabled,
    Root,
    Designated,
    Alternate,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PortState {
    Blocking,
    Listening,
    Learning,
    Forwarding,
}

#[derive(Clone, Debug)]
struct BridgePort {
    mode: PortMode,
    number: u16,
    active: bool,
    peer: Option<(Bpdu, SimTime)>,
    role: Role,
    since: SimTime,
}

impl BridgePort {
    fn state(&self, now: SimTime) -> PortState {
        if !matches!(self.role, Role::Root | Role::Designated) {
            return PortState::Blocking;
        }
        match now.saturating_sub(self.since) {
            t if t < FORWARD_DELAY => PortState::Listening,
            t if t < 2 * FORWARD_DELAY => PortState::Learning,
            _ => PortState::Forwarding,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct BridgeSnapshot {
    pub root: BridgeId,
    pub bridge: BridgeId,
    pub root_port: Option<PortId>,
    pub ports: Vec<(PortId, Role, PortState)>,
    pub macs: Vec<(u16, MacAddress, PortId, SimTime)>,
}

#[derive(Clone, Debug)]
pub struct Bridge {
    id: BridgeId,
    mac: MacAddress,
    root: BridgeId,
    cost: u32,
    root_port: Option<PortId>,
    ports: BTreeMap<PortId, BridgePort>,
    macs: BTreeMap<(u16, MacAddress), (PortId, SimTime)>,
}

impl Bridge {
    pub fn new(priority: u16, mac: MacAddress) -> Option<Self> {
        if priority % 4096 != 0 || mac.is_multicast() || mac.0 == [0; 6] {
            return None;
        }
        let mut bytes = [0; 8];
        bytes[..2].copy_from_slice(&priority.to_be_bytes());
        bytes[2..].copy_from_slice(&mac.0);
        let id = BridgeId(u64::from_be_bytes(bytes));
        Some(Self {
            id,
            mac,
            root: id,
            cost: 0,
            root_port: None,
            ports: BTreeMap::new(),
            macs: BTreeMap::new(),
        })
    }

    pub fn mac(&self) -> MacAddress {
        self.mac
    }

    pub fn configure(&mut self, port: PortId, mode: PortMode) -> bool {
        if !mode.valid() {
            return false;
        }
        let number = match self.ports.get(&port) {
            Some(p) => p.number,
            None => {
                if self.ports.len() >= 4095 {
                    return false;
                }
                0x8000 | (self.ports.len() as u16 + 1)
            }
        };
        self.ports.insert(
            port,
            BridgePort {
                mode,
                number,
                active: false,
                peer: None,
                role: Role::Disabled,
                since: 0,
            },
        );
        self.macs.retain(|_, (p, _)| *p != port);
        true
    }

    pub fn reset(&mut self) {
        self.root = self.id;
        self.cost = 0;
        self.root_port = None;
        self.macs.clear();
        for p in self.ports.values_mut() {
            p.active = false;
            p.peer = None;
            p.role = Role::Disabled;
            p.since = 0;
        }
    }

    pub fn sync(&mut self, active: &BTreeSet<PortId>, now: SimTime) {
        for (id, p) in &mut self.ports {
            let up = active.contains(id);
            if up != p.active {
                p.active = up;
                p.peer = None;
                p.role = Role::Disabled;
                p.since = now;
                self.macs.retain(|_, (port, _)| *port != *id);
            }
            if p.peer.is_some_and(|(b, at)| {
                now.saturating_sub(at)
                    .saturating_add(u64::from(b.age) * 1_000_000_000 / 256)
                    >= MAX_AGE
            }) {
                p.peer = None;
            }
        }
        self.recompute(now);
    }

    fn recompute(&mut self, now: SimTime) {
        let own = Vector {
            root: self.id,
            cost: 0,
            bridge: self.id,
            port: 0,
        };
        let best = self
            .ports
            .iter()
            .filter(|(_, p)| p.active)
            .filter_map(|(id, p)| {
                p.peer.map(|(b, _)| {
                    (
                        Vector {
                            cost: b.vector.cost.saturating_add(COST),
                            ..b.vector
                        },
                        p.number,
                        *id,
                    )
                })
            })
            .filter(|(v, _, _)| v.root < self.id && v.bridge != self.id)
            .min();
        let (root, cost, root_port) =
            best.map_or((own.root, 0, None), |(v, _, p)| (v.root, v.cost, Some(p)));
        let changed = (root, cost, root_port) != (self.root, self.cost, self.root_port);
        self.root = root;
        self.cost = cost;
        self.root_port = root_port;
        for (id, p) in &mut self.ports {
            let vector = Vector {
                root,
                cost,
                bridge: self.id,
                port: p.number,
            };
            let role = if !p.active {
                Role::Disabled
            } else if Some(*id) == root_port {
                Role::Root
            } else if p.peer.is_none_or(|(b, _)| vector < b.vector) {
                Role::Designated
            } else {
                Role::Alternate
            };
            if changed || role != p.role {
                p.role = role;
                p.since = now;
                self.macs.clear(); // conservative topology change flush
            }
        }
        self.macs.retain(|_, (_, until)| *until > now);
    }

    pub fn hello(&self, now: SimTime) -> Vec<(PortId, EthernetFrame)> {
        let age = match self
            .root_port
            .and_then(|p| self.ports.get(&p))
            .and_then(|p| p.peer)
        {
            None => 0,
            Some((b, at)) => u64::from(b.age)
                .saturating_add(256)
                .saturating_add(now.saturating_sub(at) / 3_906_250)
                .min(5120) as u16,
        };
        if age >= 5120 {
            return Vec::new();
        }
        self.ports
            .iter()
            .filter(|(_, p)| p.active && p.role == Role::Designated)
            .map(|(id, p)| {
                (
                    *id,
                    Bpdu {
                        vector: Vector {
                            root: self.root,
                            cost: self.cost,
                            bridge: self.id,
                            port: p.number,
                        },
                        age,
                    }
                    .frame(self.mac),
                )
            })
            .collect()
    }

    pub fn receive(
        &mut self,
        ingress: PortId,
        frame: EthernetFrame,
        now: SimTime,
    ) -> Vec<(PortId, EthernetFrame)> {
        if frame.dst == STP_MAC {
            if let Some(b) = Bpdu::decode(&frame) {
                if let Some(p) = self.ports.get_mut(&ingress).filter(|p| p.active) {
                    p.peer = Some((b, now));
                    self.recompute(now);
                }
            }
            return Vec::new();
        }
        // Other link-local reserved multicast is never bridged.
        if frame.dst.0[..5] == [1, 128, 194, 0, 0] && frame.dst.0[5] <= 15 {
            return Vec::new();
        }
        let Some(p) = self.ports.get(&ingress) else {
            return Vec::new();
        };
        let Some(vlan) = p.mode.ingress(frame.tag) else {
            return Vec::new();
        };
        let state = p.state(now);
        if !matches!(state, PortState::Learning | PortState::Forwarding) {
            return Vec::new();
        }
        self.macs.retain(|_, (_, until)| *until > now);
        let key = (vlan, frame.src);
        if !frame.src.is_multicast() && frame.src.0 != [0; 6] {
            if self.macs.len() >= 8192 && !self.macs.contains_key(&key) {
                if let Some(old) = self
                    .macs
                    .iter()
                    .min_by_key(|(k, (_, until))| (*until, **k))
                    .map(|(k, _)| *k)
                {
                    self.macs.remove(&old);
                }
            }
            self.macs
                .insert(key, (ingress, now.saturating_add(MAC_TTL)));
        }
        if state != PortState::Forwarding {
            return Vec::new();
        }
        let known = if frame.dst.is_multicast() {
            None
        } else {
            self.macs.get(&(vlan, frame.dst)).map(|(p, _)| *p)
        };
        self.ports
            .iter()
            .filter(|(id, p)| {
                **id != ingress
                    && p.state(now) == PortState::Forwarding
                    && known.is_none_or(|target| **id == target)
            })
            .filter_map(|(id, p)| {
                let tag = p.mode.egress(vlan, frame.tag)?;
                Some((
                    *id,
                    EthernetFrame {
                        tag,
                        ..frame.clone()
                    },
                ))
            })
            .collect()
    }

    pub fn snapshot(&self, now: SimTime) -> BridgeSnapshot {
        BridgeSnapshot {
            root: self.root,
            bridge: self.id,
            root_port: self.root_port,
            ports: self
                .ports
                .iter()
                .map(|(id, p)| (*id, p.role, p.state(now)))
                .collect(),
            macs: self
                .macs
                .iter()
                .filter(|(_, (_, until))| *until > now)
                .map(|((v, m), (p, t))| (*v, *m, *p, *t))
                .collect(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn mac(n: u8) -> MacAddress {
        MacAddress([2, 0, 0, 0, 0, n])
    }

    #[test]
    fn unknown_unicast_floods_only_forwarding_vlan_ports() {
        let mut bridge = Bridge::new(32768, mac(10)).unwrap();
        for (id, vlan) in [(1, 10), (2, 10), (3, 10), (4, 20)] {
            assert!(bridge.configure(PortId(id), PortMode::Access(vlan)));
        }
        bridge.sync(
            &[PortId(1), PortId(2), PortId(3), PortId(4)]
                .into_iter()
                .collect(),
            0,
        );
        let f = EthernetFrame {
            src: mac(1),
            dst: mac(2),
            tag: None,
            kind: 0x0800,
            payload: vec![1],
        };
        assert!(bridge.receive(PortId(1), f.clone(), 1).is_empty());
        assert!(bridge.snapshot(1).macs.is_empty());
        assert!(
            bridge
                .receive(PortId(1), f.clone(), FORWARD_DELAY)
                .is_empty()
        );
        assert_eq!(bridge.snapshot(FORWARD_DELAY).macs.len(), 1);
        let out = bridge.receive(PortId(1), f, 2 * FORWARD_DELAY);
        assert_eq!(
            out.iter().map(|(p, _)| *p).collect::<Vec<_>>(),
            [PortId(2), PortId(3)]
        );
        let reply = EthernetFrame {
            src: mac(2),
            dst: mac(1),
            tag: None,
            kind: 0x0800,
            payload: vec![2],
        };
        assert_eq!(
            bridge.receive(PortId(2), reply, 2 * FORWARD_DELAY)[0].0,
            PortId(1)
        );
    }
}
