//! RFC 826 Ethernet/IPv4 ARP and bounded per-host cache.
use netsim_types::{MacAddress, SimTime};
use std::{collections::BTreeMap, net::Ipv4Addr};

pub const ARP_TTL: SimTime = 60_000_000_000;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Operation {
    Request,
    Reply,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Arp {
    pub operation: Operation,
    pub sender_mac: MacAddress,
    pub sender_ip: Ipv4Addr,
    pub target_mac: MacAddress,
    pub target_ip: Ipv4Addr,
}

impl Arp {
    pub fn encode(self) -> Vec<u8> {
        let mut bytes = vec![
            0,
            1,
            8,
            0,
            6,
            4,
            0,
            match self.operation {
                Operation::Request => 1,
                Operation::Reply => 2,
            },
        ];
        bytes.extend_from_slice(&self.sender_mac.0);
        bytes.extend_from_slice(&self.sender_ip.octets());
        bytes.extend_from_slice(&self.target_mac.0);
        bytes.extend_from_slice(&self.target_ip.octets());
        bytes
    }

    pub fn decode(bytes: &[u8]) -> Option<Self> {
        if bytes.len() < 28 || bytes[..6] != [0, 1, 8, 0, 6, 4] {
            return None;
        }
        let operation = match [bytes[6], bytes[7]] {
            [0, 1] => Operation::Request,
            [0, 2] => Operation::Reply,
            _ => return None,
        };
        let sender_mac = MacAddress(bytes[8..14].try_into().ok()?);
        if sender_mac.is_multicast() || sender_mac.0 == [0; 6] {
            return None;
        }
        Some(Self {
            operation,
            sender_mac,
            sender_ip: Ipv4Addr::new(bytes[14], bytes[15], bytes[16], bytes[17]),
            target_mac: MacAddress(bytes[18..24].try_into().ok()?),
            target_ip: Ipv4Addr::new(bytes[24], bytes[25], bytes[26], bytes[27]),
        })
    }
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct ArpCache(BTreeMap<Ipv4Addr, (MacAddress, SimTime)>);

impl ArpCache {
    pub fn learn(&mut self, ip: Ipv4Addr, mac: MacAddress, now: SimTime) {
        if ip.is_unspecified()
            || ip.is_multicast()
            || ip.is_broadcast()
            || mac.is_multicast()
            || mac.0 == [0; 6]
        {
            return;
        }
        self.0.retain(|_, (_, until)| *until > now);
        if self.0.len() >= 1024 && !self.0.contains_key(&ip) {
            if let Some(key) = self
                .0
                .iter()
                .min_by_key(|(ip, (_, until))| (*until, **ip))
                .map(|(ip, _)| *ip)
            {
                self.0.remove(&key);
            }
        }
        self.0.insert(ip, (mac, now.saturating_add(ARP_TTL)));
    }

    pub fn lookup(&self, ip: Ipv4Addr, now: SimTime) -> Option<MacAddress> {
        self.0
            .get(&ip)
            .filter(|(_, expires)| *expires > now)
            .map(|(mac, _)| *mac)
    }

    pub fn entries(&self, now: SimTime) -> Vec<(Ipv4Addr, MacAddress, SimTime)> {
        self.0
            .iter()
            .filter(|(_, (_, until))| *until > now)
            .map(|(ip, (mac, until))| (*ip, *mac, *until))
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn arp_roundtrip_and_expiry() {
        let mac = MacAddress([2, 0, 0, 0, 0, 1]);
        let ip = Ipv4Addr::new(10, 0, 0, 1);
        let packet = Arp {
            operation: Operation::Request,
            sender_mac: mac,
            sender_ip: ip,
            target_mac: MacAddress([0; 6]),
            target_ip: Ipv4Addr::new(10, 0, 0, 2),
        };
        assert_eq!(Arp::decode(&packet.encode()), Some(packet));
        assert!(Arp::decode(&packet.encode()[..27]).is_none());
        let mut cache = ArpCache::default();
        cache.learn(ip, mac, 1);
        assert_eq!(cache.lookup(ip, ARP_TTL), Some(mac));
        assert_eq!(cache.lookup(ip, ARP_TTL + 1), None);
    }
}
