//! Virtual service boundary. DHCP and other services are not implemented yet.

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ServiceKind {
    DhcpV4,
}
