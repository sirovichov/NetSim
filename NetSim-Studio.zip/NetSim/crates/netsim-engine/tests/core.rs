use netsim_core::{
    DeviceId, EngineCommand, EngineError, EventKind, LinkId, MediaKind, PacketId, PowerState,
    SessionId, TimerId,
};
use netsim_devices::{DeviceContext, DeviceDescriptor, DeviceSnapshot, NetworkDevice, SimRng};
use netsim_engine::{
    CommandResult, Engine, EngineLimits, Outcome, TraceAction, Worker, WorkerRequest,
    WorkerResponse,
};
use netsim_topology::Link;

const PROFILE: DeviceDescriptor = DeviceDescriptor {
    profile_id: "test.probe",
    profile_version: 1,
    vendor: "Test",
    model: "Probe",
    firmware_reference: None,
};

struct Probe {
    id: DeviceId,
    descriptor: DeviceDescriptor,
    hostname: String,
    count: u64,
    random: u64,
}

impl NetworkDevice for Probe {
    fn id(&self) -> DeviceId {
        self.id
    }
    fn descriptor(&self) -> &DeviceDescriptor {
        &self.descriptor
    }
    fn on_event(&mut self, event: EventKind, ctx: &mut DeviceContext) -> Result<(), EngineError> {
        match event {
            EventKind::DeviceBoot => {
                self.count = 0;
                self.random = ctx.random_u64();
            }
            EventKind::TimerExpired {
                timer: TimerId(90), ..
            } => {
                ctx.set_timer(TimerId(91), 1)?;
                ctx.set_timer(TimerId(92), 1)?;
            }
            EventKind::TimerExpired {
                timer: TimerId(80), ..
            } => {
                ctx.set_timer(TimerId(80), 0)?;
            }
            EventKind::TimerExpired {
                timer: TimerId(70), ..
            } => {
                ctx.set_timer(TimerId(71), 3)?;
                ctx.set_timer(TimerId(71), 2)?;
                ctx.cancel_timer(TimerId(71))?;
                ctx.set_timer(TimerId(72), 1)?;
            }
            EventKind::TimerExpired { .. } | EventKind::PacketReceive { .. } => {
                self.count += 1;
                self.random = ctx.random_u64();
            }
            _ => {}
        }
        Ok(())
    }
    fn execute_cli(
        &mut self,
        _session: SessionId,
        command: &str,
        _ctx: &mut DeviceContext,
    ) -> Result<String, EngineError> {
        match command {
            "show" => Ok(format!("{} {}", self.count, self.random)),
            _ => Err(EngineError::Unsupported),
        }
    }
    fn snapshot(&self) -> DeviceSnapshot {
        DeviceSnapshot {
            id: self.id,
            hostname: self.hostname.clone(),
        }
    }
}

fn factory(id: DeviceId, descriptor: DeviceDescriptor, hostname: String) -> Box<dyn NetworkDevice> {
    Box::new(Probe {
        id,
        descriptor,
        hostname,
        count: 0,
        random: 0,
    })
}

fn engine(limits: EngineLimits) -> Engine {
    let mut engine = Engine::new(42, limits);
    engine.register_profile(PROFILE, factory).unwrap();
    engine
}

fn add(engine: &mut Engine, name: &str) -> DeviceId {
    engine
        .add_device(PROFILE.profile_id, 1, name.into())
        .unwrap()
}

fn active(engine: &mut Engine, name: &str) -> DeviceId {
    let id = add(engine, name);
    engine.power_on(id).unwrap();
    id
}

fn command(id: DeviceId, text: &str) -> EngineCommand {
    EngineCommand::ExecuteCli {
        device: id,
        session: SessionId(1),
        command: text.into(),
    }
}

fn link(a: netsim_core::PortId, b: netsim_core::PortId) -> Link {
    Link {
        id: LinkId(0),
        endpoints: [a, b],
        bandwidth_bps: 1_000_000,
        delay_ns: 10,
        loss_ppm: 0,
        queue_limit_bytes: 1500,
    }
}

#[test]
fn registry_and_lifecycle() {
    let mut e = engine(EngineLimits::default());
    assert_eq!(
        e.register_profile(PROFILE, factory),
        Err(EngineError::DuplicateProfile)
    );
    assert_eq!(
        e.add_device(PROFILE.profile_id, 2, "x".into()),
        Err(EngineError::UnknownProfile)
    );
    assert_eq!(
        e.add_device(PROFILE.profile_id, 1, "".into()),
        Err(EngineError::InvalidInput)
    );
    let id = add(&mut e, "R1");
    assert_eq!(e.snapshot().devices[0].power, PowerState::Off);
    assert_eq!(
        e.set_timer(id, TimerId(1), 1),
        Err(EngineError::InvalidState)
    );
    e.power_on(id).unwrap();
    assert_eq!(e.power_on(id), Err(EngineError::InvalidState));
    e.set_timer(id, TimerId(1), 10).unwrap();
    e.execute(EngineCommand::Reboot(id)).unwrap();
    let snap = e.snapshot();
    assert_eq!(snap.devices[0].generation, 2);
    assert!(snap.devices[0].timers.is_empty());
    assert_eq!(snap.pending_events, 0);
    e.remove_device(id).unwrap();
    assert_eq!(e.power_on(id), Err(EngineError::UnknownDevice));
    assert!(add(&mut e, "R2") > id);
}

#[test]
fn replacement_cancel_and_capacity() {
    let mut e = engine(EngineLimits {
        events: 1,
        ..EngineLimits::default()
    });
    let id = active(&mut e, "R");
    e.set_timer(id, TimerId(1), 100).unwrap();
    assert_eq!(e.set_timer(id, TimerId(2), 1), Err(EngineError::QueueFull));
    e.set_timer(id, TimerId(1), 5).unwrap();
    assert_eq!(e.snapshot().pending_events, 1);
    assert_eq!(e.snapshot().devices[0].timers, [(TimerId(1), 5)]);
    e.cancel_timer(id, TimerId(1)).unwrap();
    e.cancel_timer(id, TimerId(1)).unwrap();
    assert_eq!(e.snapshot().pending_events, 0);
    e.set_timer(id, TimerId(2), 2).unwrap();
    assert_eq!(e.step().unwrap().at, 2);
    assert!(e.step().is_none());
    assert!(e.snapshot().devices[0].timers.is_empty());
}

#[test]
fn callback_timer_effects_are_ordered_and_bounded() {
    let mut e = engine(EngineLimits::default());
    let id = active(&mut e, "R");
    e.set_timer(id, TimerId(70), 10).unwrap();
    assert_eq!(e.step().unwrap().outcome, Outcome::Applied);
    assert_eq!(e.snapshot().devices[0].timers, [(TimerId(72), 11)]);
    assert_eq!(e.step().unwrap().at, 11);
    assert!(e.step().is_none());
}

#[test]
fn callback_overflow_quarantines_and_pauses_run() {
    let mut e = engine(EngineLimits {
        events: 1,
        ..EngineLimits::default()
    });
    let id = active(&mut e, "R");
    e.set_timer(id, TimerId(90), 10).unwrap();
    let result = e.run_until(100, 100).unwrap();
    assert!(result.faulted);
    assert_eq!(result.now, 10);
    assert_eq!(
        result.events[0].outcome,
        Outcome::Failed(EngineError::QueueFull)
    );
    assert_eq!(e.snapshot().devices[0].power, PowerState::Off);
    assert_eq!(e.snapshot().pending_events, 0);
}

#[test]
fn zero_delay_loop_is_budgeted() {
    let mut e = engine(EngineLimits::default());
    let id = active(&mut e, "R");
    e.set_timer(id, TimerId(80), 0).unwrap();
    let report = e.run_until(100, 20).unwrap();
    assert_eq!(report.events.len(), 20);
    assert_eq!(report.now, 0);
    assert!(report.budget_exhausted);
    assert_eq!(e.snapshot().pending_events, 1);
    e.power_off(id).unwrap();
    assert_eq!(e.run_until(100, 0).unwrap().now, 100);
    assert_eq!(e.run_until(99, 1), Err(EngineError::PastEvent));
}

#[test]
fn cli_results_and_journal_redaction() {
    let mut e = engine(EngineLimits::default());
    let id = active(&mut e, "R");
    assert!(matches!(
        e.execute(command(id, "secret password")).unwrap(),
        CommandResult::CliQueued(_)
    ));
    let failed = e.step().unwrap();
    assert_eq!(failed.outcome, Outcome::Failed(EngineError::Unsupported));
    assert_eq!(e.snapshot().devices[0].power, PowerState::On);
    assert!(!format!("{:?}", e.trace()).contains("secret password"));
    e.execute(command(id, "show")).unwrap();
    assert!(e.step().unwrap().cli_output.unwrap().starts_with("0 "));
}

#[test]
fn deterministic_rng_and_trace() {
    assert_eq!(SimRng::new(0).next_u64(), 0xe220a8397b1dcdaf);
    fn run() -> (
        netsim_engine::SimulationSnapshot,
        netsim_engine::TraceSnapshot,
        String,
    ) {
        let mut e = engine(EngineLimits::default());
        let a = active(&mut e, "A");
        let b = active(&mut e, "B");
        e.set_timer(b, TimerId(1), 10).unwrap();
        e.set_timer(a, TimerId(1), 10).unwrap();
        let report = e.run_until(10, 10).unwrap();
        assert_eq!(
            report
                .events
                .iter()
                .map(|event| event.target)
                .collect::<Vec<_>>(),
            [b, a]
        );
        e.execute(command(a, "show")).unwrap();
        let output = e.step().unwrap().cli_output.unwrap();
        (e.snapshot(), e.trace(), output)
    }
    assert_eq!(run(), run());
}

#[test]
fn time_overflow_and_reset() {
    let mut e = engine(EngineLimits::default());
    let id = active(&mut e, "A");
    e.run_until(u64::MAX, 0).unwrap();
    assert_eq!(
        e.set_timer(id, TimerId(1), 1),
        Err(EngineError::TimeOverflow)
    );
    e.reset();
    assert_eq!(e.now(), 0);
    assert!(e.snapshot().devices.is_empty());
    assert!(e.trace().entries.is_empty());
    assert!(add(&mut e, "B") > id);
}

#[test]
fn bounded_trace_drops_oldest_and_snapshots_are_independent() {
    let mut e = engine(EngineLimits {
        trace: 2,
        ..EngineLimits::default()
    });
    let id = add(&mut e, "A");
    let old = e.snapshot();
    e.power_on(id).unwrap();
    e.power_off(id).unwrap();
    let trace = e.trace();
    assert_eq!(trace.dropped, 1);
    assert_eq!(trace.entries[0].action, TraceAction::PowerOn);
    assert_eq!(old.devices[0].generation, 0);
    assert_eq!(e.snapshot().devices[0].generation, 1);
}

#[test]
fn topology_and_stale_receive() {
    let mut e = engine(EngineLimits::default());
    let a = active(&mut e, "A");
    let b = active(&mut e, "B");
    let p = e.add_port(a, MediaKind::Ethernet).unwrap();
    let q = e.add_port(b, MediaKind::Ethernet).unwrap();
    let r = e.add_port(b, MediaKind::Serial).unwrap();
    assert_eq!(e.connect(link(p, r)), Err(EngineError::InvalidInput));
    let l = e.connect(link(p, q)).unwrap();
    assert_eq!(e.connect(link(p, q)), Err(EngineError::PortBusy));
    e.schedule_receive(100, q, PacketId(1), l).unwrap();
    e.disconnect(l).unwrap();
    assert_eq!(
        e.schedule_receive(100, q, PacketId(1), l),
        Err(EngineError::UnknownLink)
    );
    let l2 = e.connect(link(p, q)).unwrap();
    assert!(l2 > l);
    let report = e.run_until(100, 100).unwrap();
    assert!(!report.events.iter().any(|event| event.kind == "receive"));
    e.schedule_receive(110, q, PacketId(2), l2).unwrap();
    e.remove_device(a).unwrap();
    assert!(e.snapshot().links.is_empty());
    assert!(e.snapshot().port(p).is_none());
    assert!(
        !e.run_until(120, 100)
            .unwrap()
            .events
            .iter()
            .any(|event| event.kind == "receive")
    );
}

#[test]
fn valid_receive_dispatches_to_model() {
    let mut e = engine(EngineLimits::default());
    let a = active(&mut e, "A");
    let b = active(&mut e, "B");
    let p = e.add_port(a, MediaKind::Ethernet).unwrap();
    let q = e.add_port(b, MediaKind::Ethernet).unwrap();
    let l = e.connect(link(p, q)).unwrap();
    e.schedule_receive(1, q, PacketId(1), l).unwrap();
    e.run_until(1, 10).unwrap();
    e.execute(command(b, "show")).unwrap();
    assert!(e.step().unwrap().cli_output.unwrap().starts_with("1 "));
}

#[test]
fn worker_replies_and_publishes() {
    let e = engine(EngineLimits::default());
    let worker = Worker::spawn(e, 2).unwrap();
    let handle = worker.handle();
    let before = handle.latest().unwrap();
    let response = handle
        .request(WorkerRequest::Execute(EngineCommand::AddDevice {
            profile_id: PROFILE.profile_id.into(),
            profile_version: 1,
            hostname: "W".into(),
        }))
        .unwrap();
    let WorkerResponse::Command(CommandResult::DeviceAdded(id)) = response else {
        panic!("unexpected response");
    };
    let rx = handle
        .try_request(WorkerRequest::Execute(EngineCommand::PowerOn(id)))
        .unwrap();
    rx.recv().unwrap().unwrap();
    assert!(before.devices.is_empty());
    assert_eq!(handle.latest().unwrap().devices[0].power, PowerState::On);
    worker.join().unwrap();
    assert!(matches!(
        handle.request(WorkerRequest::Step),
        Err(EngineError::WorkerClosed)
    ));
}

#[test]
fn disconnect_reclaims_queue_capacity() {
    let mut e = engine(EngineLimits {
        events: 2,
        ..EngineLimits::default()
    });
    let a = active(&mut e, "A");
    let b = active(&mut e, "B");
    let p = e.add_port(a, MediaKind::Ethernet).unwrap();
    let q = e.add_port(b, MediaKind::Ethernet).unwrap();
    let l = e.connect(link(p, q)).unwrap();
    assert_eq!(e.snapshot().pending_events, 2);
    e.disconnect(l).unwrap();
    assert_eq!(e.snapshot().pending_events, 2);
    assert!(e.snapshot().links.is_empty());
    assert!(
        e.run_until(0, 2)
            .unwrap()
            .events
            .iter()
            .all(|event| event.detail == netsim_engine::EventDetail::Link { id: l, up: false })
    );
}
