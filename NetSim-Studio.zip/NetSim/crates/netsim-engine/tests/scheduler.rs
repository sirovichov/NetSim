use netsim_core::{DeviceId, EngineError, EventKind};
use netsim_engine::Scheduler;

fn schedule_fixture() -> Scheduler {
    let mut scheduler = Scheduler::new(4);
    for at in [20, 10, 10, 30] {
        scheduler
            .schedule(at, DeviceId(1), 0, EventKind::DeviceBoot)
            .unwrap();
    }
    scheduler
}

#[test]
fn stable_order_and_determinism() {
    let mut first = schedule_fixture();
    let mut second = schedule_fixture();
    let a = first.run_until(40, 4).unwrap();
    let b = second.run_until(40, 4).unwrap();
    assert_eq!(a, b);
    let keys: Vec<_> = a.events.iter().map(|e| (e.at, e.sequence)).collect();
    assert_eq!(keys, [(10, 1), (10, 2), (20, 0), (30, 3)]);
    assert_eq!(a.now, 40);
    assert!(!a.budget_exhausted);
}

#[test]
fn budget_never_skips_pending_events() {
    let mut scheduler = schedule_fixture();
    let report = scheduler.run_until(40, 1).unwrap();
    assert_eq!(report.now, 10);
    assert!(report.budget_exhausted);
    let report = scheduler.run_until(40, 0).unwrap();
    assert_eq!(report.now, 10);
    assert!(report.events.is_empty());
    assert!(report.budget_exhausted);
    assert_eq!(scheduler.run_until(40, 3).unwrap().now, 40);
}

#[test]
fn rejects_past_and_capacity_without_consuming_sequence() {
    let mut scheduler = Scheduler::new(1);
    assert_eq!(
        scheduler.schedule(10, DeviceId(1), 0, EventKind::DeviceBoot),
        Ok(0)
    );
    assert_eq!(
        scheduler.schedule(20, DeviceId(1), 0, EventKind::DeviceBoot),
        Err(EngineError::QueueFull)
    );
    scheduler.step().unwrap();
    assert_eq!(
        scheduler.schedule(9, DeviceId(1), 0, EventKind::DeviceBoot),
        Err(EngineError::PastEvent)
    );
    assert_eq!(
        scheduler.schedule(10, DeviceId(1), 0, EventKind::DeviceBoot),
        Ok(1)
    );
}

#[test]
fn idle_clock_and_past_deadline() {
    let mut scheduler = Scheduler::new(0);
    assert_eq!(scheduler.run_until(100, 0).unwrap().now, 100);
    assert_eq!(scheduler.run_until(99, 1), Err(EngineError::PastEvent));
    assert!(scheduler.step().is_none());
}
