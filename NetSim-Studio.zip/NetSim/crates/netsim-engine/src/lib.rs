//! Deterministic simulation core and legacy scheduler.

mod engine;
mod event_queue;
mod scheduler;
mod snapshot;
mod trace;
mod worker;

pub use engine::{
    CommandResult, DeviceFactory, DispatchReport, Engine, EngineLimits, ProcessedEvent,
};
pub use scheduler::{RunReport, Scheduler};
pub use snapshot::{InstanceSnapshot, SimulationSnapshot};
pub use trace::{EventDetail, Outcome, TraceAction, TraceEntry, TraceSnapshot};
pub use worker::{MAX_WORKER_BATCH, Reply, Worker, WorkerHandle, WorkerRequest, WorkerResponse};

pub use engine::{FrameTx, HostSnapshot, L2Snapshot};
pub use netsim_packet::ethernet::{EthernetFrame, Tag};
pub use netsim_protocols::bridge::{BridgeSnapshot, PortMode, PortState, Role};

pub use engine::{
    InterfaceConfig, InterfaceKey, IpInterfaceSnapshot, IpNodeSnapshot, L3Snapshot, Probe,
    ProbeStatus, Route, RouteOrigin,
};
pub use netsim_packet::ipv4::{IcmpMessage, IpError, Ipv4Packet};
pub use netsim_protocols::Ipv4Prefix;

pub use engine::{DhcpPhase, DhcpPool, DhcpStatus, OspfStatus};
