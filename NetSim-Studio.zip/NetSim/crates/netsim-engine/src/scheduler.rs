use crate::event_queue::EventQueue;
use netsim_core::{DeviceId, EngineError, EventKind, SimEvent, SimTime};

#[derive(Debug, PartialEq, Eq)]
pub struct RunReport {
    pub events: Vec<SimEvent>,
    pub now: SimTime,
    pub budget_exhausted: bool,
}

/// A bounded queue and virtual clock. Consuming events does not dispatch devices yet.
pub struct Scheduler {
    now: SimTime,
    next_sequence: u64,
    capacity: usize,
    queue: EventQueue,
}

impl Scheduler {
    pub fn new(capacity: usize) -> Self {
        Self {
            now: 0,
            next_sequence: 0,
            capacity,
            queue: EventQueue::default(),
        }
    }

    pub fn now(&self) -> SimTime {
        self.now
    }

    pub(crate) fn next_time(&self) -> Option<SimTime> {
        self.queue.peek().map(|e| e.at)
    }

    pub fn pending(&self) -> usize {
        self.queue.len()
    }

    pub fn schedule(
        &mut self,
        at: SimTime,
        target: DeviceId,
        generation: u64,
        kind: EventKind,
    ) -> Result<u64, EngineError> {
        if at < self.now {
            return Err(EngineError::PastEvent);
        }
        if self.pending() >= self.capacity {
            return Err(EngineError::QueueFull);
        }
        let sequence = self.next_sequence;
        self.next_sequence = sequence
            .checked_add(1)
            .ok_or(EngineError::SequenceExhausted)?;
        self.queue.push(SimEvent {
            at,
            sequence,
            target,
            generation,
            kind,
        });
        Ok(sequence)
    }

    pub fn step(&mut self) -> Option<SimEvent> {
        let event = self.queue.pop()?;
        self.now = event.at;
        Some(event)
    }

    /// Advance to deadline only when no pending event at or before it remains.
    pub fn run_until(
        &mut self,
        deadline: SimTime,
        budget: usize,
    ) -> Result<RunReport, EngineError> {
        if deadline < self.now {
            return Err(EngineError::PastEvent);
        }
        let mut events = Vec::new();
        while events.len() < budget && self.has_due_event(deadline) {
            if let Some(event) = self.step() {
                events.push(event);
            }
        }
        let budget_exhausted = self.has_due_event(deadline);
        if !budget_exhausted {
            self.now = deadline;
        }
        Ok(RunReport {
            events,
            now: self.now,
            budget_exhausted,
        })
    }

    pub(crate) fn count_where(&self, predicate: impl FnMut(&SimEvent) -> bool) -> usize {
        self.queue.count_where(predicate)
    }

    pub(crate) fn retain(&mut self, keep: impl FnMut(&SimEvent) -> bool) {
        self.queue.retain(keep);
    }

    pub(crate) fn check_batch(&self, count: usize, removed: usize) -> Result<(), EngineError> {
        if self.pending().saturating_sub(removed).saturating_add(count) > self.capacity {
            return Err(EngineError::QueueFull);
        }
        self.next_sequence
            .checked_add(u64::try_from(count).map_err(|_| EngineError::SequenceExhausted)?)
            .ok_or(EngineError::SequenceExhausted)?;
        Ok(())
    }

    pub(crate) fn has_due_event(&self, deadline: SimTime) -> bool {
        self.queue.peek().is_some_and(|event| event.at <= deadline)
    }
}
