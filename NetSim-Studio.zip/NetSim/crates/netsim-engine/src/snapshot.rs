use netsim_core::{DeviceId, LinkId, PortId, PowerState, SimTime, TimerId};
use netsim_devices::DeviceDescriptor;
use netsim_topology::{Link, Port};

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct InstanceSnapshot {
    pub id: DeviceId,
    pub descriptor: DeviceDescriptor,
    pub hostname: String,
    pub power: PowerState,
    pub generation: u64,
    pub timers: Vec<(TimerId, SimTime)>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SimulationSnapshot {
    pub now: SimTime,
    pub pending_events: usize,
    pub seed: u64,
    pub rng_version: u32,
    pub devices: Vec<InstanceSnapshot>,
    pub ports: Vec<Port>,
    /// Administrative shutdown is separate from physical link presence.
    pub admin_down: Vec<PortId>,
    pub links: Vec<(LinkId, Link)>,
    pub l2: crate::L2Snapshot,
    pub l3: crate::L3Snapshot,
}

impl SimulationSnapshot {
    pub fn port(&self, id: PortId) -> Option<&Port> {
        self.ports.iter().find(|port| port.id == id)
    }
}
