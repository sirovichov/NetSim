mod l2;
mod l3;
mod management;
mod services;
use crate::Scheduler;
use crate::snapshot::{InstanceSnapshot, SimulationSnapshot};
use crate::trace::{EventDetail, Outcome, Trace, TraceAction, TraceEntry, TraceSnapshot};
pub use l2::{FrameTx, HostSnapshot, L2Snapshot};
pub use l3::{
    InterfaceConfig, InterfaceKey, IpInterfaceSnapshot, IpNodeSnapshot, L3Snapshot, Probe,
    ProbeStatus, Route, RouteOrigin,
};
use netsim_core::*;
use netsim_devices::{
    DeviceContext, DeviceDescriptor, DeviceEffect, LocalPort, NetworkDevice, SimRng,
};
use netsim_topology::{Link, Port};
pub use services::{DhcpPhase, DhcpPool, DhcpStatus, OspfStatus};
use std::collections::{BTreeMap, BTreeSet};

pub type DeviceFactory = fn(DeviceId, DeviceDescriptor, String) -> Box<dyn NetworkDevice>;

#[derive(Clone, Copy, Debug)]
pub struct EngineLimits {
    pub devices: usize,
    pub ports: usize,
    pub links: usize,
    pub events: usize,
    pub trace: usize,
    pub effects_per_callback: usize,
}

impl Default for EngineLimits {
    fn default() -> Self {
        Self {
            devices: 1000,
            ports: 64_000,
            links: 5000,
            events: 100_000,
            trace: 10_000,
            effects_per_callback: 256,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum CommandResult {
    Done,
    DeviceAdded(DeviceId),
    LinkAdded(LinkId),
    CliQueued(u64),
    ProbeStarted(u32),
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ProcessedEvent {
    pub at: SimTime,
    pub sequence: u64,
    pub target: DeviceId,
    pub kind: &'static str,
    pub detail: EventDetail,
    pub outcome: Outcome,
    pub cli_output: Option<String>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DispatchReport {
    pub events: Vec<ProcessedEvent>,
    pub now: SimTime,
    pub budget_exhausted: bool,
    pub faulted: bool,
}

struct Timer {
    generation: u64,
    at: SimTime,
}

struct Instance {
    model: Box<dyn NetworkDevice>,
    hostname_override: Option<String>,
    power: PowerState,
    generation: u64,
    timers: BTreeMap<TimerId, Timer>,
}

/// Single-owner virtual machine. No wall-clock or network I/O.
pub struct Engine {
    limits: EngineLimits,
    seed: u64,
    rng: SimRng,
    scheduler: Scheduler,
    trace: Trace,
    capture: netsim_capture::Capture,
    profiles: BTreeMap<(&'static str, u32), (DeviceDescriptor, DeviceFactory)>,
    devices: BTreeMap<DeviceId, Instance>,
    ports: BTreeMap<PortId, Port>,
    links: BTreeMap<LinkId, Link>,
    admin_down: BTreeSet<PortId>,
    next_device: u64,
    next_port: u64,
    next_link: u64,
    next_timer: u64,
    l2: l2::L2State,
    l3: l3::L3State,
    services: services::ServiceState,
}

impl Engine {
    pub fn new(seed: u64, limits: EngineLimits) -> Self {
        Self {
            limits,
            seed,
            rng: SimRng::new(seed),
            scheduler: Scheduler::new(limits.events),
            trace: Trace::new(limits.trace),
            capture: netsim_capture::Capture::default(),
            profiles: BTreeMap::new(),
            devices: BTreeMap::new(),
            ports: BTreeMap::new(),
            links: BTreeMap::new(),
            admin_down: BTreeSet::new(),
            next_device: 1,
            next_port: 1,
            next_link: 1,
            next_timer: 1,
            l2: l2::L2State::default(),
            l3: l3::L3State::default(),
            services: services::ServiceState::default(),
        }
    }

    pub fn next_event_time(&self) -> Option<SimTime> {
        self.scheduler.next_time()
    }

    pub fn capture(&self) -> &netsim_capture::Capture {
        &self.capture
    }

    pub fn now(&self) -> SimTime {
        self.scheduler.now()
    }

    pub fn register_profile(
        &mut self,
        descriptor: DeviceDescriptor,
        factory: DeviceFactory,
    ) -> Result<(), EngineError> {
        let key = (descriptor.profile_id, descriptor.profile_version);
        if self.profiles.contains_key(&key) {
            return Err(EngineError::DuplicateProfile);
        }
        self.profiles.insert(key, (descriptor, factory));
        Ok(())
    }

    pub fn add_device(
        &mut self,
        profile: &str,
        version: u32,
        hostname: String,
    ) -> Result<DeviceId, EngineError> {
        if self.devices.len() >= self.limits.devices {
            return Err(EngineError::ResourceLimit);
        }
        if hostname.is_empty() || hostname.len() > 255 || hostname.chars().any(char::is_control) {
            return Err(EngineError::InvalidInput);
        }
        let (descriptor, factory) = self
            .profiles
            .values()
            .find(|(d, _)| d.profile_id == profile && d.profile_version == version)
            .copied()
            .ok_or(EngineError::UnknownProfile)?;
        let id = DeviceId(self.next_device);
        let next = self
            .next_device
            .checked_add(1)
            .ok_or(EngineError::SequenceExhausted)?;
        let model = factory(id, descriptor, hostname);
        if model.id() != id || *model.descriptor() != descriptor {
            return Err(EngineError::InvalidInput);
        }
        self.next_device = next;
        self.devices.insert(
            id,
            Instance {
                model,
                hostname_override: None,
                power: PowerState::Off,
                generation: 0,
                timers: BTreeMap::new(),
            },
        );
        self.record(id, TraceAction::Added, Outcome::Applied);
        Ok(id)
    }

    /// Explicit virtual ports for custom models; draft profiles do not auto-create ports.
    pub fn add_port(&mut self, device: DeviceId, media: MediaKind) -> Result<PortId, EngineError> {
        if !self.devices.contains_key(&device) {
            return Err(EngineError::UnknownDevice);
        }
        if self.ports.len() >= self.limits.ports {
            return Err(EngineError::ResourceLimit);
        }
        let id = PortId(self.next_port);
        self.next_port = self
            .next_port
            .checked_add(1)
            .ok_or(EngineError::SequenceExhausted)?;
        self.ports.insert(id, Port { id, device, media });
        Ok(id)
    }

    pub fn connect(&mut self, mut link: Link) -> Result<LinkId, EngineError> {
        if self.links.len() >= self.limits.links {
            return Err(EngineError::ResourceLimit);
        }
        if !link.is_valid() {
            return Err(EngineError::InvalidInput);
        }
        let a = self
            .ports
            .get(&link.endpoints[0])
            .ok_or(EngineError::UnknownPort)?;
        let b = self
            .ports
            .get(&link.endpoints[1])
            .ok_or(EngineError::UnknownPort)?;
        if a.media != b.media || a.media == MediaKind::Wireless {
            return Err(EngineError::InvalidInput);
        }
        if self
            .links
            .values()
            .any(|l| l.endpoints.iter().any(|p| link.endpoints.contains(p)))
        {
            return Err(EngineError::PortBusy);
        }
        let id = LinkId(self.next_link);
        let next = self
            .next_link
            .checked_add(1)
            .ok_or(EngineError::SequenceExhausted)?;
        let targets = self.active_endpoints(&link);
        self.scheduler.check_batch(targets.len(), 0)?;
        link.id = id;
        self.next_link = next;
        self.links.insert(id, link);
        self.sync_all_l2();
        for (target, generation) in targets {
            self.scheduler.schedule(
                self.now(),
                target,
                generation,
                EventKind::LinkChanged { link: id, up: true },
            )?;
        }
        Ok(id)
    }

    fn active_endpoints(&self, link: &Link) -> Vec<(DeviceId, u64)> {
        let mut targets = BTreeMap::new();
        for port in link.endpoints {
            if let Some((p, d)) = self
                .ports
                .get(&port)
                .and_then(|p| self.devices.get(&p.device).map(|d| (p, d)))
                .filter(|(_, d)| d.power == PowerState::On)
            {
                targets.insert(p.device, d.generation);
            }
        }
        targets.into_iter().collect()
    }

    pub fn disconnect(&mut self, id: LinkId) -> Result<(), EngineError> {
        let link = self.links.get(&id).ok_or(EngineError::UnknownLink)?;
        let targets = self.active_endpoints(link);
        // Account for events that are purged by this same atomic mutation.
        let removed = self
            .scheduler
            .count_where(|event| references_link(event, id));
        self.scheduler.check_batch(targets.len(), removed)?;
        self.links.remove(&id);
        self.l2.forget_link(id);
        self.purge_link(id);
        self.sync_all_l2();
        for (target, generation) in targets {
            self.scheduler.schedule(
                self.now(),
                target,
                generation,
                EventKind::LinkChanged {
                    link: id,
                    up: false,
                },
            )?;
        }
        Ok(())
    }

    fn purge_link(&mut self, id: LinkId) {
        self.scheduler.retain(|event| !references_link(event, id));
    }

    pub fn remove_device(&mut self, id: DeviceId) -> Result<(), EngineError> {
        if !self.devices.contains_key(&id) {
            return Err(EngineError::UnknownDevice);
        }
        let links: Vec<_> = self
            .links
            .iter()
            .filter(|(_, l)| l.endpoints.iter().any(|p| self.ports[p].device == id))
            .map(|(id, _)| *id)
            .collect();
        // Reserve peer notifications atomically (at most one per attached link).
        let notices: Vec<_> = links
            .iter()
            .flat_map(|link| {
                self.active_endpoints(&self.links[link])
                    .into_iter()
                    .filter(move |(target, _)| *target != id)
                    .map(move |(target, generation)| (*link, target, generation))
            })
            .collect();
        let removed = self.scheduler.count_where(|event| {
            event.target == id || links.iter().any(|link| references_link(event, *link))
        });
        self.scheduler.check_batch(notices.len(), removed)?;
        self.scheduler.retain(|e| e.target != id);
        for link in links {
            self.links.remove(&link);
            self.l2.forget_link(link);
            self.purge_link(link);
        }
        self.admin_down
            .retain(|p| self.ports.get(p).is_some_and(|port| port.device != id));
        self.ports.retain(|_, p| p.device != id);
        self.devices.remove(&id);
        self.l2.remove_device(id);
        self.l3.remove(id);
        self.services.remove(id);
        self.sync_all_l2();
        for (link, target, generation) in notices {
            self.scheduler.schedule(
                self.now(),
                target,
                generation,
                EventKind::LinkChanged { link, up: false },
            )?;
        }
        self.record(id, TraceAction::Removed, Outcome::Applied);
        Ok(())
    }

    pub fn power_on(&mut self, id: DeviceId) -> Result<(), EngineError> {
        let d = self.devices.get(&id).ok_or(EngineError::UnknownDevice)?;
        if d.power == PowerState::On {
            return Err(EngineError::InvalidState);
        }
        let generation = d
            .generation
            .checked_add(1)
            .ok_or(EngineError::SequenceExhausted)?;
        let d = self
            .devices
            .get_mut(&id)
            .ok_or(EngineError::UnknownDevice)?;
        d.generation = generation;
        d.power = PowerState::On;
        let result = self
            .callback(id, EventKind::DeviceBoot)
            .map(|_| ())
            .and_then(|()| self.start_l2(id))
            .and_then(|()| self.start_l3(id));
        let result = self.finish_lifecycle(id, TraceAction::PowerOn, result);
        self.sync_all_l2();
        result
    }

    pub fn power_off(&mut self, id: DeviceId) -> Result<(), EngineError> {
        let d = self.devices.get(&id).ok_or(EngineError::UnknownDevice)?;
        if d.power == PowerState::Off {
            return Err(EngineError::InvalidState);
        }
        // Shutdown runs synchronously, then all queued work is invalidated.
        let result = self.callback(id, EventKind::DeviceShutdown).map(|_| ());
        self.quarantine(id);
        self.finish_lifecycle(id, TraceAction::PowerOff, result)
    }

    fn finish_lifecycle(
        &mut self,
        id: DeviceId,
        action: TraceAction,
        result: Result<(), EngineError>,
    ) -> Result<(), EngineError> {
        if let Err(error) = result {
            self.quarantine(id);
            self.record(id, action, Outcome::Failed(error));
            return Err(error);
        }
        self.record(id, action, Outcome::Applied);
        Ok(())
    }

    fn quarantine(&mut self, id: DeviceId) {
        if let Some(d) = self.devices.get_mut(&id) {
            d.power = PowerState::Off;
            d.timers.clear();
        }
        let outgoing: Vec<_> = self
            .ports
            .values()
            .filter(|p| p.device == id)
            .map(|p| p.id)
            .collect();
        self.scheduler.retain(|e| e.target != id);
        self.scheduler.retain(|e| !matches!(&e.kind, EventKind::FrameReceive { source, .. } if outgoing.contains(source)));
        for port in outgoing {
            self.l2.clear_direction(port);
        }
        self.l2.reset_device(id);
        self.l3.reset_device(id);
        if self.services.client(id) {
            self.clear_dhcp_address(id);
        }
        self.services.reset(id);
        self.sync_all_l2();
    }

    fn active_generation(&self, id: DeviceId) -> Result<u64, EngineError> {
        let d = self.devices.get(&id).ok_or(EngineError::UnknownDevice)?;
        if d.power != PowerState::On {
            return Err(EngineError::InvalidState);
        }
        Ok(d.generation)
    }

    pub fn set_timer(
        &mut self,
        id: DeviceId,
        timer: TimerId,
        delay: SimTime,
    ) -> Result<(), EngineError> {
        self.active_generation(id)?;
        let at = self
            .now()
            .checked_add(delay)
            .ok_or(EngineError::TimeOverflow)?;
        self.apply_effects(id, vec![DeviceEffect::SetTimer { timer, at }])
    }

    pub fn cancel_timer(&mut self, id: DeviceId, timer: TimerId) -> Result<(), EngineError> {
        self.active_generation(id)?;
        self.apply_effects(id, vec![DeviceEffect::CancelTimer(timer)])
    }

    /// Opaque receive notification only. No frame bytes or forwarding in WP2.
    /// Link IDs never repeat; the ID is also its generation token.
    pub fn schedule_receive(
        &mut self,
        at: SimTime,
        port: PortId,
        packet: PacketId,
        link: LinkId,
    ) -> Result<u64, EngineError> {
        let p = self.ports.get(&port).ok_or(EngineError::UnknownPort)?;
        let l = self.links.get(&link).ok_or(EngineError::UnknownLink)?;
        if !l.endpoints.contains(&port) {
            return Err(EngineError::InvalidInput);
        }
        let target = p.device;
        let generation = self.active_generation(target)?;
        self.scheduler.schedule(
            at,
            target,
            generation,
            EventKind::PacketReceive {
                port,
                packet,
                link,
                link_generation: link.0,
            },
        )
    }

    pub fn execute(&mut self, command: EngineCommand) -> Result<CommandResult, EngineError> {
        match command {
            EngineCommand::AddDevice {
                profile_id,
                profile_version,
                hostname,
            } => self
                .add_device(&profile_id, profile_version, hostname)
                .map(CommandResult::DeviceAdded),
            EngineCommand::RemoveDevice(id) => self.remove_device(id).map(|()| CommandResult::Done),
            EngineCommand::PowerOn(id) => self.power_on(id).map(|()| CommandResult::Done),
            EngineCommand::PowerOff(id) => self.power_off(id).map(|()| CommandResult::Done),
            EngineCommand::Reboot(id) => {
                self.power_off(id)?;
                self.power_on(id)?;
                Ok(CommandResult::Done)
            }
            EngineCommand::ConnectPorts {
                endpoints,
                bandwidth_bps,
                delay_ns,
                loss_ppm,
                queue_limit_bytes,
            } => self
                .connect(Link {
                    id: LinkId(0),
                    endpoints,
                    bandwidth_bps,
                    delay_ns,
                    loss_ppm,
                    queue_limit_bytes,
                })
                .map(CommandResult::LinkAdded),
            EngineCommand::DisconnectLink(id) => self.disconnect(id).map(|()| CommandResult::Done),
            EngineCommand::ExecuteCli {
                device,
                session,
                command,
            } => {
                if command.len() > 4096 {
                    return Err(EngineError::InvalidInput);
                }
                let generation = self.active_generation(device)?;
                self.scheduler
                    .schedule(
                        self.now(),
                        device,
                        generation,
                        EventKind::CliCommand { session, command },
                    )
                    .map(CommandResult::CliQueued)
            }
            EngineCommand::Reset => {
                self.reset();
                Ok(CommandResult::Done)
            }
            EngineCommand::SendPacket {
                source,
                destination,
            } => self
                .ping(source, destination, 64, 5_000_000_000)
                .map(CommandResult::ProbeStarted),
            EngineCommand::ApplyConfig { .. } => Err(EngineError::Unsupported),
        }
    }

    /// Reset opens a new simulation epoch. Profiles and monotonic instance IDs survive.
    pub fn reset(&mut self) {
        self.l2 = l2::L2State::default();
        self.l3 = l3::L3State::default();
        self.services = services::ServiceState::default();
        self.devices.clear();
        self.ports.clear();
        self.links.clear();
        self.admin_down.clear();
        self.scheduler = Scheduler::new(self.limits.events);
        self.trace = Trace::new(self.limits.trace);
        self.capture = netsim_capture::Capture::default();
        self.rng = SimRng::new(self.seed);
    }

    fn callback(&mut self, id: DeviceId, kind: EventKind) -> Result<Option<String>, EngineError> {
        let ports = self
            .ports
            .values()
            .filter(|port| port.device == id)
            .map(|port| LocalPort {
                id: port.id,
                media: port.media,
                link: self
                    .links
                    .values()
                    .find(|link| link.endpoints.contains(&port.id))
                    .map(|link| link.id),
            })
            .collect();
        let mut ctx = DeviceContext::with_seed(
            self.now(),
            self.rng.next_u64(),
            self.limits.effects_per_callback,
        )
        .with_ports(ports);
        let model = &mut self
            .devices
            .get_mut(&id)
            .ok_or(EngineError::UnknownDevice)?
            .model;
        let shutdown = matches!(&kind, EventKind::DeviceShutdown);
        let output = match kind {
            EventKind::CliCommand { session, command } => {
                Some(model.execute_cli(session, &command, &mut ctx)?)
            }
            other => {
                model.on_event(other, &mut ctx)?;
                None
            }
        };
        if !shutdown {
            self.apply_effects(id, ctx.into_effects())?;
        }
        Ok(output)
    }

    /// Last effect per timer wins; ordering follows the final request positions.
    /// Validate the entire batch before touching scheduler or timer state.
    fn apply_effects(
        &mut self,
        id: DeviceId,
        effects: Vec<DeviceEffect>,
    ) -> Result<(), EngineError> {
        if effects.is_empty() {
            return Ok(());
        }
        let generation = self.active_generation(id)?;
        let mut plan = BTreeMap::new();
        for (index, effect) in effects.into_iter().enumerate() {
            match effect {
                DeviceEffect::SetTimer { timer, at } => {
                    if at < self.now() {
                        return Err(EngineError::PastEvent);
                    }
                    plan.insert(timer, (index, Some(at)));
                }
                DeviceEffect::CancelTimer(timer) => {
                    plan.insert(timer, (index, None));
                }
            }
        }
        let removed = plan
            .keys()
            .filter(|timer| self.devices[&id].timers.contains_key(*timer))
            .count();
        let count = plan.values().filter(|(_, at)| at.is_some()).count();
        self.scheduler.check_batch(count, removed)?;
        self.next_timer
            .checked_add(u64::try_from(count).map_err(|_| EngineError::SequenceExhausted)?)
            .ok_or(EngineError::SequenceExhausted)?;
        if removed != 0 {
            self.scheduler.retain(|event| {
                !(event.target == id
                    && matches!(&event.kind,
                EventKind::TimerExpired { timer, .. } if plan.contains_key(timer)))
            });
        }
        let mut ordered: Vec<_> = plan.into_iter().collect();
        ordered.sort_by_key(|(_, (index, _))| *index);
        for (timer, (_, at)) in ordered {
            let timers = &mut self
                .devices
                .get_mut(&id)
                .ok_or(EngineError::UnknownDevice)?
                .timers;
            timers.remove(&timer);
            if let Some(at) = at {
                let token = self.next_timer;
                self.next_timer += 1;
                self.scheduler.schedule(
                    at,
                    id,
                    generation,
                    EventKind::TimerExpired {
                        timer,
                        generation: token,
                    },
                )?;
                timers.insert(
                    timer,
                    Timer {
                        generation: token,
                        at,
                    },
                );
            }
        }
        Ok(())
    }

    pub fn step(&mut self) -> Option<ProcessedEvent> {
        let event = self.scheduler.step()?;
        let kind = event_name(&event.kind);
        let detail = EventDetail::from(&event.kind);
        let id = event.target;
        let valid_device = self
            .devices
            .get(&id)
            .is_some_and(|d| d.power == PowerState::On && d.generation == event.generation);
        let valid = valid_device
            && match &event.kind {
                EventKind::TimerExpired { timer, generation } => self.devices[&id]
                    .timers
                    .get(timer)
                    .is_some_and(|t| t.generation == *generation),
                EventKind::PacketReceive {
                    port,
                    link,
                    link_generation,
                    ..
                } => {
                    *link_generation == link.0
                        && self
                            .links
                            .get(link)
                            .is_some_and(|l| l.endpoints.contains(port))
                        && self.ports.get(port).is_some_and(|p| p.device == id)
                }
                EventKind::FrameReceive {
                    port,
                    link,
                    source,
                    source_generation,
                    ..
                } => {
                    self.links
                        .get(link)
                        .is_some_and(|l| l.endpoints.contains(port) && l.endpoints.contains(source))
                        && !self.admin_down.contains(port)
                        && !self.admin_down.contains(source)
                        && self.ports.get(port).is_some_and(|p| p.device == id)
                        && self.ports.get(source).is_some_and(|p| {
                            self.active_generation(p.device) == Ok(*source_generation)
                        })
                }
                EventKind::LinkChanged { link, up } => self.links.contains_key(link) == *up,
                _ => true,
            };
        let mut cli_output = None;
        let outcome = if valid {
            if let EventKind::TimerExpired { timer, .. } = &event.kind {
                if let Some(d) = self.devices.get_mut(&id) {
                    d.timers.remove(timer);
                }
            }
            let result = match event.kind {
                EventKind::FrameReceive { port, bytes, .. } => {
                    self.receive_l2(id, port, &bytes).map(|()| None)
                }
                EventKind::L2Tick => self.tick_l2(id).map(|()| None),
                EventKind::L3Tick => self.tick_l3(id).map(|()| None),
                other => {
                    let link_change = matches!(&other, EventKind::LinkChanged { .. });
                    let result = self.callback(id, other);
                    if link_change && result.is_ok() {
                        self.sync_l2(id);
                    }
                    result
                }
            };
            match result {
                Ok(output) => {
                    cli_output = output;
                    Outcome::Applied
                }
                // Unsupported CLI is not a device failure. No queued effects committed.
                Err(EngineError::Unsupported) if kind == "cli" => {
                    Outcome::Failed(EngineError::Unsupported)
                }
                Err(error) => {
                    self.quarantine(id);
                    Outcome::Failed(error)
                }
            }
        } else {
            Outcome::Skipped
        };
        self.record(
            id,
            TraceAction::Event {
                sequence: event.sequence,
                kind,
                detail,
            },
            outcome,
        );
        Some(ProcessedEvent {
            at: event.at,
            sequence: event.sequence,
            target: id,
            kind,
            detail,
            outcome,
            cli_output,
        })
    }

    pub fn run_until(
        &mut self,
        deadline: SimTime,
        budget: usize,
    ) -> Result<DispatchReport, EngineError> {
        if deadline < self.now() {
            return Err(EngineError::PastEvent);
        }
        let mut events = Vec::new();
        let mut faulted = false;
        while events.len() < budget && self.scheduler.has_due_event(deadline) {
            if let Some(event) = self.step() {
                faulted = matches!(event.outcome, Outcome::Failed(error) if error != EngineError::Unsupported || event.kind != "cli");
                events.push(event);
                if faulted {
                    break;
                }
            }
        }
        let budget_exhausted = events.len() == budget && self.scheduler.has_due_event(deadline);
        if !faulted && !self.scheduler.has_due_event(deadline) {
            self.scheduler.run_until(deadline, 0)?;
        }
        Ok(DispatchReport {
            events,
            now: self.now(),
            budget_exhausted,
            faulted,
        })
    }

    fn record(&mut self, device: DeviceId, action: TraceAction, outcome: Outcome) {
        self.trace.push(TraceEntry {
            at: self.scheduler.now(),
            device,
            action,
            outcome,
        });
    }

    pub fn snapshot(&self) -> SimulationSnapshot {
        SimulationSnapshot {
            now: self.now(),
            pending_events: self.scheduler.pending(),
            seed: self.seed,
            rng_version: 1,
            devices: self
                .devices
                .iter()
                .map(|(id, d)| InstanceSnapshot {
                    id: *id,
                    descriptor: *d.model.descriptor(),
                    hostname: d
                        .hostname_override
                        .clone()
                        .unwrap_or_else(|| d.model.snapshot().hostname),
                    power: d.power,
                    generation: d.generation,
                    timers: d.timers.iter().map(|(id, t)| (*id, t.at)).collect(),
                })
                .collect(),
            ports: self.ports.values().cloned().collect(),
            admin_down: self.admin_down.iter().copied().collect(),
            links: self
                .links
                .iter()
                .map(|(id, link)| (*id, link.clone()))
                .collect(),
            l2: self.l2_snapshot(),
            l3: self.l3_snapshot(),
        }
    }

    pub fn trace(&self) -> TraceSnapshot {
        self.trace.snapshot()
    }
}

fn references_link(event: &SimEvent, id: LinkId) -> bool {
    matches!(&event.kind,
        EventKind::PacketReceive { link, .. } | EventKind::FrameReceive { link, .. } | EventKind::LinkChanged { link, .. } if *link == id)
}

fn event_name(kind: &EventKind) -> &'static str {
    match kind {
        EventKind::PacketReceive { .. } => "receive",
        EventKind::FrameReceive { .. } => "frame",
        EventKind::L2Tick => "stp-tick",
        EventKind::L3Tick => "ipv4-tick",
        EventKind::TimerExpired { .. } => "timer",
        EventKind::LinkChanged { .. } => "link",
        EventKind::DeviceBoot => "boot",
        EventKind::DeviceShutdown => "shutdown",
        EventKind::CliCommand { .. } => "cli",
        EventKind::ConfigChanged => "config",
    }
}
