//! Per-node IPv4 forwarding and ICMP diagnostics over the DES Ethernet medium.
use super::*;
use netsim_packet::ethernet::{ARP, EthernetFrame, Tag};
use netsim_packet::ipv4::{ICMP, IPV4, IcmpMessage, Ipv4Packet, quote, quoted_echo};
use netsim_protocols::Ipv4Prefix;
use netsim_protocols::arp::{Arp, ArpCache, Operation};
pub use netsim_protocols::routing::{InterfaceConfig, InterfaceKey, Route, RouteOrigin};
use netsim_protocols::routing::{lookup, unicast, usable};
use std::net::Ipv4Addr;

const SEC: SimTime = 1_000_000_000;
const MAX_PENDING: usize = 128;
const MAX_PROBES: usize = 256;
const MAX_ROUTES: usize = 4096;
const MAX_INTERFACES: usize = 256;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ProbeStatus {
    Pending,
    Reply {
        from: Ipv4Addr,
        rtt_ns: SimTime,
    },
    TimeExceeded {
        from: Ipv4Addr,
        rtt_ns: SimTime,
    },
    Unreachable {
        from: Ipv4Addr,
        code: u8,
        rtt_ns: SimTime,
    },
    NoRoute,
    Timeout,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Probe {
    pub token: u32,
    pub source: Ipv4Addr,
    pub destination: Ipv4Addr,
    pub ttl: u8,
    pub started: SimTime,
    pub deadline: SimTime,
    pub status: ProbeStatus,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct IpInterfaceSnapshot {
    pub config: InterfaceConfig,
    pub active: bool,
    pub arp: Vec<(Ipv4Addr, MacAddress, SimTime)>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct IpNodeSnapshot {
    pub device: DeviceId,
    pub forwarding: bool,
    pub interfaces: Vec<IpInterfaceSnapshot>,
    pub routes: Vec<Route>,
    pub probes: Vec<Probe>,
    pub pending_packets: usize,
    pub forwarded: u64,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct L3Snapshot {
    pub nodes: Vec<IpNodeSnapshot>,
}

struct Interface {
    config: InterfaceConfig,
    cache: ArpCache,
    active: bool,
}

struct Pending {
    key: InterfaceKey,
    next: Ipv4Addr,
    packet: Ipv4Packet,
    expires: SimTime,
}

struct Resolution {
    attempts: u8,
    next_retry: SimTime,
}

struct Node {
    forwarding: bool,
    interfaces: BTreeMap<InterfaceKey, Interface>,
    static_routes: Vec<Route>,
    ospf_routes: Vec<Route>,
    pending: Vec<Pending>,
    resolutions: BTreeMap<(InterfaceKey, Ipv4Addr), Resolution>,
    probes: BTreeMap<u32, Probe>,
    forwarded: u64,
}

impl Node {
    fn new(forwarding: bool) -> Self {
        Self {
            forwarding,
            interfaces: BTreeMap::new(),
            static_routes: Vec::new(),
            ospf_routes: Vec::new(),
            pending: Vec::new(),
            resolutions: BTreeMap::new(),
            probes: BTreeMap::new(),
            forwarded: 0,
        }
    }

    fn routes(&self) -> Vec<Route> {
        let mut routes: Vec<_> = self
            .interfaces
            .values()
            .filter_map(|iface| {
                Some(Route {
                    prefix: iface.config.prefix()?,
                    interface: iface.config.key,
                    next_hop: None,
                    distance: 0,
                    metric: 0,
                    origin: RouteOrigin::Connected,
                })
            })
            .collect();
        routes.extend_from_slice(&self.static_routes);
        routes.extend_from_slice(&self.ospf_routes);
        routes
    }

    fn reset(&mut self) {
        for iface in self.interfaces.values_mut() {
            iface.cache = ArpCache::default();
            iface.active = false;
        }
        self.ospf_routes.clear();
        self.pending.clear();
        self.resolutions.clear();
        self.probes.clear();
        self.forwarded = 0;
    }
}

#[derive(Default)]
pub(super) struct L3State {
    nodes: BTreeMap<DeviceId, Node>,
    next_probe: u32,
}

impl L3State {
    pub(super) fn contains(&self, id: DeviceId) -> bool {
        self.nodes.contains_key(&id)
    }
    pub(super) fn remove(&mut self, id: DeviceId) {
        self.nodes.remove(&id);
    }
    pub(super) fn reset_device(&mut self, id: DeviceId) {
        if let Some(node) = self.nodes.get_mut(&id) {
            node.reset();
        }
    }
    pub(super) fn mac_in_use(&self, mac: MacAddress) -> bool {
        self.nodes
            .values()
            .any(|n| n.interfaces.values().any(|i| i.config.mac == mac))
    }
}

fn ip_frame(
    config: InterfaceConfig,
    dst: MacAddress,
    packet: &Ipv4Packet,
) -> Option<EthernetFrame> {
    Some(EthernetFrame {
        dst,
        src: config.mac,
        tag: config.key.vlan.map(|vid| Tag {
            vid,
            pcp: 0,
            dei: false,
        }),
        kind: IPV4,
        payload: packet.encode().ok()?,
    })
}

fn arp_frame(
    config: InterfaceConfig,
    ip: Ipv4Addr,
    target: MacAddress,
    operation: Operation,
) -> EthernetFrame {
    EthernetFrame {
        dst: if operation == Operation::Request {
            MacAddress::BROADCAST
        } else {
            target
        },
        src: config.mac,
        tag: config.key.vlan.map(|vid| Tag {
            vid,
            pcp: 0,
            dei: false,
        }),
        kind: ARP,
        payload: Arp {
            operation,
            sender_mac: config.mac,
            sender_ip: config.address,
            target_mac: target,
            target_ip: ip,
        }
        .encode(),
    }
}

fn icmp_packet(src: Ipv4Addr, dst: Ipv4Addr, ttl: u8, message: IcmpMessage) -> Ipv4Packet {
    Ipv4Packet {
        src,
        dst,
        ttl,
        protocol: ICMP,
        identification: 0,
        dscp_ecn: 0,
        dont_fragment: true,
        payload: message.encode(),
    }
}

fn status_at(probe: Probe, now: SimTime) -> Probe {
    if probe.status == ProbeStatus::Pending && now >= probe.deadline {
        Probe {
            status: ProbeStatus::Timeout,
            ..probe
        }
    } else {
        probe
    }
}

impl Engine {
    /// Single-homed IPv4 endpoint. Also attaches the legacy host component for L2 observations.
    pub fn configure_ipv4_host(
        &mut self,
        id: DeviceId,
        config: InterfaceConfig,
        gateway: Option<Ipv4Addr>,
    ) -> Result<(), EngineError> {
        self.require_off(id)?;
        if config.key.vlan.is_some()
            || !config.valid()
            || self.l3.contains(id)
            || gateway.is_some_and(|g| {
                g == config.address || !config.prefix().is_some_and(|p| usable(p, g))
            })
        {
            return Err(EngineError::InvalidInput);
        }
        self.configure_host(id, config.key.port, config.address, config.mac)?;
        let mut node = Node::new(false);
        node.interfaces.insert(
            config.key,
            Interface {
                config,
                cache: ArpCache::default(),
                active: false,
            },
        );
        if let Some(next_hop) = gateway {
            node.static_routes.push(Route {
                prefix: Ipv4Prefix::new(Ipv4Addr::UNSPECIFIED, 0)
                    .ok_or(EngineError::InvalidInput)?,
                interface: config.key,
                next_hop: Some(next_hop),
                distance: 1,
                metric: 0,
                origin: RouteOrigin::Static,
            });
        }
        self.l3.nodes.insert(id, node);
        Ok(())
    }

    /// Update an existing single-homed endpoint at an event boundary.
    pub fn update_ipv4_host(
        &mut self,
        id: DeviceId,
        config: InterfaceConfig,
        gateway: Option<Ipv4Addr>,
    ) -> Result<(), EngineError> {
        if config.key.vlan.is_some()
            || !config.valid()
            || gateway.is_some_and(|g| {
                g == config.address || !config.prefix().is_some_and(|p| usable(p, g))
            })
        {
            return Err(EngineError::InvalidInput);
        }
        let old = self.l3.nodes.get(&id).ok_or(EngineError::InvalidState)?;
        if old.forwarding
            || old.interfaces.len() != 1
            || old
                .interfaces
                .get(&config.key)
                .is_none_or(|i| i.config.mac != config.mac)
        {
            return Err(EngineError::InvalidState);
        }
        let mut node = Node::new(false);
        node.interfaces.insert(
            config.key,
            Interface {
                config,
                cache: ArpCache::default(),
                active: false,
            },
        );
        if let Some(next_hop) = gateway {
            node.static_routes.push(Route {
                prefix: Ipv4Prefix::new(Ipv4Addr::UNSPECIFIED, 0)
                    .ok_or(EngineError::InvalidInput)?,
                interface: config.key,
                next_hop: Some(next_hop),
                distance: 1,
                metric: 0,
                origin: RouteOrigin::Static,
            });
        }
        self.update_host_ip(id, config.address)?;
        self.invalidate_port_frames(config.key.port);
        self.l3.nodes.insert(id, node);
        self.sync_all_l3();
        Ok(())
    }

    pub fn configure_router(&mut self, id: DeviceId) -> Result<(), EngineError> {
        self.require_off(id)?;
        if self.has_l2_endpoint(id) || self.l3.contains(id) {
            return Err(EngineError::InvalidInput);
        }
        self.l3.nodes.insert(id, Node::new(true));
        Ok(())
    }

    /// Tagged subinterfaces may share a MAC on the same physical port only.
    pub fn configure_router_interface(
        &mut self,
        id: DeviceId,
        config: InterfaceConfig,
    ) -> Result<(), EngineError> {
        self.require_off(id)?;
        self.check_ethernet_port(id, config.key.port)?;
        if !config.valid() {
            return Err(EngineError::InvalidInput);
        }
        let node = self.l3.nodes.get(&id).ok_or(EngineError::InvalidState)?;
        if !node.forwarding
            || node.interfaces.contains_key(&config.key)
            || node
                .interfaces
                .values()
                .any(|i| i.config.address == config.address)
            || self.l2_mac_in_use(config.mac)
            || self.l3.nodes.iter().any(|(other, n)| {
                n.interfaces.values().any(|i| {
                    i.config.mac == config.mac
                        && (*other != id || i.config.key.port != config.key.port)
                })
            })
        {
            return Err(EngineError::InvalidInput);
        }
        if node.interfaces.len() >= MAX_INTERFACES {
            return Err(EngineError::ResourceLimit);
        }
        self.l3
            .nodes
            .get_mut(&id)
            .ok_or(EngineError::InvalidState)?
            .interfaces
            .insert(
                config.key,
                Interface {
                    config,
                    cache: ArpCache::default(),
                    active: false,
                },
            );
        Ok(())
    }

    /// Directly reachable next hop required. No recursive route resolution in this release.
    pub fn add_static_route(&mut self, id: DeviceId, route: Route) -> Result<(), EngineError> {
        self.require_off(id)?;
        let node = self
            .l3
            .nodes
            .get_mut(&id)
            .ok_or(EngineError::InvalidState)?;
        let iface = node
            .interfaces
            .get(&route.interface)
            .ok_or(EngineError::InvalidInput)?;
        if !node.forwarding
            || route.origin != RouteOrigin::Static
            || route.distance == 0
            || route.distance == 255
            || !route.next_hop.is_some_and(|g| {
                g != iface.config.address && iface.config.prefix().is_some_and(|p| usable(p, g))
            })
            || node.static_routes.contains(&route)
        {
            return Err(EngineError::InvalidInput);
        }
        if node.static_routes.len() >= MAX_ROUTES {
            return Err(EngineError::ResourceLimit);
        }
        node.static_routes.push(route);
        Ok(())
    }

    pub fn remove_static_route(&mut self, id: DeviceId, route: Route) -> Result<(), EngineError> {
        self.require_off(id)?;
        let node = self
            .l3
            .nodes
            .get_mut(&id)
            .ok_or(EngineError::InvalidState)?;
        if !node.forwarding {
            return Err(EngineError::InvalidState);
        }
        let index = node
            .static_routes
            .iter()
            .position(|r| *r == route)
            .ok_or(EngineError::InvalidInput)?;
        node.static_routes.remove(index);
        Ok(())
    }

    fn port_active(&self, port: PortId) -> bool {
        self.links.values().any(|link| {
            link.endpoints.contains(&port)
                && link.endpoints.iter().all(|p| {
                    !self.admin_down.contains(p)
                        && self
                            .ports
                            .get(p)
                            .is_some_and(|p| self.active_generation(p.device).is_ok())
                })
        })
    }

    pub(super) fn interface_arp_entries(
        &self,
        id: DeviceId,
        key: InterfaceKey,
    ) -> Option<Vec<(Ipv4Addr, MacAddress, SimTime)>> {
        Some(
            self.l3
                .nodes
                .get(&id)?
                .interfaces
                .get(&key)?
                .cache
                .entries(self.now()),
        )
    }

    pub fn interface_arp_lookup(
        &self,
        id: DeviceId,
        key: InterfaceKey,
        ip: Ipv4Addr,
    ) -> Option<MacAddress> {
        self.l3
            .nodes
            .get(&id)?
            .interfaces
            .get(&key)?
            .cache
            .lookup(ip, self.now())
    }

    pub fn route_lookup(&self, id: DeviceId, destination: Ipv4Addr) -> Option<Route> {
        let node = self.l3.nodes.get(&id)?;
        lookup(&node.routes(), destination, |key| {
            self.port_active(key.port)
        })
    }

    fn ip_drop(&mut self, id: DeviceId, reason: &'static str) {
        self.record(id, TraceAction::IpDrop { reason }, Outcome::Skipped);
    }

    /// Returns false when no usable route exists, not when a frame is lost.
    fn output_ip(&mut self, id: DeviceId, packet: Ipv4Packet) -> Result<bool, EngineError> {
        let Some(route) = self.route_lookup(id, packet.dst) else {
            self.ip_drop(id, "no-route");
            return Ok(false);
        };
        let now = self.now();
        let key = route.interface;
        let next = route.next_hop.unwrap_or(packet.dst);
        let node = self
            .l3
            .nodes
            .get_mut(&id)
            .ok_or(EngineError::InvalidState)?;
        let iface = &node.interfaces[&key];
        let config = iface.config;
        if !config.prefix().is_some_and(|p| usable(p, next)) || next == config.address {
            self.ip_drop(id, "invalid-next-hop");
            return Ok(false);
        }
        if let Some(mac) = iface.cache.lookup(next, now) {
            if let Some(frame) = ip_frame(config, mac, &packet) {
                self.send_frame(key.port, frame)?;
            }
            return Ok(true);
        }
        node.pending.retain(|p| p.expires > now);
        if node.pending.len() >= MAX_PENDING {
            self.ip_drop(id, "arp-pending-full");
            return Ok(true);
        }
        let expires = now.checked_add(3 * SEC).ok_or(EngineError::TimeOverflow)?;
        node.pending.push(Pending {
            key,
            next,
            packet,
            expires,
        });
        if let std::collections::btree_map::Entry::Vacant(entry) =
            node.resolutions.entry((key, next))
        {
            entry.insert(Resolution {
                attempts: 1,
                next_retry: now.saturating_add(SEC),
            });
            self.send_frame(
                key.port,
                arp_frame(config, next, MacAddress([0; 6]), Operation::Request),
            )?;
        }
        Ok(true)
    }

    /// Clear neighbor state and queued datagrams when a local carrier goes down.
    pub(super) fn sync_all_l3(&mut self) {
        let states: Vec<_> = self
            .l3
            .nodes
            .iter()
            .flat_map(|(id, n)| n.interfaces.keys().map(move |key| (*id, *key)))
            .map(|(id, key)| (id, key, self.port_active(key.port)))
            .collect();
        for (id, key, active) in states {
            if let Some(node) = self.l3.nodes.get_mut(&id) {
                if let Some(iface) = node.interfaces.get_mut(&key) {
                    if iface.active && !active {
                        iface.cache = ArpCache::default();
                        node.pending.retain(|p| p.key != key);
                        node.resolutions.retain(|(k, _), _| *k != key);
                    }
                    iface.active = active;
                }
            }
        }
    }

    pub(super) fn start_l3(&mut self, id: DeviceId) -> Result<(), EngineError> {
        if self.l3.contains(id) {
            let at = self
                .now()
                .checked_add(SEC)
                .ok_or(EngineError::TimeOverflow)?;
            let generation = self.active_generation(id)?;
            self.scheduler
                .schedule(at, id, generation, EventKind::L3Tick)?;
        }
        Ok(())
    }

    pub(super) fn tick_l3(&mut self, id: DeviceId) -> Result<(), EngineError> {
        let now = self.now();
        let generation = self.active_generation(id)?;
        let Some(node) = self.l3.nodes.get_mut(&id) else {
            return Ok(());
        };
        for probe in node.probes.values_mut() {
            *probe = status_at(*probe, now);
        }
        let mut expired = Vec::new();
        node.pending.retain(|p| {
            if p.expires <= now {
                expired.push((p.key, p.packet.clone()));
                false
            } else {
                true
            }
        });
        node.resolutions
            .retain(|(key, ip), _| node.pending.iter().any(|p| p.key == *key && p.next == *ip));
        let mut requests = Vec::new();
        for ((key, ip), resolution) in &mut node.resolutions {
            if resolution.attempts < 3 && now >= resolution.next_retry {
                resolution.attempts += 1;
                resolution.next_retry = now.saturating_add(SEC);
                requests.push((
                    *key,
                    arp_frame(
                        node.interfaces[key].config,
                        *ip,
                        MacAddress([0; 6]),
                        Operation::Request,
                    ),
                ));
            }
        }
        let forwarding = node.forwarding;
        for (key, packet) in expired {
            self.ip_drop(id, "arp-timeout");
            // Only notify for transit packets; avoid ICMP errors in response to errors.
            if forwarding && !self.is_local_ip(id, packet.src) {
                self.send_ip_error(id, key, &packet, false, 1)?;
            }
        }
        for (key, frame) in requests {
            self.send_frame(key.port, frame)?;
        }
        let next = now.checked_add(SEC).ok_or(EngineError::TimeOverflow)?;
        self.scheduler
            .schedule(next, id, generation, EventKind::L3Tick)?;
        self.ospf_tick(id)?;
        Ok(())
    }

    fn is_local_ip(&self, id: DeviceId, ip: Ipv4Addr) -> bool {
        self.l3.nodes.get(&id).is_some_and(|n| {
            n.interfaces
                .values()
                .any(|i| i.config.address == ip && self.port_admin_up(i.config.key.port))
        })
    }

    pub(super) fn receive_l3(
        &mut self,
        id: DeviceId,
        port: PortId,
        frame: EthernetFrame,
    ) -> Result<(), EngineError> {
        let key = InterfaceKey {
            port,
            vlan: frame.tag.map(|tag| tag.vid),
        };
        let Some(config) = self
            .l3
            .nodes
            .get(&id)
            .and_then(|n| n.interfaces.get(&key))
            .map(|i| i.config)
        else {
            return Ok(());
        };
        if frame.dst != config.mac && !(frame.kind == ARP && frame.dst == MacAddress::BROADCAST) {
            return Ok(());
        }
        if frame.kind == ARP {
            return self.receive_ip_arp(id, key, config, frame);
        }
        if frame.kind != IPV4 {
            return Ok(());
        }
        let Ok(packet) = Ipv4Packet::decode(&frame.payload) else {
            self.ip_drop(id, "invalid-ipv4");
            return Ok(());
        };
        if !unicast(packet.src) || !unicast(packet.dst) || packet.ttl == 0 {
            self.ip_drop(id, "invalid-ip-address-or-ttl");
            return Ok(());
        }
        if self.is_local_ip(id, packet.dst) {
            return self.receive_local_ip(id, packet);
        }
        if !self.l3.nodes[&id].forwarding {
            return Ok(());
        }
        if packet.ttl <= 1 {
            self.ip_drop(id, "ttl-expired");
            return self.send_ip_error(id, key, &packet, true, 0);
        }
        // Preserve the original quote before decrementing TTL.
        let original = packet.clone();
        let mut packet = packet;
        packet.ttl -= 1;
        if self.output_ip(id, packet)? {
            let node = self
                .l3
                .nodes
                .get_mut(&id)
                .ok_or(EngineError::InvalidState)?;
            node.forwarded = node.forwarded.saturating_add(1);
        } else {
            self.send_ip_error(id, key, &original, false, 0)?;
        }
        Ok(())
    }

    fn receive_ip_arp(
        &mut self,
        id: DeviceId,
        key: InterfaceKey,
        config: InterfaceConfig,
        frame: EthernetFrame,
    ) -> Result<(), EngineError> {
        let Some(arp) = Arp::decode(&frame.payload) else {
            return Ok(());
        };
        if arp.sender_mac != frame.src
            || arp.sender_ip == config.address
            || !config.prefix().is_some_and(|p| usable(p, arp.sender_ip))
        {
            return Ok(());
        }
        let now = self.now();
        let node = self
            .l3
            .nodes
            .get_mut(&id)
            .ok_or(EngineError::InvalidState)?;
        let iface = node
            .interfaces
            .get_mut(&key)
            .ok_or(EngineError::InvalidState)?;
        if arp.target_ip != config.address
            || (arp.operation == Operation::Reply && arp.target_mac != config.mac)
        {
            return Ok(());
        }
        iface.cache.learn(arp.sender_ip, arp.sender_mac, now);
        node.resolutions.remove(&(key, arp.sender_ip));
        let mut packets = Vec::new();
        node.pending.retain(|p| {
            if p.key == key && p.next == arp.sender_ip {
                if p.expires > now {
                    packets.push(p.packet.clone());
                }
                false
            } else {
                true
            }
        });
        if arp.operation == Operation::Request {
            self.send_frame(
                key.port,
                arp_frame(config, arp.sender_ip, arp.sender_mac, Operation::Reply),
            )?;
        }
        for packet in packets {
            if let Some(frame) = ip_frame(config, arp.sender_mac, &packet) {
                self.send_frame(key.port, frame)?;
            }
        }
        Ok(())
    }

    fn send_ip_error(
        &mut self,
        id: DeviceId,
        ingress: InterfaceKey,
        original: &Ipv4Packet,
        time: bool,
        code: u8,
    ) -> Result<(), EngineError> {
        // Suppress errors for ICMP errors and non-unicast traffic.
        if !unicast(original.src)
            || !unicast(original.dst)
            || (original.protocol == ICMP
                && !matches!(
                    IcmpMessage::decode(&original.payload),
                    Ok(IcmpMessage::Echo { .. })
                ))
        {
            return Ok(());
        }
        let Some(route) = self.route_lookup(id, original.src) else {
            return Ok(());
        };
        let node = &self.l3.nodes[&id];
        // Use the return-path interface address, not a global topology lookup.
        let source = node
            .interfaces
            .get(&route.interface)
            .or_else(|| node.interfaces.get(&ingress))
            .ok_or(EngineError::InvalidState)?
            .config
            .address;
        let message = if time {
            IcmpMessage::TimeExceeded {
                code,
                quote: quote(original),
            }
        } else {
            IcmpMessage::Unreachable {
                code,
                quote: quote(original),
            }
        };
        self.output_ip(id, icmp_packet(source, original.src, 64, message))?;
        Ok(())
    }

    fn receive_local_ip(&mut self, id: DeviceId, packet: Ipv4Packet) -> Result<(), EngineError> {
        if packet.protocol != ICMP {
            return Ok(());
        }
        let Ok(message) = IcmpMessage::decode(&packet.payload) else {
            self.ip_drop(id, "invalid-icmp");
            return Ok(());
        };
        let now = self.now();
        let (token, original_src, original_dst, status) = match message {
            IcmpMessage::Echo {
                reply: false,
                token,
                data,
            } => {
                self.output_ip(
                    id,
                    icmp_packet(
                        packet.dst,
                        packet.src,
                        64,
                        IcmpMessage::Echo {
                            reply: true,
                            token,
                            data,
                        },
                    ),
                )?;
                return Ok(());
            }
            IcmpMessage::Echo {
                reply: true,
                token,
                data,
            } => {
                if data.as_slice() != b"NetSim" {
                    return Ok(());
                }
                (token, packet.dst, packet.src, 0)
            }
            IcmpMessage::TimeExceeded { code: 0, quote } => {
                let Some((src, dst, token)) = quoted_echo(&quote) else {
                    return Ok(());
                };
                (token, src, dst, 1)
            }
            IcmpMessage::Unreachable { code, quote } => {
                let Some((src, dst, token)) = quoted_echo(&quote) else {
                    return Ok(());
                };
                (token, src, dst, u16::from(code) + 2)
            }
            _ => return Ok(()),
        };
        if let Some(probe) = self
            .l3
            .nodes
            .get_mut(&id)
            .and_then(|n| n.probes.get_mut(&token))
        {
            if probe.status == ProbeStatus::Pending
                && now < probe.deadline
                && probe.source == original_src
                && probe.destination == original_dst
                && packet.dst == probe.source
            {
                let rtt_ns = now - probe.started;
                probe.status = match status {
                    0 => ProbeStatus::Reply {
                        from: packet.src,
                        rtt_ns,
                    },
                    1 => ProbeStatus::TimeExceeded {
                        from: packet.src,
                        rtt_ns,
                    },
                    _ => ProbeStatus::Unreachable {
                        from: packet.src,
                        code: (status - 2) as u8,
                        rtt_ns,
                    },
                };
            }
        }
        Ok(())
    }

    /// Asynchronous ICMP echo probe. TTL 1..255 enables traceroute using the same API.
    pub fn ping(
        &mut self,
        id: DeviceId,
        destination: Ipv4Addr,
        ttl: u8,
        timeout: SimTime,
    ) -> Result<u32, EngineError> {
        self.active_generation(id)?;
        if ttl == 0 || timeout == 0 || !unicast(destination) {
            return Err(EngineError::InvalidInput);
        }
        let now = self.now();
        let deadline = now.checked_add(timeout).ok_or(EngineError::TimeOverflow)?;
        let node = self.l3.nodes.get(&id).ok_or(EngineError::InvalidState)?;
        let local = self.is_local_ip(id, destination);
        let route = self.route_lookup(id, destination);
        let source = if local {
            destination
        } else if let Some(r) = route {
            node.interfaces[&r.interface].config.address
        } else {
            node.interfaces
                .values()
                .next()
                .ok_or(EngineError::InvalidState)?
                .config
                .address
        };
        let token = self
            .l3
            .next_probe
            .checked_add(1)
            .ok_or(EngineError::SequenceExhausted)?;
        let node = self
            .l3
            .nodes
            .get_mut(&id)
            .ok_or(EngineError::InvalidState)?;
        if node.probes.len() >= MAX_PROBES {
            let old = node
                .probes
                .iter()
                .find(|(_, p)| status_at(**p, now).status != ProbeStatus::Pending)
                .map(|(k, _)| *k)
                .ok_or(EngineError::ResourceLimit)?;
            node.probes.remove(&old);
        }
        self.l3.next_probe = token;
        let status = if local {
            ProbeStatus::Reply {
                from: destination,
                rtt_ns: 0,
            }
        } else if route.is_none() {
            ProbeStatus::NoRoute
        } else {
            ProbeStatus::Pending
        };
        node.probes.insert(
            token,
            Probe {
                token,
                source,
                destination,
                ttl,
                started: now,
                deadline,
                status,
            },
        );
        if status == ProbeStatus::Pending {
            let sent = self.output_ip(
                id,
                icmp_packet(
                    source,
                    destination,
                    ttl,
                    IcmpMessage::Echo {
                        reply: false,
                        token,
                        data: b"NetSim".to_vec(),
                    },
                ),
            );
            match sent {
                Ok(true) => {}
                Ok(false) => {
                    if let Some(p) = self
                        .l3
                        .nodes
                        .get_mut(&id)
                        .and_then(|n| n.probes.get_mut(&token))
                    {
                        p.status = ProbeStatus::NoRoute;
                    }
                }
                Err(error) => {
                    if let Some(n) = self.l3.nodes.get_mut(&id) {
                        n.probes.remove(&token);
                    }
                    return Err(error);
                }
            }
        }
        Ok(token)
    }

    pub fn probe(&self, id: DeviceId, token: u32) -> Option<Probe> {
        self.l3
            .nodes
            .get(&id)?
            .probes
            .get(&token)
            .map(|p| status_at(*p, self.now()))
    }

    /// Bounded headless traceroute. One ICMP echo per TTL. Budget is shared across all hops.
    /// For interactive GUI, issue ping commands with successive TTL instead of blocking.
    pub fn traceroute(
        &mut self,
        id: DeviceId,
        destination: Ipv4Addr,
        max_hops: u8,
        timeout: SimTime,
        mut budget: usize,
    ) -> Result<Vec<Probe>, EngineError> {
        if max_hops == 0 || timeout == 0 || budget == 0 {
            return Err(EngineError::InvalidInput);
        }
        let mut hops = Vec::new();
        for ttl in 1..=max_hops {
            let token = self.ping(id, destination, ttl, timeout)?;
            let mut probe = self.probe(id, token).ok_or(EngineError::InvalidState)?;
            while probe.status == ProbeStatus::Pending {
                if budget == 0 {
                    return Err(EngineError::ResourceLimit);
                }
                if !self.scheduler.has_due_event(probe.deadline) {
                    self.run_until(probe.deadline, 0)?;
                } else if let Some(event) = self.step() {
                    budget -= 1;
                    if matches!(event.outcome, Outcome::Failed(error) if error != EngineError::Unsupported || event.kind != "cli")
                    {
                        return Err(EngineError::DeviceFault);
                    }
                }
                probe = self.probe(id, token).ok_or(EngineError::InvalidState)?;
            }
            hops.push(probe);
            if matches!(
                probe.status,
                ProbeStatus::Reply { .. } | ProbeStatus::Unreachable { .. } | ProbeStatus::NoRoute
            ) {
                break;
            }
        }
        Ok(hops)
    }

    pub(super) fn l3_snapshot(&self) -> L3Snapshot {
        let now = self.now();
        L3Snapshot {
            nodes: self
                .l3
                .nodes
                .iter()
                .map(|(id, node)| IpNodeSnapshot {
                    device: *id,
                    forwarding: node.forwarding,
                    interfaces: node
                        .interfaces
                        .values()
                        .map(|i| IpInterfaceSnapshot {
                            config: i.config,
                            active: self.port_active(i.config.key.port),
                            arp: i.cache.entries(now),
                        })
                        .collect(),
                    routes: node.routes(),
                    probes: node.probes.values().map(|p| status_at(*p, now)).collect(),
                    pending_packets: node.pending.len(),
                    forwarded: node.forwarded,
                })
                .collect(),
        }
    }
}

impl Engine {
    /// Validate a full router configuration before committing it. Does not power-cycle.
    /// Dynamic IPv4 state is conservatively flushed on changes.
    pub fn replace_router_config(
        &mut self,
        id: DeviceId,
        interfaces: &[InterfaceConfig],
        routes: &[Route],
    ) -> Result<(), EngineError> {
        if !self.l3.nodes.get(&id).is_some_and(|node| node.forwarding) {
            return Err(EngineError::InvalidState);
        }
        if interfaces.len() > MAX_INTERFACES || routes.len() > MAX_ROUTES {
            return Err(EngineError::ResourceLimit);
        }
        let mut candidate = Node::new(true);
        for &config in interfaces {
            self.check_ethernet_port(id, config.key.port)?;
            if !config.valid()
                || candidate.interfaces.contains_key(&config.key)
                || candidate.interfaces.values().any(|i| {
                    i.config.address == config.address
                        || (i.config.mac == config.mac && i.config.key.port != config.key.port)
                })
                || self.l2_mac_in_use(config.mac)
                || self.l3.nodes.iter().any(|(other, n)| {
                    *other != id && n.interfaces.values().any(|i| i.config.mac == config.mac)
                })
            {
                return Err(EngineError::InvalidInput);
            }
            candidate.interfaces.insert(
                config.key,
                Interface {
                    config,
                    cache: ArpCache::default(),
                    active: false,
                },
            );
        }
        for &route in routes {
            let iface = candidate
                .interfaces
                .get(&route.interface)
                .ok_or(EngineError::InvalidInput)?;
            if route.origin != RouteOrigin::Static
                || route.distance == 0
                || route.distance == 255
                || candidate.static_routes.contains(&route)
                || !route.next_hop.is_some_and(|g| {
                    g != iface.config.address && iface.config.prefix().is_some_and(|p| usable(p, g))
                })
            {
                return Err(EngineError::InvalidInput);
            }
            candidate.static_routes.push(route);
        }
        self.l3.nodes.insert(id, candidate);
        self.sync_all_l3();
        Ok(())
    }
}

impl Engine {
    pub(super) fn clear_dhcp_address(&mut self, id: DeviceId) {
        if self.l3.nodes.get(&id).is_some_and(|n| !n.forwarding) {
            let ports: Vec<_> = self.l3.nodes[&id]
                .interfaces
                .keys()
                .map(|k| k.port)
                .collect();
            for p in ports {
                self.invalidate_port_frames(p);
            }
            self.l3.remove(id);
            self.remove_l2_host(id);
            self.scheduler
                .retain(|e| e.target != id || !matches!(e.kind, EventKind::L3Tick));
        }
    }
    pub(super) fn install_dhcp_address(
        &mut self,
        id: DeviceId,
        config: InterfaceConfig,
        gateway: Option<Ipv4Addr>,
    ) -> Result<(), EngineError> {
        if !config.valid()
            || gateway.is_some_and(|g| {
                g == config.address || !config.prefix().is_some_and(|p| usable(p, g))
            })
        {
            return Err(EngineError::InvalidInput);
        }
        self.scheduler.check_batch(1, 0)?;
        self.clear_dhcp_address(id);
        self.install_l2_host(id, config.key.port, config.address, config.mac)?;
        let mut node = Node::new(false);
        node.interfaces.insert(
            config.key,
            Interface {
                config,
                cache: ArpCache::default(),
                active: false,
            },
        );
        if let Some(next_hop) = gateway {
            node.static_routes.push(Route {
                prefix: Ipv4Prefix::new(Ipv4Addr::UNSPECIFIED, 0)
                    .ok_or(EngineError::InvalidInput)?,
                interface: config.key,
                next_hop: Some(next_hop),
                distance: 1,
                metric: 0,
                origin: RouteOrigin::Static,
            });
        }
        self.l3.nodes.insert(id, node);
        self.sync_all_l3();
        self.start_l3(id)
    }
    pub(super) fn set_ospf_routes(&mut self, id: DeviceId, routes: Vec<Route>) {
        if let Some(n) = self.l3.nodes.get_mut(&id) {
            n.ospf_routes = routes;
        }
    }
}
