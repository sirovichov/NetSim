//! DHCP and the area-0 link-state teaching protocol, dispatched by the DES.
use super::*;
use netsim_packet::{
    dhcp::{Kind, Message},
    ethernet::{EthernetFrame, Tag},
    ipv4::{IPV4, Ipv4Packet},
};
use netsim_protocols::{
    Ipv4Prefix,
    ospf::{Lsa, spf},
    routing::{unicast, usable},
};
use std::net::Ipv4Addr;
const SEC: u64 = 1_000_000_000;
const ZERO: Ipv4Addr = Ipv4Addr::UNSPECIFIED;
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct DhcpPool {
    pub first: Ipv4Addr,
    pub last: Ipv4Addr,
    pub prefix: u8,
    pub gateway: Option<Ipv4Addr>,
    pub lease_secs: u32,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DhcpPhase {
    Selecting,
    Requesting,
    Bound,
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DhcpStatus {
    pub device: DeviceId,
    pub phase: DhcpPhase,
    pub address: Option<Ipv4Addr>,
    pub expires: u64,
}
struct Client {
    port: PortId,
    mac: MacAddress,
    xid: u32,
    phase: DhcpPhase,
    offer: Option<Message>,
    expires: u64,
    next: u64,
}
struct Server {
    config: InterfaceConfig,
    pool: DhcpPool,
    leases: BTreeMap<MacAddress, (Ipv4Addr, u64)>,
}
#[derive(Default)]
pub(super) struct ServiceState {
    clients: BTreeMap<DeviceId, Client>,
    servers: BTreeMap<DeviceId, Server>,
    ospf: BTreeMap<DeviceId, Ospf>,
}
struct Ospf {
    rid: Ipv4Addr,
    neighbors: BTreeMap<(Ipv4Addr, InterfaceKey), (Ipv4Addr, u64)>,
    db: BTreeMap<Ipv4Addr, (Lsa, u64)>,
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct OspfStatus {
    pub device: DeviceId,
    pub router_id: Ipv4Addr,
    pub neighbors: Vec<Ipv4Addr>,
    pub lsdb: usize,
}
impl ServiceState {
    pub(super) fn remove(&mut self, id: DeviceId) {
        self.clients.remove(&id);
        self.servers.remove(&id);
        self.ospf.remove(&id);
    }
    pub(super) fn client(&self, id: DeviceId) -> bool {
        self.clients.contains_key(&id)
    }
    pub(super) fn reset(&mut self, id: DeviceId) {
        if let Some(c) = self.clients.get_mut(&id) {
            c.phase = DhcpPhase::Selecting;
            c.offer = None;
            c.expires = 0;
            c.next = 0;
            c.xid = c.xid.wrapping_add(1);
        }
        if let Some(o) = self.ospf.get_mut(&id) {
            o.neighbors.clear();
            o.db.clear();
        }
    }
}
fn mac_for(port: PortId) -> MacAddress {
    let b = port.0.to_be_bytes();
    MacAddress([2, 0x48, b[4], b[5], b[6], b[7]])
}
fn client_msg(c: &Client, kind: Kind) -> Message {
    Message {
        kind,
        xid: c.xid,
        mac: c.mac,
        offered: ZERO,
        server: c.offer.map_or(ZERO, |m| m.server),
        requested: c.offer.map_or(ZERO, |m| m.offered),
        prefix: 0,
        gateway: None,
        lease: 0,
    }
}
impl Engine {
    pub fn enable_dhcp_client(&mut self, id: DeviceId, port: PortId) -> Result<(), EngineError> {
        self.check_ethernet_port(id, port)?;
        if self.services.servers.contains_key(&id)
            || self.services.client(id)
            || self
                .l3_snapshot()
                .nodes
                .iter()
                .any(|n| n.device == id && n.forwarding)
        {
            return Err(EngineError::InvalidState);
        }
        if self.active_generation(id).is_ok() {
            self.scheduler.check_batch(1, 0)?;
        }
        self.clear_dhcp_address(id);
        let xid = self.rng.next_u64() as u32;
        self.services.clients.insert(
            id,
            Client {
                port,
                mac: mac_for(port),
                xid,
                phase: DhcpPhase::Selecting,
                offer: None,
                expires: 0,
                next: 0,
            },
        );
        if let Ok(g) = self.active_generation(id) {
            self.scheduler
                .schedule(self.now(), id, g, EventKind::L2Tick)?;
        }
        Ok(())
    }
    pub fn enable_dhcp_server(&mut self, id: DeviceId, pool: DhcpPool) -> Result<(), EngineError> {
        let snap = self.l3_snapshot();
        let node = snap
            .nodes
            .iter()
            .find(|n| n.device == id && !n.forwarding)
            .ok_or(EngineError::InvalidState)?;
        let config = node
            .interfaces
            .first()
            .ok_or(EngineError::InvalidState)?
            .config;
        let p = Ipv4Prefix::new(pool.first, pool.prefix).ok_or(EngineError::InvalidInput)?;
        let a = u32::from(pool.first);
        let b = u32::from(pool.last);
        if self.services.client(id)
            || config.prefix() != Some(p)
            || a > b
            || b - a >= 256
            || !usable(p, pool.first)
            || !usable(p, pool.last)
            || (a..=b).contains(&u32::from(config.address))
            || pool.lease_secs < 60
            || pool.lease_secs > 86400
            || pool
                .gateway
                .is_some_and(|g| !usable(p, g) || (a..=b).contains(&u32::from(g)))
        {
            return Err(EngineError::InvalidInput);
        }
        if let Some(s) = self.services.servers.get(&id) {
            if s.config == config && s.pool == pool {
                return Ok(());
            }
            return Err(EngineError::InvalidState);
        }
        self.services.servers.insert(
            id,
            Server {
                config,
                pool,
                leases: BTreeMap::new(),
            },
        );
        Ok(())
    }
    pub fn dhcp_status(&self) -> Vec<DhcpStatus> {
        self.services
            .clients
            .iter()
            .map(|(id, c)| DhcpStatus {
                device: *id,
                phase: c.phase,
                address: if c.phase == DhcpPhase::Bound {
                    c.offer.map(|m| m.offered)
                } else {
                    None
                },
                expires: c.expires,
            })
            .collect()
    }
    pub(super) fn dhcp_tick(&mut self, id: DeviceId) -> Result<(), EngineError> {
        let now = self.now();
        let Some(c) = self.services.clients.get_mut(&id) else {
            return Ok(());
        };
        let mut clear = false;
        if c.phase == DhcpPhase::Bound && now >= c.expires {
            c.phase = DhcpPhase::Selecting;
            c.offer = None;
            c.xid = c.xid.wrapping_add(1);
            c.next = now;
            clear = true;
        }
        let mut send = None;
        if c.phase != DhcpPhase::Bound && now >= c.next {
            // Restart discovery after request timeout; no unbounded retries within one tick.
            if c.phase == DhcpPhase::Requesting {
                c.phase = DhcpPhase::Selecting;
                c.offer = None;
                c.xid = c.xid.wrapping_add(1);
            }
            c.next = now.saturating_add(4 * SEC);
            send = client_msg(c, Kind::Discover)
                .frame(c.mac)
                .map(|f| (c.port, f));
        }
        if clear {
            self.clear_dhcp_address(id);
        }
        if let Some((p, f)) = send {
            self.send_frame(p, f)?;
        }
        Ok(())
    }
    pub(super) fn receive_dhcp(
        &mut self,
        id: DeviceId,
        port: PortId,
        frame: &EthernetFrame,
    ) -> Result<bool, EngineError> {
        if !self.services.clients.contains_key(&id) && !self.services.servers.contains_key(&id) {
            return Ok(false);
        }
        let Some(m) = Message::decode(frame) else {
            return Ok(false);
        };
        let now = self.now();
        let mut response = None;
        let mut install = None;
        if let Some(c) = self.services.clients.get_mut(&id) {
            if c.port == port && m.xid == c.xid && m.mac == c.mac {
                match (c.phase, m.kind) {
                    (DhcpPhase::Selecting, Kind::Offer)
                        if unicast(m.offered) && unicast(m.server) =>
                    {
                        c.offer = Some(m);
                        c.phase = DhcpPhase::Requesting;
                        c.next = now.saturating_add(4 * SEC);
                        response = client_msg(c, Kind::Request).frame(c.mac);
                    }
                    (DhcpPhase::Requesting, Kind::Ack)
                        if c.offer
                            .is_some_and(|o| o.server == m.server && o.offered == m.offered)
                            && (60..=86400).contains(&m.lease) =>
                    {
                        install = Some((
                            InterfaceConfig {
                                key: InterfaceKey { port, vlan: None },
                                address: m.offered,
                                prefix_len: m.prefix,
                                mac: c.mac,
                            },
                            m,
                        ));
                    }
                    (DhcpPhase::Requesting, Kind::Nak) => {
                        c.phase = DhcpPhase::Selecting;
                        c.offer = None;
                        c.next = now;
                    }
                    _ => {}
                }
            }
        }
        if let Some((config, m)) = install {
            if !config.valid()
                || m.gateway.is_some_and(|g| {
                    g == config.address || !config.prefix().is_some_and(|p| usable(p, g))
                })
            {
                return Ok(true);
            }
            self.install_dhcp_address(id, config, m.gateway)?;
            let c = self
                .services
                .clients
                .get_mut(&id)
                .ok_or(EngineError::InvalidState)?;
            c.offer = Some(m);
            c.phase = DhcpPhase::Bound;
            c.expires = now.saturating_add(u64::from(m.lease) * SEC);
        }
        let configured = self.l3_snapshot().nodes.iter().any(|n| {
            n.device == id
                && n.interfaces.iter().any(|i| {
                    i.config.key.port == port
                        && self
                            .services
                            .servers
                            .get(&id)
                            .is_some_and(|s| s.config == i.config)
                })
        });
        if configured {
            if let Some(s) = self.services.servers.get_mut(&id) {
                s.leases.retain(|_, (_, expiry)| *expiry > now);
                let existing = s.leases.get(&m.mac).map(|v| v.0);
                let free = || {
                    (u32::from(s.pool.first)..=u32::from(s.pool.last))
                        .map(Ipv4Addr::from)
                        .find(|ip| !s.leases.values().any(|(a, _)| a == ip))
                };
                let allocation = match m.kind {
                    Kind::Discover => existing.or_else(free).map(|a| (Kind::Offer, a, 30)),
                    Kind::Request
                        if m.server == s.config.address && existing == Some(m.requested) =>
                    {
                        Some((Kind::Ack, m.requested, s.pool.lease_secs))
                    }
                    Kind::Request if m.server == s.config.address => Some((Kind::Nak, ZERO, 0)),
                    _ => None,
                };
                if let Some((kind, addr, seconds)) = allocation {
                    if kind != Kind::Nak {
                        s.leases
                            .insert(m.mac, (addr, now.saturating_add(u64::from(seconds) * SEC)));
                    }
                    response = Message {
                        kind,
                        xid: m.xid,
                        mac: m.mac,
                        offered: addr,
                        server: s.config.address,
                        requested: ZERO,
                        prefix: s.pool.prefix,
                        gateway: s.pool.gateway,
                        lease: s.pool.lease_secs,
                    }
                    .frame(s.config.mac);
                }
            }
        }
        if let Some(f) = response {
            self.send_frame(port, f)?;
        }
        // Only consume DHCP at endpoint, not at intermediate learning bridges.
        Ok(self.services.clients.contains_key(&id) || self.services.servers.contains_key(&id))
    }
    pub fn enable_ospf(&mut self, id: DeviceId, rid: Ipv4Addr) -> Result<(), EngineError> {
        if !unicast(rid)
            || !self
                .l3_snapshot()
                .nodes
                .iter()
                .any(|n| n.device == id && n.forwarding)
            || self
                .services
                .ospf
                .iter()
                .any(|(other, o)| *other != id && o.rid == rid)
        {
            return Err(EngineError::InvalidInput);
        }
        self.services.ospf.insert(
            id,
            Ospf {
                rid,
                neighbors: BTreeMap::new(),
                db: BTreeMap::new(),
            },
        );
        self.set_ospf_routes(id, vec![]);
        Ok(())
    }
    pub fn ospf_status(&self) -> Vec<OspfStatus> {
        self.services
            .ospf
            .iter()
            .map(|(id, o)| OspfStatus {
                device: *id,
                router_id: o.rid,
                neighbors: o
                    .neighbors
                    .keys()
                    .map(|(r, _)| *r)
                    .collect::<BTreeSet<_>>()
                    .into_iter()
                    .collect(),
                lsdb: o.db.len(),
            })
            .collect()
    }
    fn ospf_interfaces(&self, id: DeviceId) -> Vec<InterfaceConfig> {
        self.l3_snapshot()
            .nodes
            .iter()
            .find(|n| n.device == id)
            .map(|n| {
                n.interfaces
                    .iter()
                    .filter(|i| i.active)
                    .map(|i| i.config)
                    .collect()
            })
            .unwrap_or_default()
    }
    fn ospf_emit(
        &mut self,
        interfaces: &[InterfaceConfig],
        payload: &[u8],
        exclude: Option<InterfaceKey>,
    ) -> Result<(), EngineError> {
        for c in interfaces.iter().filter(|c| Some(c.key) != exclude) {
            let ip = Ipv4Packet {
                src: c.address,
                dst: Ipv4Addr::new(224, 0, 0, 5),
                ttl: 1,
                protocol: 89,
                identification: 0,
                dscp_ecn: 0,
                dont_fragment: true,
                payload: payload.to_vec(),
            };
            if let Ok(bytes) = ip.encode() {
                self.send_frame(
                    c.key.port,
                    EthernetFrame {
                        dst: MacAddress([1, 0, 94, 0, 0, 5]),
                        src: c.mac,
                        tag: c.key.vlan.map(|vid| Tag {
                            vid,
                            pcp: 0,
                            dei: false,
                        }),
                        kind: IPV4,
                        payload: bytes,
                    },
                )?;
            }
        }
        Ok(())
    }
    pub(super) fn ospf_tick(&mut self, id: DeviceId) -> Result<(), EngineError> {
        if !self.services.ospf.contains_key(&id) {
            return Ok(());
        }
        let now = self.now();
        let interfaces = self.ospf_interfaces(id);
        let o = self
            .services
            .ospf
            .get_mut(&id)
            .ok_or(EngineError::InvalidState)?;
        o.neighbors.retain(|(_, key), (ip, t)| {
            now.saturating_sub(*t) < 6 * SEC
                && interfaces
                    .iter()
                    .any(|i| i.key == *key && i.prefix().is_some_and(|p| usable(p, *ip)))
        });
        o.db.retain(|_, (_, t)| now.saturating_sub(*t) < 12 * SEC);
        let rid = o.rid;
        let lsa = Lsa {
            router: rid,
            sequence: now,
            neighbors: o
                .neighbors
                .keys()
                .map(|(r, _)| *r)
                .collect::<BTreeSet<_>>()
                .into_iter()
                .take(64)
                .collect(),
            prefixes: interfaces
                .iter()
                .filter_map(|i| i.prefix())
                .take(64)
                .collect(),
        };
        o.db.insert(rid, (lsa.clone(), now));
        let db = o.db.iter().map(|(r, (l, _))| (*r, l.clone())).collect();
        let paths = spf(rid, &db);
        let mut routes = Vec::new();
        for (dest, (cost, first)) in paths {
            let Some(((_, key), (hop, _))) = o.neighbors.iter().find(|entry| (entry.0).0 == first)
            else {
                continue;
            };
            if let Some((advertisement, _)) = o.db.get(&dest) {
                for p in &advertisement.prefixes {
                    routes.push(Route {
                        prefix: *p,
                        interface: *key,
                        next_hop: Some(*hop),
                        distance: 110,
                        metric: cost,
                        origin: RouteOrigin::Ospf,
                    });
                }
            }
        }
        routes.sort_by_key(|r| {
            (
                r.prefix.network(),
                r.prefix.length(),
                r.metric,
                r.interface,
                r.next_hop,
            )
        });
        routes.truncate(4096);
        self.set_ospf_routes(id, routes);
        let mut hello = b"NSH1".to_vec();
        hello.extend(rid.octets());
        self.ospf_emit(&interfaces, &hello, None)?;
        if let Some(payload) = lsa.encode() {
            self.ospf_emit(&interfaces, &payload, None)?;
        }
        Ok(())
    }
    pub(super) fn receive_ospf(
        &mut self,
        id: DeviceId,
        port: PortId,
        frame: &EthernetFrame,
    ) -> Result<bool, EngineError> {
        if !self.services.ospf.contains_key(&id) || frame.kind != IPV4 {
            return Ok(false);
        }
        let Ok(ip) = Ipv4Packet::decode(&frame.payload) else {
            return Ok(false);
        };
        if ip.protocol != 89 || ip.dst != Ipv4Addr::new(224, 0, 0, 5) || ip.ttl != 1 {
            return Ok(false);
        }
        let key = InterfaceKey {
            port,
            vlan: frame.tag.map(|t| t.vid),
        };
        let ifaces = self.ospf_interfaces(id);
        if !ifaces.iter().any(|i| {
            i.key == key && i.address != ip.src && i.prefix().is_some_and(|p| usable(p, ip.src))
        }) {
            return Ok(true);
        }
        let now = self.now();
        let o = self
            .services
            .ospf
            .get_mut(&id)
            .ok_or(EngineError::InvalidState)?;
        if ip.payload.len() == 8 && &ip.payload[..4] == b"NSH1" {
            let r = Ipv4Addr::new(ip.payload[4], ip.payload[5], ip.payload[6], ip.payload[7]);
            if r != o.rid
                && unicast(r)
                && (o.neighbors.len() < 256 || o.neighbors.contains_key(&(r, key)))
            {
                o.neighbors.insert((r, key), (ip.src, now));
            }
        } else if let Some(lsa) = Lsa::decode(&ip.payload) {
            // Only accept floods from a known local neighbor; sequence suppresses loops.
            if lsa.router != o.rid
                && unicast(lsa.router)
                && o.neighbors
                    .iter()
                    .any(|((_, k), (src, _))| *k == key && *src == ip.src)
                && (o.db.len() < 1000 || o.db.contains_key(&lsa.router))
                && o.db
                    .get(&lsa.router)
                    .is_none_or(|(old, _)| old.sequence < lsa.sequence)
            {
                o.db.insert(lsa.router, (lsa, now));
                self.ospf_emit(&ifaces, &ip.payload, Some(key))?;
            }
        }
        Ok(true)
    }
}
