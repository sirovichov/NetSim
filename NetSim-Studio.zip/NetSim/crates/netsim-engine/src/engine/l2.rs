//! L2 adapter: per-device protocol state driven by the existing DES queue.
use super::*;
use netsim_packet::ethernet::{ARP, EthernetFrame};
use netsim_protocols::arp::{Arp, ArpCache, Operation};
use netsim_protocols::bridge::{Bridge, BridgeSnapshot, HELLO, PortMode};
use std::{
    collections::{BTreeSet, VecDeque},
    net::Ipv4Addr,
};

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct HostSnapshot {
    pub port: PortId,
    pub ip: Ipv4Addr,
    pub mac: MacAddress,
    pub arp: Vec<(Ipv4Addr, MacAddress, SimTime)>,
    pub received: u64,
    pub last_frame: Option<EthernetFrame>,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct L2Snapshot {
    pub switches: Vec<(DeviceId, BridgeSnapshot)>,
    pub hosts: Vec<(DeviceId, HostSnapshot)>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FrameTx {
    Scheduled { packet: PacketId, arrival: SimTime },
    Dropped(&'static str),
}

struct Host {
    port: PortId,
    ip: Ipv4Addr,
    mac: MacAddress,
    cache: ArpCache,
    received: u64,
    last_frame: Option<EthernetFrame>,
}

impl Host {
    fn frame(
        &self,
        destination: Ipv4Addr,
        target: MacAddress,
        operation: Operation,
    ) -> EthernetFrame {
        EthernetFrame {
            dst: if operation == Operation::Request {
                MacAddress::BROADCAST
            } else {
                target
            },
            src: self.mac,
            tag: None,
            kind: ARP,
            payload: Arp {
                operation,
                sender_mac: self.mac,
                sender_ip: self.ip,
                target_mac: target,
                target_ip: destination,
            }
            .encode(),
        }
    }

    fn receive(
        &mut self,
        port: PortId,
        frame: EthernetFrame,
        now: SimTime,
    ) -> Option<EthernetFrame> {
        if port != self.port
            || frame.tag.is_some()
            || frame.dst == netsim_packet::ethernet::STP_MAC
            || !(frame.dst == self.mac || frame.dst.is_multicast())
        {
            return None;
        }
        self.received = self.received.saturating_add(1);
        self.last_frame = Some(frame.clone());
        if frame.kind != ARP {
            return None;
        }
        let arp = Arp::decode(&frame.payload)?;
        if arp.sender_mac != frame.src {
            return None;
        }
        if arp.target_ip == self.ip || self.cache.lookup(arp.sender_ip, now).is_some() {
            self.cache.learn(arp.sender_ip, arp.sender_mac, now);
        }
        if arp.operation == Operation::Request && arp.target_ip == self.ip {
            Some(self.frame(arp.sender_ip, arp.sender_mac, Operation::Reply))
        } else {
            None
        }
    }

    fn reset(&mut self) {
        self.cache = ArpCache::default();
        self.received = 0;
        self.last_frame = None;
    }
}

#[derive(Default)]
struct Direction {
    pending: VecDeque<(SimTime, u64)>,
    bytes: u64,
}

impl Direction {
    fn prune(&mut self, now: SimTime) {
        while self
            .pending
            .front()
            .is_some_and(|(finish, _)| *finish <= now)
        {
            if let Some((_, bytes)) = self.pending.pop_front() {
                self.bytes -= bytes;
            }
        }
    }
}

#[derive(Default)]
pub(super) struct L2State {
    switches: BTreeMap<DeviceId, Bridge>,
    hosts: BTreeMap<DeviceId, Host>,
    directions: BTreeMap<(LinkId, PortId), Direction>,
    next_packet: u64,
}

impl L2State {
    pub(super) fn forget_link(&mut self, id: LinkId) {
        self.directions.retain(|(link, _), _| *link != id);
    }
    pub(super) fn remove_device(&mut self, id: DeviceId) {
        self.switches.remove(&id);
        self.hosts.remove(&id);
    }
    pub(super) fn clear_direction(&mut self, port: PortId) {
        self.directions.retain(|(_, source), _| *source != port);
    }
    pub(super) fn reset_device(&mut self, id: DeviceId) {
        if let Some(b) = self.switches.get_mut(&id) {
            b.reset();
        }
        if let Some(h) = self.hosts.get_mut(&id) {
            h.reset();
        }
    }
}

impl Engine {
    pub(super) fn require_off(&self, id: DeviceId) -> Result<(), EngineError> {
        let d = self.devices.get(&id).ok_or(EngineError::UnknownDevice)?;
        if d.power != PowerState::Off {
            return Err(EngineError::InvalidState);
        }
        Ok(())
    }

    pub(super) fn check_ethernet_port(
        &self,
        id: DeviceId,
        port: PortId,
    ) -> Result<(), EngineError> {
        let p = self.ports.get(&port).ok_or(EngineError::UnknownPort)?;
        if p.device != id || p.media != MediaKind::Ethernet {
            return Err(EngineError::InvalidInput);
        }
        Ok(())
    }

    /// Explicitly attach the generic learning-bridge component to a powered-off instance.
    /// MAC must be unique across configured L2 endpoints.
    pub fn configure_switch(
        &mut self,
        id: DeviceId,
        priority: u16,
        mac: MacAddress,
    ) -> Result<(), EngineError> {
        self.require_off(id)?;
        if self.l3.contains(id)
            || self.l2.hosts.contains_key(&id)
            || self.l2.switches.contains_key(&id)
            || self.mac_in_use(mac)
        {
            return Err(EngineError::InvalidInput);
        }
        let b = Bridge::new(priority, mac).ok_or(EngineError::InvalidInput)?;
        self.l2.switches.insert(id, b);
        Ok(())
    }

    pub fn configure_switch_port(
        &mut self,
        id: DeviceId,
        port: PortId,
        mode: PortMode,
    ) -> Result<(), EngineError> {
        self.require_off(id)?;
        self.check_ethernet_port(id, port)?;
        let bridge = self
            .l2
            .switches
            .get_mut(&id)
            .ok_or(EngineError::InvalidState)?;
        if !bridge.configure(port, mode) {
            return Err(EngineError::InvalidInput);
        }
        Ok(())
    }

    pub fn configure_host(
        &mut self,
        id: DeviceId,
        port: PortId,
        ip: Ipv4Addr,
        mac: MacAddress,
    ) -> Result<(), EngineError> {
        self.require_off(id)?;
        self.install_l2_host(id, port, ip, mac)
    }
    pub(super) fn install_l2_host(
        &mut self,
        id: DeviceId,
        port: PortId,
        ip: Ipv4Addr,
        mac: MacAddress,
    ) -> Result<(), EngineError> {
        self.check_ethernet_port(id, port)?;
        if self.l3.contains(id)
            || self.l2.switches.contains_key(&id)
            || self.l2.hosts.contains_key(&id)
            || self.mac_in_use(mac)
            || mac.is_multicast()
            || mac.0 == [0; 6]
            || ip.is_unspecified()
            || ip.is_multicast()
            || ip.is_broadcast()
        {
            return Err(EngineError::InvalidInput);
        }
        self.l2.hosts.insert(
            id,
            Host {
                port,
                ip,
                mac,
                cache: ArpCache::default(),
                received: 0,
                last_frame: None,
            },
        );
        Ok(())
    }

    pub(super) fn remove_l2_host(&mut self, id: DeviceId) {
        self.l2.hosts.remove(&id);
    }
    pub(super) fn update_host_ip(&mut self, id: DeviceId, ip: Ipv4Addr) -> Result<(), EngineError> {
        let host = self
            .l2
            .hosts
            .get_mut(&id)
            .ok_or(EngineError::InvalidState)?;
        host.ip = ip;
        host.reset();
        Ok(())
    }

    pub(super) fn has_l2_endpoint(&self, id: DeviceId) -> bool {
        self.l2.hosts.contains_key(&id) || self.l2.switches.contains_key(&id)
    }

    fn mac_in_use(&self, mac: MacAddress) -> bool {
        self.l3.mac_in_use(mac) || self.l2_mac_in_use(mac)
    }

    pub(super) fn l2_mac_in_use(&self, mac: MacAddress) -> bool {
        self.l2.hosts.values().any(|h| h.mac == mac)
            || self.l2.switches.values().any(|b| b.mac() == mac)
    }

    pub fn request_arp(
        &mut self,
        id: DeviceId,
        destination: Ipv4Addr,
    ) -> Result<FrameTx, EngineError> {
        self.active_generation(id)?;
        if destination.is_unspecified() || destination.is_multicast() || destination.is_broadcast()
        {
            return Err(EngineError::InvalidInput);
        }
        let h = self.l2.hosts.get(&id).ok_or(EngineError::InvalidState)?;
        let (port, frame) = (
            h.port,
            h.frame(destination, MacAddress([0; 6]), Operation::Request),
        );
        self.send_frame(port, frame)
    }

    pub fn arp_lookup(&self, id: DeviceId, ip: Ipv4Addr) -> Option<MacAddress> {
        let host = self.l2.hosts.get(&id)?;
        if self.l3.contains(id) {
            self.interface_arp_lookup(
                id,
                super::InterfaceKey {
                    port: host.port,
                    vlan: None,
                },
                ip,
            )
        } else {
            host.cache.lookup(ip, self.now())
        }
    }

    fn drop_frame(&mut self, id: DeviceId, port: PortId, reason: &'static str) -> FrameTx {
        self.record(
            id,
            TraceAction::FrameDrop { port, reason },
            Outcome::Skipped,
        );
        FrameTx::Dropped(reason)
    }

    /// Send bytes across one Ethernet link; separate full-duplex serialization queues.
    /// Link loss, unavailable peers, and congestion are ordinary drops, not device faults.
    pub fn send_frame(
        &mut self,
        port: PortId,
        frame: EthernetFrame,
    ) -> Result<FrameTx, EngineError> {
        let bytes = frame.encode().map_err(|_| EngineError::InvalidInput)?;
        let p = self.ports.get(&port).ok_or(EngineError::UnknownPort)?;
        let id = p.device;
        if p.media != MediaKind::Ethernet {
            return Err(EngineError::InvalidInput);
        }
        let source_generation = self.active_generation(id)?;
        if self.admin_down.contains(&port) {
            return Ok(self.drop_frame(id, port, "admin-down"));
        }
        let Some(link) = self
            .links
            .values()
            .find(|l| l.endpoints.contains(&port))
            .cloned()
        else {
            return Ok(self.drop_frame(id, port, "disconnected"));
        };
        let peer = if link.endpoints[0] == port {
            link.endpoints[1]
        } else {
            link.endpoints[0]
        };
        if self.admin_down.contains(&peer) {
            return Ok(self.drop_frame(id, port, "peer-admin-down"));
        }
        let target = self.ports[&peer].device;
        let Ok(generation) = self.active_generation(target) else {
            return Ok(self.drop_frame(id, port, "peer-off"));
        };
        let now = self.now();
        let wire = EthernetFrame::wire_bytes(bytes.len());
        let delay = netsim_media::serialization_delay_ns(wire, link.bandwidth_bps)
            .ok_or(EngineError::TimeOverflow)?;
        let dir = self.l2.directions.entry((link.id, port)).or_default();
        dir.prune(now);
        if dir.pending.len() >= 4096 || wire > link.queue_limit_bytes.saturating_sub(dir.bytes) {
            return Ok(self.drop_frame(id, port, "link-queue-full"));
        }
        let start = dir.pending.back().map_or(now, |(end, _)| *end);
        let finish = start.checked_add(delay).ok_or(EngineError::TimeOverflow)?;
        let arrival = finish
            .checked_add(link.delay_ns)
            .ok_or(EngineError::TimeOverflow)?;
        // Validate scheduler capacity before reserving serialization for a deliverable frame.
        let lost = link.loss_ppm != 0 && self.rng.next_u64() % 1_000_000 < u64::from(link.loss_ppm);
        if !lost {
            if let Err(error) = self.scheduler.check_batch(1, 0) {
                if error == EngineError::QueueFull {
                    return Ok(self.drop_frame(id, port, "event-queue-full"));
                }
                return Err(error);
            }
        }
        let next = self
            .l2
            .next_packet
            .checked_add(1)
            .ok_or(EngineError::SequenceExhausted)?;
        let packet = PacketId(next);
        let captured = bytes.clone();
        if !lost {
            self.scheduler.schedule(
                arrival,
                target,
                generation,
                EventKind::FrameReceive {
                    port: peer,
                    packet,
                    link: link.id,
                    source: port,
                    source_generation,
                    bytes: bytes.into(),
                },
            )?;
        }
        self.capture.push(netsim_capture::Record {
            at: now,
            device: id,
            port,
            link: link.id,
            packet,
            lost,
            bytes: captured,
        });
        self.l2.next_packet = next;
        let dir = self.l2.directions.entry((link.id, port)).or_default();
        dir.pending.push_back((finish, wire));
        dir.bytes += wire;
        self.record(
            id,
            TraceAction::FrameTx {
                port,
                packet,
                link: link.id,
            },
            Outcome::Applied,
        );
        if lost {
            Ok(self.drop_frame(id, port, "link-loss"))
        } else {
            Ok(FrameTx::Scheduled { packet, arrival })
        }
    }

    pub(super) fn sync_all_l2(&mut self) {
        let ids: Vec<_> = self.l2.switches.keys().copied().collect();
        for id in ids {
            self.sync_l2(id);
        }
        self.sync_all_l3();
    }

    pub(super) fn sync_l2(&mut self, id: DeviceId) {
        if !self.l2.switches.contains_key(&id) {
            return;
        }
        let now = self.now();
        let mut active = BTreeSet::new();
        for link in self.links.values() {
            if link.endpoints.iter().all(|port| {
                !self.admin_down.contains(port)
                    && self.active_generation(self.ports[port].device).is_ok()
            }) {
                for port in link.endpoints {
                    if self.ports[&port].device == id {
                        active.insert(port);
                    }
                }
            }
        }
        if let Some(b) = self.l2.switches.get_mut(&id) {
            b.sync(&active, now);
        }
    }

    pub(super) fn start_l2(&mut self, id: DeviceId) -> Result<(), EngineError> {
        if self.l2.switches.contains_key(&id) || self.services.client(id) {
            self.sync_l2(id);
            let generation = self.active_generation(id)?;
            self.scheduler
                .schedule(self.now(), id, generation, EventKind::L2Tick)?;
        }
        Ok(())
    }

    pub(super) fn tick_l2(&mut self, id: DeviceId) -> Result<(), EngineError> {
        self.sync_l2(id);
        if self.services.client(id) {
            self.dhcp_tick(id)?;
            let g = self.active_generation(id)?;
            self.scheduler.schedule(
                self.now()
                    .checked_add(1_000_000_000)
                    .ok_or(EngineError::TimeOverflow)?,
                id,
                g,
                EventKind::L2Tick,
            )?;
            return Ok(());
        }
        let now = self.now();
        let Some(b) = self.l2.switches.get(&id) else {
            return Ok(());
        };
        let frames = b.hello(now);
        let generation = self.active_generation(id)?;
        let next = now.checked_add(HELLO).ok_or(EngineError::TimeOverflow)?;
        self.scheduler
            .schedule(next, id, generation, EventKind::L2Tick)?;
        for (port, frame) in frames {
            self.send_frame(port, frame)?;
        }
        Ok(())
    }

    pub(super) fn receive_l2(
        &mut self,
        id: DeviceId,
        port: PortId,
        bytes: &[u8],
    ) -> Result<(), EngineError> {
        let Ok(frame) = EthernetFrame::decode(bytes) else {
            self.drop_frame(id, port, "malformed");
            return Ok(());
        };
        if self.receive_dhcp(id, port, &frame)? || self.receive_ospf(id, port, &frame)? {
            return Ok(());
        }
        self.sync_l2(id);
        let now = self.now();
        if self.l3.contains(id) {
            // Preserve legacy host counters/cache, but send exactly one ARP reply via L3.
            if let Some(h) = self.l2.hosts.get_mut(&id) {
                let _ = h.receive(port, frame.clone(), now);
            }
            return self.receive_l3(id, port, frame);
        }
        let frames = if let Some(b) = self.l2.switches.get_mut(&id) {
            b.receive(port, frame, now)
        } else if let Some(h) = self.l2.hosts.get_mut(&id) {
            h.receive(port, frame, now)
                .map_or_else(Vec::new, |f| vec![(port, f)])
        } else {
            Vec::new()
        };
        for (out, frame) in frames {
            self.send_frame(out, frame)?;
        }
        Ok(())
    }

    pub(super) fn l2_snapshot(&self) -> L2Snapshot {
        let now = self.now();
        L2Snapshot {
            switches: self
                .l2
                .switches
                .iter()
                .map(|(id, b)| (*id, b.snapshot(now)))
                .collect(),
            hosts: self
                .l2
                .hosts
                .iter()
                .map(|(id, h)| {
                    (
                        *id,
                        HostSnapshot {
                            port: h.port,
                            ip: h.ip,
                            mac: h.mac,
                            arp: self
                                .interface_arp_entries(
                                    *id,
                                    super::InterfaceKey {
                                        port: h.port,
                                        vlan: None,
                                    },
                                )
                                .unwrap_or_else(|| h.cache.entries(now)),
                            received: h.received,
                            last_frame: h.last_frame.clone(),
                        },
                    )
                })
                .collect(),
        }
    }
}

impl Engine {
    /// Live port changes retain power and restart convergence for the affected port.
    pub fn set_switch_port_mode(
        &mut self,
        id: DeviceId,
        port: PortId,
        mode: PortMode,
    ) -> Result<(), EngineError> {
        self.check_ethernet_port(id, port)?;
        let bridge = self
            .l2
            .switches
            .get_mut(&id)
            .ok_or(EngineError::InvalidState)?;
        if !bridge.configure(port, mode) {
            return Err(EngineError::InvalidInput);
        }
        self.invalidate_port_frames(port);
        self.sync_all_l2();
        Ok(())
    }
}
