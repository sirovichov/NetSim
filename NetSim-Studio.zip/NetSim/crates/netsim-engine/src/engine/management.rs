//! Vendor-neutral management operations, callable at an event boundary.
use super::*;

impl Engine {
    pub fn set_hostname(&mut self, id: DeviceId, name: String) -> Result<(), EngineError> {
        if name.is_empty() || name.len() > 255 || name.chars().any(char::is_control) {
            return Err(EngineError::InvalidInput);
        }
        self.devices
            .get_mut(&id)
            .ok_or(EngineError::UnknownDevice)?
            .hostname_override = Some(name);
        Ok(())
    }

    pub fn port_admin_up(&self, port: PortId) -> bool {
        self.ports.contains_key(&port) && !self.admin_down.contains(&port)
    }

    pub fn port_oper_up(&self, port: PortId) -> bool {
        self.links.values().any(|l| {
            l.endpoints.contains(&port)
                && l.endpoints.iter().all(|p| {
                    self.port_admin_up(*p)
                        && self
                            .ports
                            .get(p)
                            .is_some_and(|p| self.active_generation(p.device).is_ok())
                })
        })
    }

    pub(super) fn invalidate_port_frames(&mut self, port: PortId) {
        self.scheduler.retain(|event| {
            !matches!(&event.kind,
            EventKind::FrameReceive { port: dst, source, .. } if *dst == port || *source == port)
        });
        self.l2.clear_direction(port);
        let links: Vec<_> = self
            .links
            .values()
            .filter(|l| l.endpoints.contains(&port))
            .map(|l| l.id)
            .collect();
        for link in links {
            self.l2.forget_link(link);
        }
    }

    pub fn set_port_admin(&mut self, port: PortId, up: bool) -> Result<(), EngineError> {
        if !self.ports.contains_key(&port) {
            return Err(EngineError::UnknownPort);
        }
        let changed = if up {
            self.admin_down.remove(&port)
        } else {
            self.admin_down.insert(port)
        };
        if changed {
            self.invalidate_port_frames(port);
            self.sync_all_l2();
        }
        Ok(())
    }
}
