//! A bounded single-owner worker. Calls return correlated replies; no wall-clock pacing.
use crate::{
    CommandResult, DispatchReport, Engine, ProcessedEvent, SimulationSnapshot, TraceSnapshot,
};
use netsim_core::{DeviceId, EngineCommand, EngineError, MediaKind, PortId, SimTime, TimerId};
use std::sync::{Arc, Mutex, mpsc};
use std::thread::{self, JoinHandle};

pub const MAX_WORKER_BATCH: usize = 4096;

#[derive(Debug)]
pub enum WorkerRequest {
    Execute(EngineCommand),
    AddPort {
        device: DeviceId,
        media: MediaKind,
    },
    SetTimer {
        device: DeviceId,
        timer: TimerId,
        delay: SimTime,
    },
    CancelTimer {
        device: DeviceId,
        timer: TimerId,
    },
    ConfigureSwitch {
        device: DeviceId,
        priority: u16,
        mac: netsim_core::MacAddress,
    },
    ConfigureSwitchPort {
        device: DeviceId,
        port: PortId,
        mode: crate::PortMode,
    },
    ConfigureHost {
        device: DeviceId,
        port: PortId,
        ip: std::net::Ipv4Addr,
        mac: netsim_core::MacAddress,
    },
    SendFrame {
        port: PortId,
        frame: crate::EthernetFrame,
    },
    RequestArp {
        device: DeviceId,
        destination: std::net::Ipv4Addr,
    },
    ConfigureIpv4Host {
        device: DeviceId,
        config: crate::InterfaceConfig,
        gateway: Option<std::net::Ipv4Addr>,
    },
    ConfigureRouter {
        device: DeviceId,
    },
    ConfigureRouterInterface {
        device: DeviceId,
        config: crate::InterfaceConfig,
    },
    AddStaticRoute {
        device: DeviceId,
        route: crate::Route,
    },
    RemoveStaticRoute {
        device: DeviceId,
        route: crate::Route,
    },
    Ping {
        device: DeviceId,
        destination: std::net::Ipv4Addr,
        ttl: u8,
        timeout: SimTime,
    },
    Probe {
        device: DeviceId,
        token: u32,
    },
    Step,
    RunUntil {
        deadline: SimTime,
        budget: usize,
    },
    Trace,
    Shutdown,
}

#[derive(Debug)]
pub enum WorkerResponse {
    Command(CommandResult),
    Port(PortId),
    Done,
    Frame(crate::FrameTx),
    ProbeStarted(u32),
    Probe(Option<crate::Probe>),
    Step(Option<ProcessedEvent>),
    Run(DispatchReport),
    Trace(TraceSnapshot),
}

pub type Reply = Result<WorkerResponse, EngineError>;
type Envelope = (WorkerRequest, mpsc::Sender<Reply>);

#[derive(Clone)]
pub struct WorkerHandle {
    sender: mpsc::SyncSender<Envelope>,
    latest: Arc<Mutex<Arc<SimulationSnapshot>>>,
}

impl WorkerHandle {
    /// Blocking request with a private reply channel (no reply loss or ID collisions).
    /// GUI must call this off its UI thread.
    pub fn request(&self, request: WorkerRequest) -> Reply {
        let (tx, rx) = mpsc::channel();
        self.sender
            .send((request, tx))
            .map_err(|_| EngineError::WorkerClosed)?;
        rx.recv().map_err(|_| EngineError::WorkerClosed)?
    }

    /// Nonblocking submission; caller polls the returned receiver.
    pub fn try_request(
        &self,
        request: WorkerRequest,
    ) -> Result<mpsc::Receiver<Reply>, EngineError> {
        let (tx, rx) = mpsc::channel();
        self.sender
            .try_send((request, tx))
            .map_err(|err| match err {
                mpsc::TrySendError::Full(_) => EngineError::QueueFull,
                mpsc::TrySendError::Disconnected(_) => EngineError::WorkerClosed,
            })?;
        Ok(rx)
    }

    pub fn latest(&self) -> Result<Arc<SimulationSnapshot>, EngineError> {
        self.latest
            .lock()
            .map(|s| Arc::clone(&s))
            .map_err(|_| EngineError::WorkerClosed)
    }
}

pub struct Worker {
    handle: WorkerHandle,
    thread: JoinHandle<()>,
}

impl Worker {
    pub fn spawn(mut engine: Engine, capacity: usize) -> std::io::Result<Self> {
        let (sender, receiver) = mpsc::sync_channel::<Envelope>(capacity);
        let latest = Arc::new(Mutex::new(Arc::new(engine.snapshot())));
        let publish = Arc::clone(&latest);
        let thread = thread::Builder::new()
            .name("netsim-core".into())
            .spawn(move || {
                while let Ok((request, reply)) = receiver.recv() {
                    let shutdown = matches!(&request, WorkerRequest::Shutdown);
                    let result = process(&mut engine, request);
                    match publish.lock() {
                        Ok(mut slot) => *slot = Arc::new(engine.snapshot()),
                        Err(_) => break,
                    }
                    // A client may discard its receiver; the command has still executed.
                    let _ = reply.send(result);
                    if shutdown {
                        break;
                    }
                }
            })?;
        Ok(Self {
            handle: WorkerHandle { sender, latest },
            thread,
        })
    }

    pub fn handle(&self) -> WorkerHandle {
        self.handle.clone()
    }

    /// Request shutdown and join even if other handles still exist.
    pub fn join(self) -> thread::Result<()> {
        let _ = self.handle.request(WorkerRequest::Shutdown);
        self.thread.join()
    }
}

fn process(engine: &mut Engine, request: WorkerRequest) -> Reply {
    match request {
        WorkerRequest::Execute(command) => engine.execute(command).map(WorkerResponse::Command),
        WorkerRequest::AddPort { device, media } => {
            engine.add_port(device, media).map(WorkerResponse::Port)
        }
        WorkerRequest::SetTimer {
            device,
            timer,
            delay,
        } => engine
            .set_timer(device, timer, delay)
            .map(|()| WorkerResponse::Done),
        WorkerRequest::CancelTimer { device, timer } => engine
            .cancel_timer(device, timer)
            .map(|()| WorkerResponse::Done),
        WorkerRequest::ConfigureSwitch {
            device,
            priority,
            mac,
        } => engine
            .configure_switch(device, priority, mac)
            .map(|()| WorkerResponse::Done),
        WorkerRequest::ConfigureSwitchPort { device, port, mode } => engine
            .configure_switch_port(device, port, mode)
            .map(|()| WorkerResponse::Done),
        WorkerRequest::ConfigureHost {
            device,
            port,
            ip,
            mac,
        } => engine
            .configure_host(device, port, ip, mac)
            .map(|()| WorkerResponse::Done),
        WorkerRequest::SendFrame { port, frame } => {
            engine.send_frame(port, frame).map(WorkerResponse::Frame)
        }
        WorkerRequest::RequestArp {
            device,
            destination,
        } => engine
            .request_arp(device, destination)
            .map(WorkerResponse::Frame),
        WorkerRequest::ConfigureIpv4Host {
            device,
            config,
            gateway,
        } => engine
            .configure_ipv4_host(device, config, gateway)
            .map(|()| WorkerResponse::Done),
        WorkerRequest::ConfigureRouter { device } => engine
            .configure_router(device)
            .map(|()| WorkerResponse::Done),
        WorkerRequest::ConfigureRouterInterface { device, config } => engine
            .configure_router_interface(device, config)
            .map(|()| WorkerResponse::Done),
        WorkerRequest::AddStaticRoute { device, route } => engine
            .add_static_route(device, route)
            .map(|()| WorkerResponse::Done),
        WorkerRequest::RemoveStaticRoute { device, route } => engine
            .remove_static_route(device, route)
            .map(|()| WorkerResponse::Done),
        WorkerRequest::Ping {
            device,
            destination,
            ttl,
            timeout,
        } => engine
            .ping(device, destination, ttl, timeout)
            .map(WorkerResponse::ProbeStarted),
        WorkerRequest::Probe { device, token } => {
            Ok(WorkerResponse::Probe(engine.probe(device, token)))
        }
        WorkerRequest::Step => Ok(WorkerResponse::Step(engine.step())),
        WorkerRequest::RunUntil { deadline, budget } => engine
            .run_until(deadline, budget.min(MAX_WORKER_BATCH))
            .map(WorkerResponse::Run),
        WorkerRequest::Trace => Ok(WorkerResponse::Trace(engine.trace())),
        WorkerRequest::Shutdown => Ok(WorkerResponse::Done),
    }
}
