use netsim_core::SimEvent;
use std::cmp::Ordering;
use std::collections::BinaryHeap;

struct Entry(SimEvent);

impl PartialEq for Entry {
    fn eq(&self, other: &Self) -> bool {
        (self.0.at, self.0.sequence) == (other.0.at, other.0.sequence)
    }
}

impl Eq for Entry {}

impl PartialOrd for Entry {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for Entry {
    fn cmp(&self, other: &Self) -> Ordering {
        (other.0.at, other.0.sequence).cmp(&(self.0.at, self.0.sequence))
    }
}

#[derive(Default)]
pub(crate) struct EventQueue {
    entries: BinaryHeap<Entry>,
}

impl EventQueue {
    pub(crate) fn len(&self) -> usize {
        self.entries.len()
    }

    pub(crate) fn push(&mut self, event: SimEvent) {
        self.entries.push(Entry(event));
    }

    pub(crate) fn peek(&self) -> Option<&SimEvent> {
        self.entries.peek().map(|entry| &entry.0)
    }

    pub(crate) fn count_where(&self, mut predicate: impl FnMut(&SimEvent) -> bool) -> usize {
        self.entries
            .iter()
            .filter(|entry| predicate(&entry.0))
            .count()
    }

    pub(crate) fn retain(&mut self, mut keep: impl FnMut(&SimEvent) -> bool) {
        self.entries.retain(|entry| keep(&entry.0));
    }

    pub(crate) fn pop(&mut self) -> Option<SimEvent> {
        self.entries.pop().map(|entry| entry.0)
    }
}
