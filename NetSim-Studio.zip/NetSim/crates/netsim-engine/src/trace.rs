use netsim_core::{DeviceId, EngineError, EventKind, LinkId, PacketId, PortId, SimTime, TimerId};
use std::collections::VecDeque;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum TraceAction {
    Added,
    Removed,
    PowerOn,
    PowerOff,
    FrameTx {
        port: PortId,
        packet: PacketId,
        link: LinkId,
    },
    FrameDrop {
        port: PortId,
        reason: &'static str,
    },
    IpDrop {
        reason: &'static str,
    },
    Event {
        sequence: u64,
        kind: &'static str,
        detail: EventDetail,
    },
}

/// No raw CLI command, credentials, output, or packet payload is retained.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum EventDetail {
    None,
    Timer(TimerId),
    Link {
        id: LinkId,
        up: bool,
    },
    Receive {
        port: PortId,
        packet: PacketId,
        link: LinkId,
    },
}

impl From<&EventKind> for EventDetail {
    fn from(event: &EventKind) -> Self {
        match event {
            EventKind::TimerExpired { timer, .. } => Self::Timer(*timer),
            EventKind::LinkChanged { link, up } => Self::Link { id: *link, up: *up },
            EventKind::PacketReceive {
                port, packet, link, ..
            }
            | EventKind::FrameReceive {
                port, packet, link, ..
            } => Self::Receive {
                port: *port,
                packet: *packet,
                link: *link,
            },
            _ => Self::None,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Outcome {
    Applied,
    Skipped,
    Failed(EngineError),
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TraceEntry {
    pub at: SimTime,
    pub device: DeviceId,
    pub action: TraceAction,
    pub outcome: Outcome,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TraceSnapshot {
    pub dropped: u64,
    pub entries: Vec<TraceEntry>,
}

pub(crate) struct Trace {
    entries: VecDeque<TraceEntry>,
    capacity: usize,
    dropped: u64,
}

impl Trace {
    pub(crate) fn new(capacity: usize) -> Self {
        Self {
            entries: VecDeque::new(),
            capacity,
            dropped: 0,
        }
    }

    pub(crate) fn push(&mut self, entry: TraceEntry) {
        if self.entries.len() == self.capacity {
            self.dropped = self.dropped.saturating_add(1);
            if self.capacity == 0 {
                return;
            }
            self.entries.pop_front();
        }
        self.entries.push_back(entry);
    }

    pub(crate) fn snapshot(&self) -> TraceSnapshot {
        TraceSnapshot {
            dropped: self.dropped,
            entries: self.entries.iter().cloned().collect(),
        }
    }
}
