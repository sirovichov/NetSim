//! CLI mode contracts. Vendor grammar and execution are future work.

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum CliMode {
    #[default]
    UserExec,
    PrivilegedExec,
    GlobalConfig,
    InterfaceConfig,
    RouterConfig,
}
