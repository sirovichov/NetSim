//! Device contracts and draft catalog entries; no simulated vendor behavior yet.

use netsim_core::{
    DeviceId, EngineError, EventKind, LinkId, MediaKind, PortId, SessionId, SimEvent, SimTime,
    TimerId,
};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct DeviceDescriptor {
    pub profile_id: &'static str,
    pub profile_version: u32,
    pub vendor: &'static str,
    pub model: &'static str,
    pub firmware_reference: Option<&'static str>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DeviceSnapshot {
    pub id: DeviceId,
    pub hostname: String,
}

/// Ordered requests; the engine validates and applies them after the callback.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum DeviceEffect {
    SetTimer { timer: TimerId, at: SimTime },
    CancelTimer(TimerId),
}

/// SplitMix64, fixed algorithm v1. Not for cryptography.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct SimRng(u64);

impl SimRng {
    pub fn new(seed: u64) -> Self {
        Self(seed)
    }

    pub fn next_u64(&mut self) -> u64 {
        self.0 = self.0.wrapping_add(0x9e3779b97f4a7c15);
        let mut z = self.0;
        z = (z ^ (z >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94d049bb133111eb);
        z ^ (z >> 31)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct LocalPort {
    pub id: PortId,
    pub media: MediaKind,
    pub link: Option<LinkId>,
}

pub struct DeviceContext {
    now: SimTime,
    rng: SimRng,
    effects: Vec<DeviceEffect>,
    max_effects: usize,
    ports: Vec<LocalPort>,
}

impl DeviceContext {
    pub fn new(now: SimTime) -> Self {
        Self::with_seed(now, 0, 256)
    }

    pub fn with_seed(now: SimTime, seed: u64, max_effects: usize) -> Self {
        Self {
            now,
            rng: SimRng::new(seed),
            effects: Vec::new(),
            max_effects,
            ports: Vec::new(),
        }
    }

    pub fn now(&self) -> SimTime {
        self.now
    }

    pub fn with_ports(mut self, ports: Vec<LocalPort>) -> Self {
        self.ports = ports;
        self
    }

    pub fn ports(&self) -> &[LocalPort] {
        &self.ports
    }

    pub fn random_u64(&mut self) -> u64 {
        self.rng.next_u64()
    }

    pub fn set_timer(&mut self, timer: TimerId, delay: SimTime) -> Result<(), EngineError> {
        let at = self
            .now
            .checked_add(delay)
            .ok_or(EngineError::TimeOverflow)?;
        self.push(DeviceEffect::SetTimer { timer, at })
    }

    pub fn cancel_timer(&mut self, timer: TimerId) -> Result<(), EngineError> {
        self.push(DeviceEffect::CancelTimer(timer))
    }

    fn push(&mut self, effect: DeviceEffect) -> Result<(), EngineError> {
        if self.effects.len() >= self.max_effects {
            return Err(EngineError::ResourceLimit);
        }
        self.effects.push(effect);
        Ok(())
    }

    pub fn into_effects(self) -> Vec<DeviceEffect> {
        self.effects
    }
}

pub type DeviceEvent = EventKind;
pub type DeviceError = EngineError;
pub type CliResult = Result<String, DeviceError>;

pub trait NetworkDevice: Send {
    fn id(&self) -> DeviceId;
    fn descriptor(&self) -> &DeviceDescriptor;
    fn on_event(&mut self, event: DeviceEvent, ctx: &mut DeviceContext) -> Result<(), DeviceError>;
    fn execute_cli(
        &mut self,
        session: SessionId,
        command: &str,
        ctx: &mut DeviceContext,
    ) -> CliResult;
    fn snapshot(&self) -> DeviceSnapshot;
}

/// Legacy isolated dispatch helper; use the engine for timer effects and generation checks.
pub fn dispatch(device: &mut dyn NetworkDevice, event: SimEvent) -> Result<(), DeviceError> {
    if device.id() != event.target {
        return Err(EngineError::Unsupported);
    }
    let mut context = DeviceContext::new(event.at);
    device.on_event(event.kind, &mut context)?;
    if context.into_effects().is_empty() {
        Ok(())
    } else {
        Err(EngineError::Unsupported)
    }
}
