use netsim_app::create_engine;
use netsim_core::{DeviceId, EngineCommand, EngineError, MacAddress, MediaKind, PortId};
use netsim_engine::{
    CommandResult, Engine, EngineLimits, EthernetFrame, FrameTx, PortMode, PortState, Role, Tag,
};
use std::net::Ipv4Addr;

const SEC: u64 = 1_000_000_000;
fn mac(n: u8) -> MacAddress {
    MacAddress([2, 0, 0, 0, 0, n])
}
fn ip(n: u8) -> Ipv4Addr {
    Ipv4Addr::new(10, 0, 0, n)
}
fn engine() -> Engine {
    create_engine(42, EngineLimits::default()).unwrap()
}
fn host(e: &mut Engine, n: u8) -> (DeviceId, PortId) {
    let d = e
        .add_device("generic.host.pc", 1, format!("PC{n}"))
        .unwrap();
    let p = e.add_port(d, MediaKind::Ethernet).unwrap();
    e.configure_host(d, p, ip(n), mac(n)).unwrap();
    (d, p)
}
fn switch(e: &mut Engine, n: u8, modes: Vec<PortMode>) -> (DeviceId, Vec<PortId>) {
    let d = e
        .add_device(
            if n % 2 == 0 {
                "cisco.switch.2960"
            } else {
                "eltex.switch.mes2428"
            },
            1,
            format!("SW{n}"),
        )
        .unwrap();
    e.configure_switch(d, 32768, mac(n)).unwrap();
    let ports = modes
        .into_iter()
        .map(|mode| {
            let p = e.add_port(d, MediaKind::Ethernet).unwrap();
            e.configure_switch_port(d, p, mode).unwrap();
            p
        })
        .collect();
    (d, ports)
}
fn connect(e: &mut Engine, a: PortId, b: PortId, loss: u32, queue: u64) -> netsim_core::LinkId {
    match e
        .execute(EngineCommand::ConnectPorts {
            endpoints: [a, b],
            bandwidth_bps: 100_000_000,
            delay_ns: 100,
            loss_ppm: loss,
            queue_limit_bytes: queue,
        })
        .unwrap()
    {
        CommandResult::LinkAdded(id) => id,
        _ => panic!("expected link"),
    }
}
fn cable(e: &mut Engine, a: PortId, b: PortId) -> netsim_core::LinkId {
    connect(e, a, b, 0, 65536)
}
fn power(e: &mut Engine, ids: &[DeviceId]) {
    for id in ids {
        e.power_on(*id).unwrap();
    }
}
fn run(e: &mut Engine, deadline: u64) {
    let report = e.run_until(deadline, 20_000).unwrap();
    assert!(!report.budget_exhausted && !report.faulted, "{report:?}");
}
fn frame(src: u8, dst: MacAddress) -> EthernetFrame {
    EthernetFrame {
        dst,
        src: mac(src),
        tag: None,
        kind: 0x0800,
        payload: vec![1, 2, 3],
    }
}
fn received(e: &Engine, d: DeviceId) -> u64 {
    e.snapshot()
        .l2
        .hosts
        .iter()
        .find(|(id, _)| *id == d)
        .unwrap()
        .1
        .received
}
fn trunk(v: &[u16]) -> PortMode {
    PortMode::Trunk {
        native: None,
        allowed: v.iter().copied().collect(),
    }
}

#[test]
fn arp_over_switch_and_known_unicast_not_flooded() {
    let mut e = engine();
    let (a, pa) = host(&mut e, 1);
    let (b, pb) = host(&mut e, 2);
    let (c, pc) = host(&mut e, 3);
    let (s, p) = switch(&mut e, 10, vec![PortMode::Access(10); 3]);
    cable(&mut e, pa, p[0]);
    cable(&mut e, pb, p[1]);
    cable(&mut e, pc, p[2]);
    power(&mut e, &[a, b, c, s]);
    run(&mut e, 40 * SEC);
    e.request_arp(a, ip(2)).unwrap();
    run(&mut e, 41 * SEC);
    assert_eq!(e.arp_lookup(a, ip(2)), Some(mac(2)));
    assert_eq!(e.arp_lookup(b, ip(1)), Some(mac(1)));
    assert_eq!(e.snapshot().l2.switches[0].1.macs.len(), 2);
    let count = received(&e, c);
    // Trace proves no physical TX onto C's switch port, even if C would filter it.
    let at = e.now();
    e.send_frame(pa, frame(1, mac(2))).unwrap();
    run(&mut e, 41 * SEC + 1_000_000);
    assert_eq!(received(&e, c), count);
    assert!(!e.trace().entries.iter().any(|t| t.at >= at
        && matches!(&t.action,
        netsim_engine::TraceAction::FrameTx { port, .. } if *port == p[2])));
    run(&mut e, 102 * SEC);
    assert_eq!(e.arp_lookup(a, ip(2)), None);
    run(&mut e, 350 * SEC);
    assert!(e.snapshot().l2.switches[0].1.macs.is_empty());
}

#[test]
fn vlan_isolation_and_tagged_access_rejection() {
    let mut e = engine();
    let (a, pa) = host(&mut e, 1);
    let (b, pb) = host(&mut e, 2);
    let (s, p) = switch(&mut e, 10, vec![PortMode::Access(10), PortMode::Access(20)]);
    cable(&mut e, pa, p[0]);
    cable(&mut e, pb, p[1]);
    power(&mut e, &[a, b, s]);
    run(&mut e, 40 * SEC);
    e.request_arp(a, ip(2)).unwrap();
    run(&mut e, 41 * SEC);
    assert_eq!(e.arp_lookup(a, ip(2)), None);
    assert_eq!(received(&e, b), 0);
    let mut f = frame(1, MacAddress::BROADCAST);
    f.tag = Some(Tag {
        vid: 20,
        pcp: 0,
        dei: false,
    });
    e.send_frame(pa, f).unwrap();
    run(&mut e, 42 * SEC);
    assert_eq!(received(&e, b), 0);
}

#[test]
fn trunk_interoperability_and_egress_untagging() {
    let mut e = engine();
    let (a, pa) = host(&mut e, 1);
    let (b, pb) = host(&mut e, 2);
    let (c, pc) = host(&mut e, 3);
    let (s, p) = switch(&mut e, 10, vec![PortMode::Access(10), trunk(&[10, 20])]);
    let (t, q) = switch(
        &mut e,
        11,
        vec![PortMode::Access(10), trunk(&[10, 20]), PortMode::Access(20)],
    );
    cable(&mut e, pa, p[0]);
    cable(&mut e, p[1], q[1]);
    cable(&mut e, pb, q[0]);
    cable(&mut e, pc, q[2]);
    power(&mut e, &[a, b, c, s, t]);
    run(&mut e, 45 * SEC);
    e.request_arp(a, ip(2)).unwrap();
    run(&mut e, 46 * SEC);
    assert_eq!(e.arp_lookup(a, ip(2)), Some(mac(2)));
    assert_eq!(received(&e, c), 0);
    let snap = e.snapshot();
    assert!(
        snap.l2
            .hosts
            .iter()
            .filter_map(|(_, h)| h.last_frame.as_ref())
            .all(|f| f.tag.is_none())
    );
}

#[test]
fn triangle_stp_blocks_and_recovers_after_link_failure() {
    let mut e = engine();
    let (a, pa) = host(&mut e, 1);
    let (b, pb) = host(&mut e, 2);
    let (s, p) = switch(&mut e, 10, vec![PortMode::Access(10); 3]);
    let (t, q) = switch(&mut e, 11, vec![PortMode::Access(10); 2]);
    let (u, r) = switch(&mut e, 12, vec![PortMode::Access(10); 3]);
    cable(&mut e, pa, p[0]);
    cable(&mut e, pb, r[0]);
    cable(&mut e, p[1], q[0]);
    let direct = cable(&mut e, p[2], r[1]);
    cable(&mut e, q[1], r[2]);
    power(&mut e, &[a, b, s, t, u]);
    run(&mut e, 50 * SEC);
    let snap = e.snapshot();
    let root = snap.l2.switches[0].1.bridge;
    assert!(snap.l2.switches.iter().all(|(_, b)| b.root == root));
    assert_eq!(
        snap.l2
            .switches
            .iter()
            .flat_map(|(_, b)| &b.ports)
            .filter(|(_, role, state)| *role == Role::Alternate && *state == PortState::Blocking)
            .count(),
        1
    );
    e.request_arp(a, ip(2)).unwrap();
    run(&mut e, 51 * SEC);
    assert_eq!(e.arp_lookup(a, ip(2)), Some(mac(2)));
    e.disconnect(direct).unwrap();
    run(&mut e, 100 * SEC);
    let count = received(&e, b);
    e.send_frame(pa, frame(1, MacAddress::BROADCAST)).unwrap();
    run(&mut e, 101 * SEC);
    assert_eq!(received(&e, b), count + 1);
    assert!(e.snapshot().l2.switches.iter().all(|(_, b)| b.root == root));
}

#[test]
fn full_duplex_serialization_and_queue_limit() {
    let mut e = engine();
    let (a, pa) = host(&mut e, 1);
    let (b, pb) = host(&mut e, 2);
    connect(&mut e, pa, pb, 0, 168);
    power(&mut e, &[a, b]);
    let first = e.send_frame(pa, frame(1, mac(2))).unwrap();
    let second = e.send_frame(pa, frame(1, mac(2))).unwrap();
    let reverse = e.send_frame(pb, frame(2, mac(1))).unwrap();
    assert!(matches!(first, FrameTx::Scheduled { arrival: 6820, .. }));
    assert!(matches!(second, FrameTx::Scheduled { arrival: 13540, .. }));
    assert!(matches!(reverse, FrameTx::Scheduled { arrival: 6820, .. }));
    assert_eq!(
        e.send_frame(pa, frame(1, mac(2))).unwrap(),
        FrameTx::Dropped("link-queue-full")
    );
    run(&mut e, 20_000);
    assert_eq!(received(&e, b), 2);
    assert_eq!(received(&e, a), 1);
}

#[test]
fn total_loss_and_stale_delivery() {
    let mut e = engine();
    let (a, pa) = host(&mut e, 1);
    let (b, pb) = host(&mut e, 2);
    let l = connect(&mut e, pa, pb, 1_000_000, 65536);
    power(&mut e, &[a, b]);
    assert_eq!(
        e.send_frame(pa, frame(1, mac(2))).unwrap(),
        FrameTx::Dropped("link-loss")
    );
    run(&mut e, 20_000);
    assert_eq!(received(&e, b), 0);
    e.disconnect(l).unwrap();
    cable(&mut e, pa, pb);
    e.send_frame(pa, frame(1, mac(2))).unwrap();
    e.power_off(a).unwrap();
    e.power_on(a).unwrap();
    run(&mut e, 40_000);
    assert_eq!(received(&e, b), 0);
    e.send_frame(pa, frame(1, mac(2))).unwrap();
    run(&mut e, 60_000);
    assert_eq!(received(&e, b), 1);
}

#[test]
fn configuration_and_replay() {
    let mut e = engine();
    let (a, pa) = host(&mut e, 1);
    let s = e.add_device("cisco.switch.2960", 1, "SW".into()).unwrap();
    assert_eq!(
        e.configure_switch(s, 32768, mac(1)),
        Err(EngineError::InvalidInput)
    );
    e.configure_switch(s, 32768, mac(10)).unwrap();
    assert_eq!(
        e.configure_switch_port(s, pa, PortMode::Access(10)),
        Err(EngineError::InvalidInput)
    );
    let p = e.add_port(s, MediaKind::Ethernet).unwrap();
    assert_eq!(
        e.configure_switch_port(s, p, PortMode::Access(4095)),
        Err(EngineError::InvalidInput)
    );
    power(&mut e, &[a, s]);
    assert_eq!(
        e.configure_switch_port(s, p, PortMode::Access(10)),
        Err(EngineError::InvalidState)
    );
    assert_eq!(
        netsim_app::l2_demo().unwrap(),
        netsim_app::l2_demo().unwrap()
    );
}

#[test]
fn trunk_allowed_and_native_vlan_policy() {
    let mode = PortMode::Trunk {
        native: Some(10),
        allowed: [10, 20].into_iter().collect(),
    };
    assert!(mode.valid());
    assert_eq!(mode.ingress(None), Some(10));
    assert_eq!(
        mode.ingress(Some(Tag {
            vid: 30,
            pcp: 0,
            dei: false
        })),
        None
    );
    assert_eq!(mode.egress(10, None), Some(None));
    assert_eq!(
        mode.egress(20, None),
        Some(Some(Tag {
            vid: 20,
            pcp: 0,
            dei: false
        }))
    );
    assert_eq!(mode.egress(30, None), None);
}

#[test]
fn worker_configures_and_delivers_l2() {
    use netsim_engine::{Worker, WorkerRequest, WorkerResponse};
    let mut e = engine();
    let a = e.add_device("generic.host.pc", 1, "A".into()).unwrap();
    let b = e.add_device("generic.host.pc", 1, "B".into()).unwrap();
    let pa = e.add_port(a, MediaKind::Ethernet).unwrap();
    let pb = e.add_port(b, MediaKind::Ethernet).unwrap();
    cable(&mut e, pa, pb);
    let worker = Worker::spawn(e, 8).unwrap();
    let handle = worker.handle();
    for (device, port, n) in [(a, pa, 1), (b, pb, 2)] {
        assert!(matches!(
            handle
                .request(WorkerRequest::ConfigureHost {
                    device,
                    port,
                    ip: ip(n),
                    mac: mac(n)
                })
                .unwrap(),
            WorkerResponse::Done
        ));
        handle
            .request(WorkerRequest::Execute(EngineCommand::PowerOn(device)))
            .unwrap();
    }
    assert!(matches!(
        handle
            .request(WorkerRequest::RequestArp {
                device: a,
                destination: ip(2)
            })
            .unwrap(),
        WorkerResponse::Frame(FrameTx::Scheduled { .. })
    ));
    handle
        .request(WorkerRequest::RunUntil {
            deadline: 100_000,
            budget: 100,
        })
        .unwrap();
    assert_eq!(handle.latest().unwrap().l2.hosts[0].1.arp[0].1, mac(2));
    worker.join().unwrap();
}
