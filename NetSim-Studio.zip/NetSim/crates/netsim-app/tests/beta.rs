use netsim_app::{create_engine, desktop::Desktop};
use netsim_core::{DeviceId, EventKind};
use netsim_engine::EngineLimits;
use netsim_storage::Project;
#[test]
fn capture_contains_actual_arp_and_icmp() {
    let mut d = Desktop::from_project(
        Project::decode(include_bytes!("../../../examples/two-pcs.netsim")).unwrap(),
    )
    .unwrap();
    let token = d.ping(1, "10.0.0.2".parse().unwrap()).unwrap();
    for _ in 0..6 {
        d.advance(1_000_000_000).unwrap();
    }
    let s = d.snapshot();
    assert!(s.l3.nodes.iter().any(|n| {
        n.probes.iter().any(|p| {
            p.token == token && matches!(p.status, netsim_engine::ProbeStatus::Reply { .. })
        })
    }));
    let c = d.capture();
    assert!(
        c.records()
            .iter()
            .any(|r| netsim_capture::inspect(r).iter().any(|s| s.contains("ARP")))
    );
    assert!(c.records().iter().any(|r| {
        netsim_capture::inspect(r)
            .iter()
            .any(|s| s.contains("ICMP"))
    }));
    let mut bytes = vec![];
    netsim_capture::write_pcap(&mut bytes, c.records().iter().cloned()).unwrap();
    assert!(bytes.len() > 24);
}
#[test]
fn scheduler_load_100k() {
    let mut s = netsim_engine::Scheduler::new(100_000);
    let start = std::time::Instant::now();
    for i in (0..100_000).rev() {
        s.schedule(i, DeviceId(1), 0, EventKind::DeviceBoot)
            .unwrap();
    }
    let report = s.run_until(100_000, 100_000).unwrap();
    assert_eq!(report.events.len(), 100_000);
    assert!(!report.budget_exhausted);
    assert!(report.events.windows(2).all(|w| w[0].at <= w[1].at));
    eprintln!("100k queue insert+drain: {:?}", start.elapsed());
}
#[test]
fn engine_capacity_100_devices() {
    let mut e = create_engine(42, EngineLimits::default()).unwrap();
    for i in 0..100 {
        let id = e
            .add_device("generic.host.pc", 1, format!("PC{i}"))
            .unwrap();
        e.power_on(id).unwrap();
    }
    assert_eq!(e.snapshot().devices.len(), 100);
}

#[test]
fn service_cli_roundtrip() {
    let mut d = Desktop::from_project(
        Project::decode(include_bytes!("../../../examples/two-pcs.netsim")).unwrap(),
    )
    .unwrap();
    assert!(d.service_cli(1, ":ospf enable 1.1.1.1").is_err());
    d.service_cli(1, ":dhcp client").unwrap();
    assert!(d.export().unwrap().services.dhcp_clients.contains(&1));
    assert!(
        d.service_cli(1, ":dhcp show")
            .unwrap()
            .contains("Selecting")
    );
}
