use netsim_app::desktop::Desktop;
use netsim_engine::{DhcpPhase, ProbeStatus, RouteOrigin};
use netsim_storage::{ApConfig, Endpoint, HostConfig, Model, Project, WifiClient};
fn ep(node: u64, port: &str) -> Endpoint {
    Endpoint {
        node,
        port: port.into(),
    }
}
fn host(d: &mut Desktop, id: u64, ip: &str) {
    d.configure_host(
        id,
        HostConfig {
            ip: ip.parse().unwrap(),
            prefix: 24,
            gateway: None,
        },
    )
    .unwrap();
}
fn run(d: &mut Desktop, seconds: u64) {
    for _ in 0..seconds {
        d.advance(1_000_000_000).unwrap();
    }
}
fn cli(d: &mut Desktop, id: u64, cmds: &[&str]) {
    for c in cmds {
        let r = d.execute(id, c).unwrap();
        assert!(!r.starts_with('%'), "{c}: {r}");
    }
}
#[test]
fn wireless_dhcp_and_ping() {
    let p = Project::decode(include_bytes!("../../../examples/wireless-dhcp.netsim")).unwrap();
    let mut d = Desktop::from_project(p).unwrap();
    assert_eq!(d.associations()[0].ap, 2);
    run(&mut d, 50);
    let status = d
        .dhcp_status()
        .into_iter()
        .find(|s| Some(s.device) == d.engine_id(3))
        .unwrap();
    assert_eq!(status.phase, DhcpPhase::Bound);
    assert_eq!(status.address, Some("10.0.0.100".parse().unwrap()));
    let token = d.ping(3, "10.0.0.1".parse().unwrap()).unwrap();
    run(&mut d, 3);
    assert!(
        d.snapshot()
            .l3
            .nodes
            .iter()
            .find(|n| Some(n.device) == d.engine_id(3))
            .unwrap()
            .probes
            .iter()
            .any(|p| p.token == token && matches!(p.status, ProbeStatus::Reply { .. }))
    );
    let saved = d.export().unwrap();
    assert_eq!(saved.nodes.iter().find(|n| n.id == 3).unwrap().host, None);
    let d2 = Desktop::from_project(Project::decode(&saved.encode().unwrap()).unwrap()).unwrap();
    assert_eq!(d2.associations()[0].ap, 2);
    assert_eq!(d2.dhcp_status()[0].phase, DhcpPhase::Selecting);
}
#[test]
fn wrong_psk_range_and_power() {
    let mut d = Desktop::new(42).unwrap();
    let ap = d.add(Model::Wep2acSmart, [0., 0.]).unwrap();
    let laptop = d.add(Model::Laptop, [10., 0.]).unwrap();
    let mut conf = ApConfig::default();
    conf.vaps[0].psk = Some("correct123".into());
    d.configure_ap(ap, conf.clone()).unwrap();
    let c = |s: &str| WifiClient {
        radio: 2,
        ssid: "NetSim".into(),
        psk: Some(s.into()),
    };
    d.configure_wifi(laptop, Some(c("wrong123"))).unwrap();
    assert!(d.associations().is_empty());
    d.configure_wifi(laptop, Some(c("correct123"))).unwrap();
    assert_eq!(d.associations().len(), 1);
    d.move_node(laptop, [1000., 0.]).unwrap();
    assert!(d.associations().is_empty());
    d.move_node(laptop, [10., 0.]).unwrap();
    assert_eq!(d.associations().len(), 1);
    d.power(ap, false).unwrap();
    assert!(d.associations().is_empty());
    d.power(ap, true).unwrap();
    assert_eq!(d.associations().len(), 1);
    conf.radios[1].enabled = false;
    d.configure_ap(ap, conf).unwrap();
    assert!(d.associations().is_empty());
}
#[test]
fn wifi_vlan_isolation() {
    let mut d = Desktop::new(42).unwrap();
    let ap = d.add(Model::Wep2ac, [0., 0.]).unwrap();
    let a = d.add(Model::Laptop, [10., 0.]).unwrap();
    let b = d.add(Model::Laptop, [15., 0.]).unwrap();
    let mut c = ApConfig::default();
    c.vaps[0].vlan = 10;
    let mut other = c.vaps[0].clone();
    other.index = 1;
    other.ssid = "Other".into();
    other.vlan = 20;
    c.vaps.push(other);
    d.configure_ap(ap, c).unwrap();
    for (id, ssid, ip) in [(a, "NetSim", "10.0.0.1"), (b, "Other", "10.0.0.2")] {
        host(&mut d, id, ip);
        d.configure_wifi(
            id,
            Some(WifiClient {
                ssid: ssid.into(),
                psk: None,
                radio: 2,
            }),
        )
        .unwrap();
    }
    run(&mut d, 40);
    let token = d.ping(a, "10.0.0.2".parse().unwrap()).unwrap();
    run(&mut d, 6);
    assert!(
        d.snapshot()
            .l3
            .nodes
            .iter()
            .find(|n| Some(n.device) == d.engine_id(a))
            .unwrap()
            .probes
            .iter()
            .any(|p| p.token == token && !matches!(p.status, ProbeStatus::Reply { .. }))
    );
}
#[test]
fn ospf_across_cisco_and_eltex() {
    let mut d = Desktop::new(42).unwrap();
    let a = d.add(Model::CiscoRouter, [0., 0.]).unwrap();
    let b = d.add(Model::EltexRouter, [50., 0.]).unwrap();
    let h = d.add(Model::Pc, [100., 0.]).unwrap();
    cli(
        &mut d,
        a,
        &[
            "enable",
            "conf t",
            "int gi0/0",
            "ip address 10.0.0.1 255.255.255.0",
            "no shut",
            "end",
        ],
    );
    cli(
        &mut d,
        b,
        &[
            "configure",
            "interface gi 1/0/1",
            "ip address 10.0.0.2/24",
            "exit",
            "interface gi 1/0/2",
            "ip address 10.1.0.1/24",
            "end",
            "commit",
            "confirm",
        ],
    );
    host(&mut d, h, "10.1.0.2");
    d.connect(ep(a, "GigabitEthernet0/0"), ep(b, "1/0/1"))
        .unwrap();
    d.connect(ep(b, "1/0/2"), ep(h, "eth0")).unwrap();
    d.enable_ospf(a, "1.1.1.1".parse().unwrap()).unwrap();
    d.enable_ospf(b, "2.2.2.2".parse().unwrap()).unwrap();
    run(&mut d, 10);
    let id = d.engine_id(a).unwrap();
    let has_route = |d: &Desktop| {
        d.snapshot()
            .l3
            .nodes
            .iter()
            .find(|n| n.device == id)
            .unwrap()
            .routes
            .iter()
            .any(|r| {
                r.origin == RouteOrigin::Ospf
                    && r.prefix.network() == "10.1.0.0".parse::<std::net::Ipv4Addr>().unwrap()
            })
    };
    assert!(has_route(&d));
    assert!(d.execute(a, "show ip route").unwrap().contains("O "));
    d.disconnect(0).unwrap();
    run(&mut d, 10);
    assert!(!has_route(&d));
}
#[test]
fn version_two_migration() {
    let p = Project::decode(include_bytes!("../../../examples/two-pcs.netsim")).unwrap();
    assert_eq!(p.schema_version, 3);
    assert!(p.wireless.aps.is_empty());
}

#[test]
fn scan_follows_band_power_distance_and_hidden_ssids() {
    let mut d = Desktop::new(42).unwrap();
    let laptop = d.add(Model::Laptop, [0., 0.]).unwrap();
    let near = d.add(Model::Wep2ac, [10., 0.]).unwrap();
    let far = d.add(Model::Wep2ac, [50., 0.]).unwrap();
    let mut ap = ApConfig::default();
    ap.vaps[0].ssid = "Visible".into();
    ap.vaps[0].psk = Some("password1".into());
    let mut hidden = ap.vaps[0].clone();
    hidden.index = 1;
    hidden.ssid = "Hidden".into();
    hidden.broadcast = false;
    ap.vaps.push(hidden);
    d.configure_ap(near, ap.clone()).unwrap();
    let seen = d.wifi_scan(laptop, 2);
    assert_eq!(seen.iter().map(|n| n.ap).collect::<Vec<_>>(), [near, far]);
    assert_eq!(seen[0].ssid, "Visible");
    assert!(seen[0].secured && seen[0].signal_dbm > seen[1].signal_dbm);
    assert!(d.wifi_scan(laptop, 1).is_empty());
    d.configure_wifi(
        laptop,
        Some(WifiClient {
            ssid: "Hidden".into(),
            psk: Some("password1".into()),
            radio: 2,
        }),
    )
    .unwrap();
    assert_eq!(d.associations()[0].ap, near);
    ap.radios[1].enabled = false;
    d.configure_ap(near, ap).unwrap();
    assert_eq!(d.wifi_scan(laptop, 2).len(), 1);
    d.move_node(far, [1000., 0.]).unwrap();
    assert!(d.wifi_scan(laptop, 2).is_empty());
    d.move_node(far, [50., 0.]).unwrap();
    d.power(far, false).unwrap();
    assert!(d.wifi_scan(laptop, 2).is_empty());
}
