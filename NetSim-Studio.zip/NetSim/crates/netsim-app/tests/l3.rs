use netsim_app::create_engine;
use netsim_core::{DeviceId, EngineCommand, EngineError, MacAddress, MediaKind, PortId};
use netsim_engine::{
    CommandResult, Engine, EngineLimits, InterfaceConfig, InterfaceKey, Ipv4Prefix, PortMode,
    ProbeStatus, Route, RouteOrigin,
};
use std::net::Ipv4Addr;

const SEC: u64 = 1_000_000_000;
fn ip(a: u8, b: u8, c: u8) -> Ipv4Addr {
    Ipv4Addr::new(10, a, b, c)
}
fn engine() -> Engine {
    create_engine(42, EngineLimits::default()).unwrap()
}
fn cfg(port: PortId, vlan: Option<u16>, address: Ipv4Addr, mac: u8) -> InterfaceConfig {
    InterfaceConfig {
        key: InterfaceKey { port, vlan },
        address,
        prefix_len: 24,
        mac: MacAddress([2, 0, 0, 0, 0, mac]),
    }
}
fn host(
    e: &mut Engine,
    address: Ipv4Addr,
    gateway: Option<Ipv4Addr>,
    mac: u8,
) -> (DeviceId, PortId) {
    let d = e
        .add_device("generic.host.pc", 1, format!("PC{mac}"))
        .unwrap();
    let p = e.add_port(d, MediaKind::Ethernet).unwrap();
    e.configure_ipv4_host(d, cfg(p, None, address, mac), gateway)
        .unwrap();
    (d, p)
}
fn router(e: &mut Engine, name: &str) -> DeviceId {
    let d = e.add_device("cisco.router.2911", 1, name.into()).unwrap();
    e.configure_router(d).unwrap();
    d
}
fn iface(e: &mut Engine, d: DeviceId, address: Ipv4Addr, mac: u8) -> InterfaceKey {
    let p = e.add_port(d, MediaKind::Ethernet).unwrap();
    let c = cfg(p, None, address, mac);
    e.configure_router_interface(d, c).unwrap();
    c.key
}
fn route(address: Ipv4Addr, len: u8, via: Ipv4Addr, key: InterfaceKey, distance: u8) -> Route {
    Route {
        prefix: Ipv4Prefix::new(address, len).unwrap(),
        interface: key,
        next_hop: Some(via),
        distance,
        metric: 0,
        origin: RouteOrigin::Static,
    }
}
fn cable(e: &mut Engine, a: PortId, b: PortId) -> netsim_core::LinkId {
    match e
        .execute(EngineCommand::ConnectPorts {
            endpoints: [a, b],
            bandwidth_bps: 100_000_000,
            delay_ns: 100,
            loss_ppm: 0,
            queue_limit_bytes: 65536,
        })
        .unwrap()
    {
        CommandResult::LinkAdded(id) => id,
        _ => panic!("link expected"),
    }
}
fn power(e: &mut Engine, ids: &[DeviceId]) {
    for id in ids {
        e.power_on(*id).unwrap();
    }
}
fn run(e: &mut Engine, time: u64) {
    let report = e.run_until(time, 50_000).unwrap();
    assert!(!report.faulted && !report.budget_exhausted, "{report:?}");
}
fn status(e: &mut Engine, source: DeviceId, destination: Ipv4Addr, ttl: u8) -> ProbeStatus {
    let token = e.ping(source, destination, ttl, 5 * SEC).unwrap();
    let until = e.now() + 5 * SEC;
    run(e, until);
    e.probe(source, token).unwrap().status
}

#[test]
fn same_subnet_and_default_gateway_validation() {
    let mut e = engine();
    let (a, pa) = host(&mut e, ip(1, 0, 10), None, 1);
    let (b, pb) = host(&mut e, ip(1, 0, 20), None, 2);
    cable(&mut e, pa, pb);
    power(&mut e, &[a, b]);
    assert!(
        matches!(status(&mut e,a,ip(1,0,20),64),ProbeStatus::Reply{from,..} if from==ip(1,0,20))
    );
    assert_eq!(status(&mut e, a, ip(2, 0, 10), 64), ProbeStatus::NoRoute);
    assert_eq!(
        status(&mut e, a, ip(1, 0, 10), 64),
        ProbeStatus::Reply {
            from: ip(1, 0, 10),
            rtt_ns: 0
        }
    );
    assert_eq!(
        e.ping(a, ip(1, 0, 20), 0, SEC),
        Err(EngineError::InvalidInput)
    );
    let c = e.add_device("generic.host.pc", 1, "bad".into()).unwrap();
    let pc = e.add_port(c, MediaKind::Ethernet).unwrap();
    assert_eq!(
        e.configure_ipv4_host(c, cfg(pc, None, ip(1, 0, 30), 3), Some(ip(2, 0, 1))),
        Err(EngineError::InvalidInput)
    );
}

#[test]
fn connected_routes_and_traceroute() {
    let (ping, hops) = netsim_app::l3_demo().unwrap();
    assert!(matches!(ping.status,ProbeStatus::Reply{rtt_ns,..} if rtt_ns>0));
    assert_eq!(hops.len(), 2);
    assert!(
        matches!(hops[0].status,ProbeStatus::TimeExceeded{from,..} if from==Ipv4Addr::new(192,168,1,1))
    );
    assert!(
        matches!(hops[1].status,ProbeStatus::Reply{from,..} if from==Ipv4Addr::new(192,168,2,10))
    );
    assert_eq!(netsim_app::l3_demo().unwrap(), (ping, hops));
}

#[test]
fn two_routers_static_routes_and_ttl() {
    let mut e = engine();
    let (a, pa) = host(&mut e, ip(1, 0, 10), Some(ip(1, 0, 1)), 1);
    let (b, pb) = host(&mut e, ip(3, 0, 10), Some(ip(3, 0, 1)), 2);
    let r = router(&mut e, "R1");
    let s = router(&mut e, "R2");
    let ra = iface(&mut e, r, ip(1, 0, 1), 3);
    let rs = iface(&mut e, r, ip(2, 0, 1), 4);
    let sr = iface(&mut e, s, ip(2, 0, 2), 5);
    let sb = iface(&mut e, s, ip(3, 0, 1), 6);
    e.add_static_route(r, route(ip(3, 0, 0), 24, ip(2, 0, 2), rs, 1))
        .unwrap();
    e.add_static_route(s, route(Ipv4Addr::UNSPECIFIED, 0, ip(2, 0, 1), sr, 1))
        .unwrap();
    cable(&mut e, pa, ra.port);
    cable(&mut e, rs.port, sr.port);
    cable(&mut e, sb.port, pb);
    power(&mut e, &[a, b, r, s]);
    let hops = e.traceroute(a, ip(3, 0, 10), 8, 5 * SEC, 20_000).unwrap();
    assert_eq!(hops.len(), 3);
    assert!(matches!(hops[0].status,ProbeStatus::TimeExceeded{from,..} if from==ip(1,0,1)));
    assert!(matches!(hops[1].status,ProbeStatus::TimeExceeded{from,..} if from==ip(2,0,2)));
    assert!(matches!(hops[2].status,ProbeStatus::Reply{from,..} if from==ip(3,0,10)));
    assert_eq!(
        e.route_lookup(r, ip(3, 0, 10)).unwrap().next_hop,
        Some(ip(2, 0, 2))
    );
    assert_eq!(e.route_lookup(s, ip(1, 0, 10)).unwrap().prefix.length(), 0);
}

#[test]
fn unreachable_and_arp_timeout() {
    let mut e = engine();
    let (a, pa) = host(&mut e, ip(1, 0, 10), Some(ip(1, 0, 1)), 1);
    let r = router(&mut e, "R");
    let ra = iface(&mut e, r, ip(1, 0, 1), 2);
    cable(&mut e, pa, ra.port);
    power(&mut e, &[a, r]);
    assert!(matches!(
        status(&mut e, a, ip(9, 0, 10), 64),
        ProbeStatus::Unreachable { code: 0, .. }
    ));
    assert_eq!(status(&mut e, a, ip(1, 0, 99), 64), ProbeStatus::Timeout);
    assert!(e.trace().entries.iter().any(|t| matches!(
        &t.action,
        netsim_engine::TraceAction::IpDrop {
            reason: "arp-timeout"
        }
    )));
    assert_eq!(
        e.snapshot()
            .l3
            .nodes
            .iter()
            .find(|n| n.device == a)
            .unwrap()
            .pending_packets,
        0
    );
}

#[test]
fn router_on_a_stick_between_vlans() {
    let mut e = engine();
    let (a, pa) = host(&mut e, ip(10, 0, 10), Some(ip(10, 0, 1)), 1);
    let (b, pb) = host(&mut e, ip(20, 0, 10), Some(ip(20, 0, 1)), 2);
    let r = router(&mut e, "R");
    let rp = e.add_port(r, MediaKind::Ethernet).unwrap();
    e.configure_router_interface(r, cfg(rp, Some(10), ip(10, 0, 1), 3))
        .unwrap();
    e.configure_router_interface(r, cfg(rp, Some(20), ip(20, 0, 1), 3))
        .unwrap();
    let s = e
        .add_device("eltex.switch.mes2428", 1, "SW".into())
        .unwrap();
    e.configure_switch(s, 32768, MacAddress([2, 0, 0, 0, 0, 4]))
        .unwrap();
    let mut ports = Vec::new();
    for mode in [
        PortMode::Access(10),
        PortMode::Access(20),
        PortMode::Trunk {
            native: None,
            allowed: [10, 20].into_iter().collect(),
        },
    ] {
        let p = e.add_port(s, MediaKind::Ethernet).unwrap();
        e.configure_switch_port(s, p, mode).unwrap();
        ports.push(p);
    }
    cable(&mut e, pa, ports[0]);
    cable(&mut e, pb, ports[1]);
    cable(&mut e, rp, ports[2]);
    power(&mut e, &[a, b, r, s]);
    run(&mut e, 40 * SEC);
    assert!(matches!(
        status(&mut e, a, ip(20, 0, 10), 64),
        ProbeStatus::Reply { .. }
    ));
    let snap = e.snapshot();
    let router = snap.l3.nodes.iter().find(|n| n.device == r).unwrap();
    assert_eq!(router.interfaces.len(), 2);
    assert!(router.interfaces.iter().all(|i| !i.arp.is_empty()));
    assert!(router.forwarded >= 2);
}

#[test]
fn route_selection_and_link_failure() {
    let mut e = engine();
    let r = router(&mut e, "R");
    let x = iface(&mut e, r, ip(1, 0, 1), 1);
    let y = iface(&mut e, r, ip(2, 0, 1), 2);
    let (a, pa) = host(&mut e, ip(1, 0, 2), None, 3);
    let (b, pb) = host(&mut e, ip(2, 0, 2), None, 4);
    let general = route(ip(9, 0, 0), 16, ip(1, 0, 2), x, 1);
    let specific = route(ip(9, 1, 0), 24, ip(2, 0, 2), y, 100);
    e.add_static_route(r, general).unwrap();
    e.add_static_route(r, specific).unwrap();
    assert_eq!(
        e.add_static_route(r, specific),
        Err(EngineError::InvalidInput)
    );
    assert_eq!(
        e.add_static_route(r, route(ip(8, 0, 0), 16, ip(99, 0, 2), y, 1)),
        Err(EngineError::InvalidInput)
    );
    cable(&mut e, x.port, pa);
    let l = cable(&mut e, y.port, pb);
    power(&mut e, &[r, a, b]);
    assert_eq!(e.route_lookup(r, ip(9, 1, 3)), Some(specific));
    e.disconnect(l).unwrap();
    assert_eq!(e.route_lookup(r, ip(9, 1, 3)), Some(general));
    e.power_off(r).unwrap();
    e.remove_static_route(r, general).unwrap();
    e.power_on(r).unwrap();
    assert_eq!(e.route_lookup(r, ip(9, 1, 3)), None);
}

#[test]
fn lifecycle_resets_arp_probes_not_interfaces() {
    let mut e = engine();
    let (a, pa) = host(&mut e, ip(1, 0, 10), None, 1);
    let (b, pb) = host(&mut e, ip(1, 0, 20), None, 2);
    cable(&mut e, pa, pb);
    power(&mut e, &[a, b]);
    let token = e.ping(a, ip(1, 0, 20), 64, SEC).unwrap();
    run(&mut e, SEC);
    assert!(matches!(
        e.probe(a, token).unwrap().status,
        ProbeStatus::Reply { .. }
    ));
    e.execute(EngineCommand::Reboot(a)).unwrap();
    assert!(e.probe(a, token).is_none());
    assert_eq!(
        e.interface_arp_lookup(
            a,
            InterfaceKey {
                port: pa,
                vlan: None
            },
            ip(1, 0, 20)
        ),
        None
    );
    assert!(matches!(
        status(&mut e, a, ip(1, 0, 20), 64),
        ProbeStatus::Reply { .. }
    ));
    e.remove_device(a).unwrap();
    assert!(!e.snapshot().l3.nodes.iter().any(|n| n.device == a));
}

#[test]
fn worker_ping_and_snapshot() {
    use netsim_engine::{Worker, WorkerRequest, WorkerResponse};
    let mut e = engine();
    let (a, pa) = host(&mut e, ip(1, 0, 10), None, 1);
    let (b, pb) = host(&mut e, ip(1, 0, 20), None, 2);
    cable(&mut e, pa, pb);
    power(&mut e, &[a, b]);
    let w = Worker::spawn(e, 8).unwrap();
    let h = w.handle();
    let token = match h
        .request(WorkerRequest::Ping {
            device: a,
            destination: ip(1, 0, 20),
            ttl: 64,
            timeout: SEC,
        })
        .unwrap()
    {
        WorkerResponse::ProbeStarted(token) => token,
        _ => panic!("probe expected"),
    };
    h.request(WorkerRequest::RunUntil {
        deadline: SEC,
        budget: 1000,
    })
    .unwrap();
    assert!(
        matches!(h.request(WorkerRequest::Probe{device:a,token}).unwrap(),
        WorkerResponse::Probe(Some(p)) if matches!(p.status,ProbeStatus::Reply{..}))
    );
    assert_eq!(h.latest().unwrap().l3.nodes.len(), 2);
    w.join().unwrap();
}
