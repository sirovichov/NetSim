use netsim_app::{CiscoModel, CiscoSessionId, EltexModel, MixedLab};
use netsim_core::DeviceId;
const S: CiscoSessionId = CiscoSessionId(1);
fn cmds(l: &mut MixedLab, id: DeviceId, commands: &[&str]) {
    for c in commands {
        let out = l.execute(id, S, c).unwrap();
        assert!(!out.starts_with('%'), "{c}: {out}");
    }
}
fn port(l: &MixedLab, id: DeviceId, n: &str) -> netsim_core::PortId {
    l.port(id, n).unwrap()
}
#[test]
fn esr_candidate_commit_confirm_and_restore() {
    let mut l = MixedLab::new(42).unwrap();
    let r = l.add_eltex(EltexModel::Esr100, "ESR").unwrap();
    cmds(
        &mut l,
        r,
        &[
            "configure",
            "interface gi 1/0/1",
            "ip address 10.0.0.1/24",
            "end",
        ],
    );
    assert!(
        l.execute(r, S, "show candidate-config")
            .unwrap()
            .contains("10.0.0.1/24")
    );
    assert!(
        !l.execute(r, S, "show running-config")
            .unwrap()
            .contains("10.0.0.1/24")
    );
    cmds(&mut l, r, &["commit"]);
    assert!(
        l.execute(r, S, "show running-config")
            .unwrap()
            .contains("10.0.0.1/24")
    );
    assert!(
        !l.execute(r, S, "show startup-config")
            .unwrap()
            .contains("10.0.0.1/24")
    );
    cmds(&mut l, r, &["restore"]);
    assert!(
        !l.execute(r, S, "show running-config")
            .unwrap()
            .contains("10.0.0.1/24")
    );
    cmds(
        &mut l,
        r,
        &[
            "configure",
            "interface gi 1/0/1",
            "ip address 10.0.0.2/24",
            "end",
            "commit",
            "confirm",
            "reboot",
        ],
    );
    assert!(
        l.execute(r, S, "show running-config")
            .unwrap()
            .contains("10.0.0.2/24")
    );
}
#[test]
fn esr_virtual_timeout() {
    let mut l = MixedLab::new(42).unwrap();
    let r = l.add_eltex(EltexModel::Esr100, "ESR").unwrap();
    cmds(
        &mut l,
        r,
        &[
            "configure",
            "hostname NEW",
            "end",
            "commit confirm-timeout 120",
        ],
    );
    assert_eq!(l.prompt(r, S).unwrap(), "NEW#");
    l.run_for(120_000_000_000).unwrap();
    assert_eq!(l.prompt(r, S).unwrap(), "ESR#");
    assert!(l.execute(r, S, "confirm").unwrap().starts_with('%'));
}
#[test]
fn mes_live_save_and_reload() {
    let mut l = MixedLab::new(1).unwrap();
    let m = l.add_eltex(EltexModel::Mes2428, "MES").unwrap();
    assert!(l.port(m, "gi1/0/28").is_some());
    assert!(l.port(m, "gi1/0/29").is_none());
    cmds(
        &mut l,
        m,
        &[
            "enable",
            "configure terminal",
            "vlan 10",
            "name USERS",
            "exit",
            "interface gi 1/0/1",
            "switchport mode access",
            "switchport access vlan 10",
            "end",
            "write startup-config",
        ],
    );
    assert!(l.execute(m, S, "show vlan").unwrap().contains("gi1/0/1(U)"));
    cmds(
        &mut l,
        m,
        &[
            "configure terminal",
            "hostname NEW",
            "end",
            "reload",
            "enable",
        ],
    );
    assert_eq!(l.prompt(m, S).unwrap(), "MES#");
    assert!(
        l.execute(m, S, "show startup-config")
            .unwrap()
            .contains("USERS")
    );
}
#[test]
fn mixed_demo() {
    assert!(
        netsim_app::eltex_demo()
            .unwrap()
            .contains("Cisco/Eltex simulation successful")
    );
}
#[test]
fn mixed_trunk_with_esr_subinterface() {
    let mut l = MixedLab::new(2).unwrap();
    let r = l.add_eltex(EltexModel::Esr100, "ESR").unwrap();
    let m = l.add_eltex(EltexModel::Mes2428, "MES").unwrap();
    let s = l.add_cisco(CiscoModel::Catalyst2960, "SW").unwrap();
    let c = l.add_cisco(CiscoModel::Isr2911, "R").unwrap();
    for (a, b) in [
        (port(&l, r, "gi1/0/1"), port(&l, m, "gi1/0/1")),
        (port(&l, m, "gi1/0/2"), port(&l, s, "gi0/1")),
        (port(&l, s, "fa0/1"), port(&l, c, "gi0/0")),
    ] {
        l.connect(a, b).unwrap();
    }
    cmds(
        &mut l,
        r,
        &[
            "configure",
            "interface gi 1/0/1.10",
            "ip address 10.0.0.1/24",
            "end",
            "commit",
            "confirm",
        ],
    );
    cmds(
        &mut l,
        m,
        &[
            "enable",
            "configure terminal",
            "vlan 10",
            "exit",
            "interface gi 1/0/1",
            "switchport mode trunk",
            "switchport trunk allowed vlan 10",
            "exit",
            "interface gi 1/0/2",
            "switchport mode trunk",
            "switchport trunk allowed vlan 10",
            "end",
        ],
    );
    cmds(
        &mut l,
        s,
        &[
            "enable",
            "conf t",
            "vlan 10",
            "exit",
            "int gi0/1",
            "switchport mode trunk",
            "switchport trunk allowed vlan 10",
            "exit",
            "int fa0/1",
            "switchport access vlan 10",
            "end",
        ],
    );
    cmds(
        &mut l,
        c,
        &[
            "enable",
            "conf t",
            "int gi0/0",
            "ip address 10.0.0.2 255.255.255.0",
            "no shut",
            "end",
        ],
    );
    l.run_for(40_000_000_000).unwrap();
    assert!(
        l.execute(c, S, "ping 10.0.0.1")
            .unwrap()
            .contains("100 percent")
    );
}
#[test]
fn static_routes_across_vendors() {
    let mut l = MixedLab::new(3).unwrap();
    let c = l.add_cisco(CiscoModel::Isr2911, "R").unwrap();
    let e = l.add_eltex(EltexModel::Esr100, "ESR").unwrap();
    let dest = l.add_cisco(CiscoModel::Isr2911, "D").unwrap();
    for (a, b) in [
        (port(&l, c, "gi0/0"), port(&l, e, "gi1/0/1")),
        (port(&l, e, "gi1/0/2"), port(&l, dest, "gi0/0")),
    ] {
        l.connect(a, b).unwrap();
    }
    cmds(
        &mut l,
        c,
        &[
            "enable",
            "conf t",
            "int gi0/0",
            "ip address 10.0.0.1 255.255.255.0",
            "no shut",
            "exit",
            "ip route 10.1.0.0 255.255.255.0 10.0.0.2",
            "end",
        ],
    );
    cmds(
        &mut l,
        e,
        &[
            "configure",
            "interface gi 1/0/1",
            "ip address 10.0.0.2/24",
            "exit",
            "interface gi 1/0/2",
            "ip address 10.1.0.1/24",
            "exit",
            "ip route 192.168.1.0/24 10.0.0.1",
            "end",
            "commit",
            "confirm",
        ],
    );
    cmds(
        &mut l,
        dest,
        &[
            "enable",
            "conf t",
            "int gi0/0",
            "ip address 10.1.0.2 255.255.255.0",
            "no shut",
            "exit",
            "ip route 0.0.0.0 0.0.0.0 10.1.0.1",
            "end",
        ],
    );
    l.run_for(1_000_000_000).unwrap();
    assert!(
        l.execute(c, S, "ping 10.1.0.2")
            .unwrap()
            .contains("100 percent")
    );
    assert!(
        l.execute(e, S, "show ip route")
            .unwrap()
            .contains("192.168.1.0/24")
    );
}
#[test]
fn invalid_commands_do_not_mutate() {
    let mut l = MixedLab::new(4).unwrap();
    let r = l.add_eltex(EltexModel::Esr100, "ESR").unwrap();
    cmds(&mut l, r, &["configure", "interface gi 1/0/1"]);
    assert!(
        l.execute(r, S, "ip address 10.0.0.1 255.255.255.0")
            .unwrap()
            .starts_with('%')
    );
    assert!(
        l.execute(r, S, "ip address 10.0.0.1/33")
            .unwrap()
            .starts_with('%')
    );
    cmds(&mut l, r, &["end"]);
    assert!(
        !l.execute(r, S, "show candidate-config")
            .unwrap()
            .contains("10.0.0.1")
    );
}

#[test]
fn advance_preserves_remainder_after_esr_rollback() {
    let mut lab = MixedLab::new(42).unwrap();
    let router = lab.add_eltex(EltexModel::Esr100, "ESR").unwrap();
    cmds(
        &mut lab,
        router,
        &[
            "configure",
            "hostname TEMP",
            "end",
            "commit confirm-timeout 120",
        ],
    );
    lab.advance(110_000_000_000, 4096).unwrap();
    assert_eq!(lab.prompt(router, S).unwrap(), "TEMP#");
    lab.advance(40_000_000_000, 4096).unwrap();
    assert_eq!(lab.snapshot().now, 150_000_000_000);
    assert_eq!(lab.prompt(router, S).unwrap(), "ESR#");
}
