use netsim_app::{CiscoLab, CiscoModel, CiscoSessionId};
use netsim_cisco::ios::CiscoDevice;
use netsim_core::{DeviceId, EngineCommand, MacAddress, MediaKind, PortId, SessionId};
use netsim_engine::{EngineLimits, InterfaceConfig, InterfaceKey, ProbeStatus};
use std::net::Ipv4Addr;

const S: CiscoSessionId = CiscoSessionId(1);
fn cmd(lab: &mut CiscoLab, id: DeviceId, line: &str) -> String {
    lab.execute(id, S, line).unwrap()
}
fn commands(lab: &mut CiscoLab, id: DeviceId, lines: &[&str]) {
    for line in lines {
        let output = cmd(lab, id, line);
        assert!(!output.starts_with('%'), "{line}: {output}");
    }
}

#[test]
fn modes_abbreviations_help_completion_and_isolated_sessions() {
    let mut lab = CiscoLab::new(42).unwrap();
    let r = lab.add(CiscoModel::Isr2911, "Router").unwrap();
    assert_eq!(lab.prompt(r, S).unwrap(), "Router>");
    assert!(cmd(&mut lab, r, "conf t").starts_with('%'));
    assert_eq!(cmd(&mut lab, r, "en"), "");
    assert_eq!(lab.prompt(r, S).unwrap(), "Router#");
    assert_eq!(cmd(&mut lab, r, "conf\t"), "configure ");
    assert_eq!(cmd(&mut lab, r, "conf ?"), "terminal");
    assert_eq!(cmd(&mut lab, r, "show i"), "% Ambiguous command");
    assert_eq!(cmd(&mut lab, r, "show ip"), "% Incomplete command.");
    commands(&mut lab, r, &["conf t", "hostname R1", "int gi 0/0"]);
    assert_eq!(lab.prompt(r, S).unwrap(), "R1(config-if)#");
    assert_eq!(lab.prompt(r, CiscoSessionId(2)).unwrap(), "R1>");
    assert_eq!(lab.snapshot().devices[0].hostname, "R1");
    assert!(cmd(&mut lab, r, "switchport mode trunk").starts_with('%'));
    commands(&mut lab, r, &["exit", "end"]);
    assert_eq!(lab.prompt(r, S).unwrap(), "R1#");
}

#[test]
fn startup_config_reload_erase_and_invalid_input() {
    let mut lab = CiscoLab::new(42).unwrap();
    let r = lab.add(CiscoModel::Isr2911, "Router").unwrap();
    commands(
        &mut lab,
        r,
        &[
            "en",
            "conf t",
            "hostname R1",
            "int g0/0",
            "ip address 10.0.0.1 255.255.255.0",
            "no shut",
            "end",
            "copy run start",
        ],
    );
    let saved = cmd(&mut lab, r, "show start");
    assert!(saved.contains("hostname R1"));
    commands(&mut lab, r, &["conf t", "hostname Other", "int gi0/0"]);
    assert!(cmd(&mut lab, r, "ip address 10.1.0.1 255.0.255.0").starts_with('%'));
    assert!(cmd(&mut lab, r, "do show running-config").contains("10.0.0.1"));
    commands(&mut lab, r, &["end", "reload"]);
    assert_eq!(lab.prompt(r, S).unwrap(), "R1>");
    commands(&mut lab, r, &["en"]);
    assert_eq!(cmd(&mut lab, r, "show startup-config"), saved);
    assert!(cmd(&mut lab, r, "show running-config").contains("hostname R1"));
    commands(&mut lab, r, &["erase startup-config", "reload", "en"]);
    assert_eq!(lab.prompt(r, S).unwrap(), "Router#");
    assert_eq!(
        cmd(&mut lab, r, "show startup-config"),
        "startup-config is not present"
    );
}

#[test]
fn switch_vlan_trunk_and_mac_tables_are_live() {
    let mut lab = CiscoLab::new(42).unwrap();
    let sw = lab.add(CiscoModel::Catalyst2960, "SW1").unwrap();
    let r = lab.add(CiscoModel::Isr2911, "R1").unwrap();
    let swp = lab.port(sw, "fa0/1").unwrap();
    let rp = lab.port(r, "gi0/0").unwrap();
    lab.connect(swp, rp).unwrap();
    commands(
        &mut lab,
        sw,
        &[
            "en",
            "conf t",
            "vlan 10",
            "name USERS",
            "exit",
            "int fa0/1",
            "switchport mode trunk",
            "switchport trunk allowed vlan 10,20-22",
            "switchport trunk native vlan 10",
            "end",
        ],
    );
    assert!(cmd(&mut lab, sw, "show vlan brief").contains("USERS"));
    assert!(cmd(&mut lab, sw, "show interfaces trunk").contains("10,20-22"));
    assert!(
        cmd(&mut lab, sw, "show interfaces fa0/1 switchport")
            .contains("Administrative Mode: trunk")
    );
    commands(
        &mut lab,
        sw,
        &[
            "conf t",
            "int fa0/1",
            "switchport trunk allowed vlan remove 21",
            "shutdown",
            "end",
        ],
    );
    assert!(cmd(&mut lab, sw, "show interfaces trunk").contains("10,20,22"));
    assert!(cmd(&mut lab, sw, "show ip interface brief").contains("administratively down"));
    assert!(cmd(&mut lab, sw, "show spanning-tree").contains("Common spanning tree"));
    assert!(cmd(&mut lab, sw, "show mac address-table").contains("Mac Address"));
}

#[test]
fn cli_configures_real_ethernet_and_icmp() {
    let output = netsim_app::cisco_demo().unwrap();
    assert!(output.contains("Success rate is 100 percent (5/5)"));
    assert!(output.contains("DYNAMIC"));
}

fn address(s: &str) -> Ipv4Addr {
    s.parse().unwrap()
}
fn host(
    engine: &mut netsim_engine::Engine,
    name: &str,
    ip: &str,
    gw: &str,
    octet: u8,
) -> (DeviceId, PortId) {
    let id = engine
        .add_device("generic.host.pc", 1, name.into())
        .unwrap();
    let port = engine.add_port(id, MediaKind::Ethernet).unwrap();
    engine
        .configure_ipv4_host(
            id,
            InterfaceConfig {
                key: InterfaceKey { port, vlan: None },
                address: address(ip),
                prefix_len: 24,
                mac: MacAddress([2, 0x11, 0, 0, 0, octet]),
            },
            Some(address(gw)),
        )
        .unwrap();
    engine.power_on(id).unwrap();
    (id, port)
}
fn connect(engine: &mut netsim_engine::Engine, a: PortId, b: PortId) {
    engine
        .execute(EngineCommand::ConnectPorts {
            endpoints: [a, b],
            bandwidth_bps: 100_000_000,
            delay_ns: 1000,
            loss_ppm: 0,
            queue_limit_bytes: 65536,
        })
        .unwrap();
}
fn cli(d: &mut CiscoDevice, e: &mut netsim_engine::Engine, commands: &[&str]) {
    for line in commands {
        let out = d.execute(e, SessionId(1), line);
        assert!(!out.starts_with('%'), "{line}: {out}");
    }
}

#[test]
fn router_on_a_stick_vlan_isolation_and_shutdown() {
    let mut e = netsim_app::create_engine(42, EngineLimits::default()).unwrap();
    let mut r = CiscoDevice::create(&mut e, CiscoModel::Isr2911, "R1").unwrap();
    let mut sw = CiscoDevice::create(&mut e, CiscoModel::Catalyst2960, "SW1").unwrap();
    let (a, pa) = host(&mut e, "PC1", "10.10.0.10", "10.10.0.1", 1);
    let (_, pb) = host(&mut e, "PC2", "10.20.0.10", "10.20.0.1", 2);
    connect(&mut e, pa, sw.port("fa0/1").unwrap());
    connect(&mut e, pb, sw.port("fa0/2").unwrap());
    connect(&mut e, r.port("gi0/0").unwrap(), sw.port("gi0/1").unwrap());
    cli(
        &mut sw,
        &mut e,
        &[
            "en",
            "conf t",
            "vlan 10",
            "exit",
            "vlan 20",
            "exit",
            "int fa0/1",
            "switchport access vlan 10",
            "exit",
            "int fa0/2",
            "switchport access vlan 20",
            "exit",
            "int gi0/1",
            "switchport mode trunk",
            "switchport trunk allowed vlan 10,20",
            "end",
        ],
    );
    cli(
        &mut r,
        &mut e,
        &[
            "en",
            "conf t",
            "int gi0/0",
            "no shut",
            "exit",
            "int gi0/0.10",
            "encapsulation dot1q 10",
            "ip address 10.10.0.1 255.255.255.0",
            "exit",
            "int gi0/0.20",
            "encapsulation dot1q 20",
            "ip address 10.20.0.1 255.255.255.0",
            "end",
        ],
    );
    e.run_until(40_000_000_000, 10000).unwrap();
    let token = e.ping(a, address("10.20.0.10"), 64, 5_000_000_000).unwrap();
    e.run_until(45_000_000_000, 10000).unwrap();
    assert!(matches!(
        e.probe(a, token).unwrap().status,
        ProbeStatus::Reply { .. }
    ));
    cli(&mut r, &mut e, &["conf t", "int gi0/0", "shutdown", "end"]);
    let token = e.ping(a, address("10.20.0.10"), 64, 5_000_000_000).unwrap();
    e.run_until(50_000_000_000, 10000).unwrap();
    assert!(!matches!(
        e.probe(a, token).unwrap().status,
        ProbeStatus::Reply { .. }
    ));
}

#[test]
fn static_route_configuration_and_live_rib() {
    let mut lab = CiscoLab::new(42).unwrap();
    let a = lab.add(CiscoModel::Isr2911, "R1").unwrap();
    let b = lab.add(CiscoModel::Isr2911, "R2").unwrap();
    let pa = lab.port(a, "gi0/0").unwrap();
    let pb = lab.port(b, "gi0/0").unwrap();
    lab.connect(pa, pb).unwrap();
    commands(
        &mut lab,
        a,
        &[
            "en",
            "conf t",
            "ip route 0.0.0.0 0.0.0.0 10.0.0.2",
            "int gi0/0",
            "ip address 10.0.0.1 255.255.255.0",
            "no shut",
            "end",
        ],
    );
    commands(
        &mut lab,
        b,
        &[
            "en",
            "conf t",
            "int gi0/0",
            "ip address 10.0.0.2 255.255.255.0",
            "no shut",
            "end",
        ],
    );
    assert!(cmd(&mut lab, a, "show ip route").contains("S*   0.0.0.0/0 [1/0] via 10.0.0.2"));
    assert!(cmd(&mut lab, a, "ping 10.0.0.2").contains("100 percent"));
    commands(
        &mut lab,
        a,
        &["conf t", "no ip route 0.0.0.0 0.0.0.0 10.0.0.2", "end"],
    );
    assert!(cmd(&mut lab, a, "show ip route").contains("Gateway of last resort is not set"));
    assert!(!cmd(&mut lab, a, "show ip route").contains("S*"));
}

#[test]
fn invalid_vlan_and_duplicate_subinterface_are_atomic() {
    let mut lab = CiscoLab::new(42).unwrap();
    let r = lab.add(CiscoModel::Isr2911, "R1").unwrap();
    commands(
        &mut lab,
        r,
        &[
            "en",
            "conf t",
            "int gi0/0.10",
            "encapsulation dot1q 10",
            "exit",
            "int gi0/0.20",
        ],
    );
    assert!(cmd(&mut lab, r, "encapsulation dot1q 10").starts_with('%'));
    assert!(cmd(&mut lab, r, "ip address 10.20.0.1 255.255.255.0").starts_with('%'));
    let sw = lab.add(CiscoModel::Catalyst2960, "SW1").unwrap();
    commands(&mut lab, sw, &["en", "conf t", "int fa0/1"]);
    assert!(cmd(&mut lab, sw, "switchport access vlan 4095").starts_with('%'));
    assert!(cmd(&mut lab, sw, "switchport trunk allowed vlan 20-10").starts_with('%'));
}
