//! Application-level owner of the simulation and IOS console state.
use netsim_cisco::ios::{CiscoDevice, Model};
use netsim_core::{DeviceId, EngineCommand, EngineError, PortId, SessionId};
use netsim_engine::{Engine, EngineLimits, SimulationSnapshot};
use std::collections::BTreeMap;

pub struct CiscoLab {
    engine: Engine,
    devices: BTreeMap<DeviceId, CiscoDevice>,
}

impl CiscoLab {
    pub fn new(seed: u64) -> Result<Self, EngineError> {
        Ok(Self {
            engine: crate::create_engine(seed, EngineLimits::default())?,
            devices: BTreeMap::new(),
        })
    }
    pub fn add(&mut self, model: Model, name: &str) -> Result<DeviceId, EngineError> {
        let dev = CiscoDevice::create(&mut self.engine, model, name)?;
        let id = dev.id();
        self.devices.insert(id, dev);
        Ok(id)
    }
    pub fn port(&self, device: DeviceId, name: &str) -> Option<PortId> {
        self.devices.get(&device)?.port(name)
    }
    pub fn connect(&mut self, a: PortId, b: PortId) -> Result<(), EngineError> {
        self.engine.execute(EngineCommand::ConnectPorts {
            endpoints: [a, b],
            bandwidth_bps: 100_000_000,
            delay_ns: 1000,
            loss_ppm: 0,
            queue_limit_bytes: 65536,
        })?;
        Ok(())
    }
    pub fn execute(
        &mut self,
        id: DeviceId,
        session: SessionId,
        command: &str,
    ) -> Result<String, EngineError> {
        Ok(self
            .devices
            .get_mut(&id)
            .ok_or(EngineError::UnknownDevice)?
            .execute(&mut self.engine, session, command))
    }
    pub fn prompt(&self, id: DeviceId, session: SessionId) -> Result<String, EngineError> {
        Ok(self
            .devices
            .get(&id)
            .ok_or(EngineError::UnknownDevice)?
            .prompt(session))
    }
    pub fn snapshot(&self) -> SimulationSnapshot {
        self.engine.snapshot()
    }
    pub fn run_for(&mut self, ns: u64) -> Result<(), EngineError> {
        let deadline = self
            .engine
            .now()
            .checked_add(ns)
            .ok_or(EngineError::TimeOverflow)?;
        let report = self.engine.run_until(deadline, 100_000)?;
        if report.faulted || report.budget_exhausted {
            return Err(EngineError::DeviceFault);
        }
        Ok(())
    }
    pub fn remove(&mut self, id: DeviceId) -> Result<(), EngineError> {
        self.engine.remove_device(id)?;
        self.devices.remove(&id);
        Ok(())
    }
}

/// End-to-end demo: build two routers and one switch, configure them exclusively via IOS commands.
pub fn cisco_demo() -> Result<String, EngineError> {
    let mut lab = CiscoLab::new(42)?;
    let a = lab.add(Model::Isr2911, "R1")?;
    let b = lab.add(Model::Isr2911, "R2")?;
    let sw = lab.add(Model::Catalyst2960, "SW1")?;
    let port = |lab: &CiscoLab, id, name| lab.port(id, name).ok_or(EngineError::UnknownPort);
    let a_port = port(&lab, a, "Gi0/0")?;
    let b_port = port(&lab, b, "Gi0/0")?;
    let s1 = port(&lab, sw, "Fa0/1")?;
    let s2 = port(&lab, sw, "Fa0/2")?;
    lab.connect(a_port, s1)?;
    lab.connect(b_port, s2)?;
    let session = SessionId(1);
    for (id, commands) in [
        (
            a,
            vec![
                "enable",
                "conf t",
                "int gi0/0",
                "ip address 10.10.10.1 255.255.255.0",
                "no shut",
                "end",
            ],
        ),
        (
            b,
            vec![
                "enable",
                "conf t",
                "int gi0/0",
                "ip address 10.10.10.2 255.255.255.0",
                "no shut",
                "end",
            ],
        ),
        (
            sw,
            vec![
                "enable",
                "conf t",
                "vlan 10",
                "name LAB",
                "exit",
                "int fa0/1",
                "switchport access vlan 10",
                "exit",
                "int fa0/2",
                "switchport access vlan 10",
                "end",
            ],
        ),
    ] {
        for cmd in commands {
            if lab.execute(id, session, cmd)?.starts_with('%') {
                return Err(EngineError::InvalidInput);
            }
        }
    }
    lab.run_for(40_000_000_000)?;
    let ping = lab.execute(a, session, "ping 10.10.10.2")?;
    if !ping.contains("100 percent") {
        return Err(EngineError::DeviceFault);
    }
    Ok(format!(
        "{ping}\n{}\nCisco IOS simulation successful",
        lab.execute(sw, session, "show mac address-table")?
    ))
}
