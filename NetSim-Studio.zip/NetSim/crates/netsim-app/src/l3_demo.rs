//! A routed two-subnet topology, with real simulated ping and ICMP traceroute.
use crate::create_engine;
use netsim_core::{EngineCommand, EngineError, MacAddress, MediaKind};
use netsim_engine::{EngineLimits, InterfaceConfig, InterfaceKey, Probe, ProbeStatus};
use std::net::Ipv4Addr;

pub fn l3_demo() -> Result<(Probe, Vec<Probe>), EngineError> {
    let mut e = create_engine(42, EngineLimits::default())?;
    let a = e.add_device("generic.host.pc", 1, "PC1".into())?;
    let r = e.add_device("cisco.router.2911", 1, "R1".into())?;
    let b = e.add_device("generic.host.pc", 1, "PC2".into())?;
    let pa = e.add_port(a, MediaKind::Ethernet)?;
    let ra = e.add_port(r, MediaKind::Ethernet)?;
    let rb = e.add_port(r, MediaKind::Ethernet)?;
    let pb = e.add_port(b, MediaKind::Ethernet)?;
    let ip = |subnet, host| Ipv4Addr::new(192, 168, subnet, host);
    let cfg = |port, address, mac| InterfaceConfig {
        key: InterfaceKey { port, vlan: None },
        address,
        prefix_len: 24,
        mac: MacAddress([2, 0, 0, 0, 0, mac]),
    };
    e.configure_ipv4_host(a, cfg(pa, ip(1, 10), 1), Some(ip(1, 1)))?;
    e.configure_router(r)?;
    e.configure_router_interface(r, cfg(ra, ip(1, 1), 2))?;
    e.configure_router_interface(r, cfg(rb, ip(2, 1), 3))?;
    e.configure_ipv4_host(b, cfg(pb, ip(2, 10), 4), Some(ip(2, 1)))?;
    for endpoints in [[pa, ra], [rb, pb]] {
        e.execute(EngineCommand::ConnectPorts {
            endpoints,
            bandwidth_bps: 100_000_000,
            delay_ns: 100,
            loss_ppm: 0,
            queue_limit_bytes: 65536,
        })?;
    }
    for id in [a, r, b] {
        e.power_on(id)?;
    }
    let token = e.ping(a, ip(2, 10), 64, 5_000_000_000)?;
    let report = e.run_until(1_000_000_000, 4096)?;
    if report.faulted || report.budget_exhausted {
        return Err(EngineError::DeviceFault);
    }
    let ping = e.probe(a, token).ok_or(EngineError::InvalidState)?;
    let hops = e.traceroute(a, ip(2, 10), 8, 5_000_000_000, 4096)?;
    if !matches!(ping.status, ProbeStatus::Reply { .. })
        || hops.len() != 2
        || !matches!(hops[0].status, ProbeStatus::TimeExceeded { .. })
        || !matches!(hops[1].status, ProbeStatus::Reply { .. })
    {
        return Err(EngineError::DeviceFault);
    }
    Ok((ping, hops))
}
