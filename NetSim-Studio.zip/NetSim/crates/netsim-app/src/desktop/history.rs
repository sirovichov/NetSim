use super::*;
/// Topology history only; restores persisted configuration, not transient packets.
#[derive(Default)]
pub struct History {
    undo: Vec<Project>,
    redo: Vec<Project>,
}
impl History {
    pub fn record(&mut self, p: Project) {
        if self.undo.len() == 32 {
            self.undo.remove(0);
        }
        self.undo.push(p);
        self.redo.clear();
    }
    pub fn undo(&mut self, current: &Desktop) -> Result<Option<Desktop>, String> {
        let Some(p) = self.undo.last() else {
            return Ok(None);
        };
        let next = Desktop::from_project(p.clone())?;
        let old = current.export()?;
        self.undo.pop();
        self.redo.push(old);
        Ok(Some(next))
    }
    pub fn redo(&mut self, current: &Desktop) -> Result<Option<Desktop>, String> {
        let Some(p) = self.redo.last() else {
            return Ok(None);
        };
        let next = Desktop::from_project(p.clone())?;
        let old = current.export()?;
        self.redo.pop();
        self.undo.push(old);
        Ok(Some(next))
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn undo_redo_restores_topology() {
        let mut d = Desktop::new(42).unwrap();
        let mut h = History::default();
        h.record(d.export().unwrap());
        d.add(Model::Pc, [0., 0.]).unwrap();
        let d = h.undo(&d).unwrap().unwrap();
        assert!(d.nodes().is_empty());
        let d = h.redo(&d).unwrap().unwrap();
        assert_eq!(d.nodes().len(), 1);
    }
}
