use super::*;
impl Desktop {
    /// Explicit simulator service commands, not claimed as vendor IOS syntax.
    pub fn service_cli(&mut self, id: u64, line: &str) -> Result<String, String> {
        let device = self.id(id)?;
        let v: Vec<_> = line.split_whitespace().collect();
        let addr = |s: &str| {
            s.parse::<Ipv4Addr>()
                .map_err(|_| "Invalid IPv4 address".to_string())
        };
        match v.as_slice(){
            [":dhcp","client"]=>{self.enable_dhcp(id)?;Ok("DHCP client enabled".into())}
            [":dhcp","server",first,last,prefix,gateway,lease]=>{
                let pool=netsim_storage::DhcpPool{first:addr(first)?,last:addr(last)?,prefix:prefix.parse().map_err(|_|"Invalid prefix")?,gateway:if *gateway=="-"{None}else{Some(addr(gateway)?)},lease_secs:lease.parse().map_err(|_|"Invalid lease")?};
                self.configure_dhcp_server(id,pool)?;Ok("DHCP pool configured".into())
            }
            [":dhcp","show"]=>Ok(format!("{:#?}",self.dhcp_status().into_iter().filter(|s|s.device==device).collect::<Vec<_>>())),
            [":ospf","enable",rid]=>{self.enable_ospf(id,addr(rid)?)?;Ok("Area 0 teaching OSPF enabled".into())}
            [":ospf","show"]=>Ok(format!("{:#?}",self.ospf_status().into_iter().filter(|s|s.device==device).collect::<Vec<_>>())),
            _=>Err("Commands: :dhcp client | :dhcp server FIRST LAST PREFIX GATEWAY_OR_- LEASE | :dhcp show | :ospf enable ROUTER_ID | :ospf show".into())
        }
    }
}
