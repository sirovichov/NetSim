use super::*;

impl Desktop {
    /// Diagnostics for simulated endpoints without a vendor command interpreter.
    pub(super) fn endpoint_cli(&mut self, id: u64, line: &str) -> Result<String, String> {
        let node = self.node(id).ok_or("Unknown node")?;
        if !node.powered {
            return Err("Device is powered off".into());
        }
        let host = node.model.host();
        let words = line.split_whitespace().collect::<Vec<_>>();
        match words.as_slice() {
            [] => Ok(String::new()),
            ["?"] | ["help"] => Ok(if host {
                "hostname\nipconfig\nping ADDRESS\nshow probes\n:dhcp show"
            } else {
                "hostname\nshow clients"
            }
            .into()),
            ["hostname"] => Ok(node.hostname.clone()),
            ["show", "clients"] if node.model.ap() => {
                let rows: Vec<_> = self
                    .associations
                    .values()
                    .filter(|a| a.ap == id)
                    .filter_map(|a| {
                        self.node(a.client).map(|n| {
                            format!(
                                "{}   VLAN {}   CH {}   {} dBm",
                                n.hostname, a.vlan, a.channel, a.signal_dbm
                            )
                        })
                    })
                    .collect();
                Ok(if rows.is_empty() {
                    "No associated clients".into()
                } else {
                    rows.join("\n")
                })
            }
            ["ipconfig"] | ["show", "probes"] if host => {
                let eid = self.id(id)?;
                let snap = self.snapshot();
                let state = snap.l3.nodes.iter().find(|n| n.device == eid);
                if words[0] == "ipconfig" {
                    Ok(state.and_then(|n| n.interfaces.first()).map_or_else(
                        || "eth0   IPv4 unassigned".into(),
                        |i| format!("eth0   {}/{}", i.config.address, i.config.prefix_len),
                    ))
                } else {
                    let probes: Vec<_> = state
                        .into_iter()
                        .flat_map(|n| n.probes.iter().rev().take(10))
                        .map(|p| format!("#{}   {}   {:?}", p.token, p.destination, p.status))
                        .collect();
                    Ok(if probes.is_empty() {
                        "No probes".into()
                    } else {
                        probes.join("\n")
                    })
                }
            }
            ["ping", address] if host => {
                let token =
                    self.ping(id, address.parse().map_err(|_| "Expected an IPv4 address")?)?;
                Ok(format!(
                    "Probe #{token} queued. Advance simulation time, then use show probes."
                ))
            }
            _ => Ok("% Unknown command. Type ? for help.".into()),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn host_commands_use_the_address_and_probes_of_the_target() {
        let project =
            Project::decode(include_bytes!("../../../../examples/two-pcs.netsim")).unwrap();
        let mut d = Desktop::from_project(project).unwrap();
        assert_eq!(d.execute(1, "ipconfig").unwrap(), "eth0   10.0.0.1/24");
        assert_eq!(d.execute(2, "ipconfig").unwrap(), "eth0   10.0.0.2/24");
        d.advance(1_000_000_000).unwrap();
        assert!(d.execute(1, "ping 10.0.0.2").unwrap().contains("queued"));
        d.advance(1_000_000_000).unwrap();
        assert!(d.execute(1, "show probes").unwrap().contains("Reply"));
        assert_eq!(d.execute(2, "show probes").unwrap(), "No probes");
        assert!(d.execute(2, "ping invalid").is_err());
        d.power(2, false).unwrap();
        assert!(d.execute(2, "ipconfig").is_err());
    }

    #[test]
    fn access_point_lists_only_its_associations() {
        let project =
            Project::decode(include_bytes!("../../../../examples/wireless-dhcp.netsim")).unwrap();
        let mut d = Desktop::from_project(project).unwrap();
        assert!(d.execute(2, "show clients").unwrap().contains("Laptop3"));
        assert_eq!(
            d.execute(4, "show clients").unwrap(),
            "No associated clients"
        );
        assert_eq!(d.prompt(3).unwrap(), "Laptop3>");
    }
}
