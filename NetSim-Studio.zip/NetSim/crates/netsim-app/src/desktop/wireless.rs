use super::*;
use netsim_storage::{ApConfig, WifiClient};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Association {
    pub ap: u64,
    pub client: u64,
    pub radio: u8,
    pub channel: u8,
    pub vap: u8,
    pub vlan: u16,
    pub link: LinkId,
    pub signal_dbm: i16,
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct VisibleNetwork {
    pub ap: u64,
    pub ssid: String,
    pub channel: u8,
    pub signal_dbm: i16,
    pub secured: bool,
}

impl Desktop {
    pub fn wireless(&self) -> &netsim_storage::WirelessSettings {
        &self.project.wireless
    }
    pub fn dhcp_status(&self) -> Vec<netsim_engine::DhcpStatus> {
        self.lab.dhcp_status()
    }
    pub fn ospf_status(&self) -> Vec<netsim_engine::OspfStatus> {
        self.lab.ospf_status()
    }
    pub fn services(&self) -> &netsim_storage::Services {
        &self.project.services
    }
    pub fn associations(&self) -> Vec<Association> {
        self.associations.values().copied().collect()
    }
    fn detach(&mut self, client: u64) -> Result<(), String> {
        if let Some(a) = self.associations.get(&client).copied() {
            self.lab.disconnect(a.link).map_err(|e| e.to_string())?;
            self.associations.remove(&client);
        }
        Ok(())
    }
    pub(super) fn detach_related(&mut self, id: u64) -> Result<(), String> {
        let clients: Vec<_> = self
            .associations
            .values()
            .filter(|a| a.ap == id || a.client == id)
            .map(|a| a.client)
            .collect();
        for c in clients {
            self.detach(c)?;
        }
        Ok(())
    }
    pub fn configure_ap(&mut self, id: u64, c: ApConfig) -> Result<(), String> {
        c.validate()?;
        if !self.node(id).is_some_and(|n| n.model.ap()) {
            return Err("Not an access point".into());
        }
        self.detach_related(id)?;
        self.lab
            .configure_ap(self.id(id)?, &c)
            .map_err(|e| e.to_string())?;
        self.project.wireless.aps.insert(id, c);
        self.reconcile_wifi()
    }
    pub fn configure_wifi(&mut self, id: u64, c: Option<WifiClient>) -> Result<(), String> {
        if self.node(id).map(|n| n.model) != Some(Model::Laptop) {
            return Err("Wi-Fi available on Laptop".into());
        }
        if c.is_some()
            && self
                .project
                .cables
                .iter()
                .any(|c| c.ends.iter().any(|e| e.node == id))
        {
            return Err("Disconnect wired cable first".into());
        }
        if let Some(c) = &c {
            if !(1..=2).contains(&c.radio)
                || c.ssid.is_empty()
                || c.ssid.len() > 32
                || c.psk
                    .as_ref()
                    .is_some_and(|s| !(8..=63).contains(&s.len()) || !s.is_ascii())
            {
                return Err("Invalid Wi-Fi credentials".into());
            }
        }
        self.detach(id)?;
        if let Some(c) = c {
            self.project.wireless.clients.insert(id, c);
        } else {
            self.project.wireless.clients.remove(&id);
        }
        self.reconcile_wifi()
    }
    // Canvas units are metres in this educational radio model.
    fn access_points_in_range(
        &self,
        client: u64,
        radio: u8,
    ) -> impl Iterator<Item = (u64, &ApConfig, i16, u8)> {
        let listener = self
            .node(client)
            .filter(|n| n.model == Model::Laptop && n.powered);
        self.project
            .wireless
            .aps
            .iter()
            .filter_map(move |(&id, ap)| {
                let listener = listener?;
                let band = ap.radios.get(usize::from(radio.checked_sub(1)?))?;
                let node = self.node(id)?;
                if !node.powered || !band.enabled {
                    return None;
                }
                let dx = node.position[0] - listener.position[0];
                let dy = node.position[1] - listener.position[1];
                let distance = dx.hypot(dy).max(1.0);
                let band_loss = if radio == 1 { 7.0 } else { 0.0 };
                let signal = (-35.0 - 20.0 * distance.log10() - band_loss).round() as i16;
                (signal >= -82).then_some((id, ap, signal, band.channel))
            })
    }

    pub fn wifi_scan(&self, client: u64, radio: u8) -> Vec<VisibleNetwork> {
        let mut networks = Vec::new();
        for (ap, config, signal_dbm, channel) in self.access_points_in_range(client, radio) {
            for vap in config
                .vaps
                .iter()
                .filter(|v| v.radio == radio && v.enabled && v.broadcast)
            {
                networks.push(VisibleNetwork {
                    ap,
                    ssid: vap.ssid.clone(),
                    channel,
                    signal_dbm,
                    secured: vap.psk.is_some(),
                });
            }
        }
        networks.sort_by_key(|n| (std::cmp::Reverse(n.signal_dbm), n.ap));
        networks
    }

    fn best(&self, id: u64, c: &WifiClient) -> Option<(u64, u8, u16, i16, u8)> {
        self.access_points_in_range(id, c.radio)
            .filter_map(|(id, ap, signal, channel)| {
                ap.vaps
                    .iter()
                    .filter(|v| {
                        v.enabled && v.radio == c.radio && v.ssid == c.ssid && v.psk == c.psk
                    })
                    .min_by_key(|v| v.index)
                    .map(|v| (id, v.index, v.vlan, signal, channel))
            })
            .max_by_key(|(id, idx, _, signal, _)| {
                (*signal, std::cmp::Reverse(*id), std::cmp::Reverse(*idx))
            })
    }
    pub(super) fn reconcile_wifi(&mut self) -> Result<(), String> {
        let clients = self.project.wireless.clients.clone();
        for (id, c) in clients {
            let best = self.best(id, &c);
            if let Some(old) = self.associations.get_mut(&id) {
                if best.is_some_and(|(ap, vap, vlan, _, channel)| {
                    ap == old.ap
                        && vap == old.vap
                        && vlan == old.vlan
                        && c.radio == old.radio
                        && channel == old.channel
                }) {
                    old.signal_dbm = best.unwrap().3;
                    continue;
                }
            }
            self.detach(id)?;
            if let Some((ap, vap, vlan, signal, channel)) = best {
                let rate = if c.radio == 1 { 86_000_000 } else { 54_000_000 };
                let apid = self.id(ap)?;
                let cid = self.id(id)?;
                let link = match self.lab.attach_wifi(apid, cid, vlan, rate, 0) {
                    Ok(l) => l,
                    Err(netsim_core::EngineError::ResourceLimit) => continue,
                    Err(e) => return Err(e.to_string()),
                };
                self.associations.insert(
                    id,
                    Association {
                        ap,
                        client: id,
                        radio: c.radio,
                        channel,
                        vap,
                        vlan,
                        link,
                        signal_dbm: signal,
                    },
                );
            }
        }
        Ok(())
    }
    pub fn configure_dhcp_server(
        &mut self,
        id: u64,
        pool: netsim_storage::DhcpPool,
    ) -> Result<(), String> {
        if self.node(id).map(|n| n.model) != Some(Model::Server) || !pool.valid() {
            return Err("Invalid DHCP server".into());
        }
        self.lab
            .dhcp_server(self.id(id)?, &pool)
            .map_err(|e| e.to_string())?;
        self.project.services.dhcp_servers.insert(id, pool);
        Ok(())
    }
    pub fn enable_dhcp(&mut self, id: u64) -> Result<(), String> {
        if !self.node(id).is_some_and(|n| n.model.host())
            || self.project.services.dhcp_servers.contains_key(&id)
        {
            return Err("Invalid DHCP client".into());
        }
        self.lab
            .dhcp_client(self.id(id)?)
            .map_err(|e| e.to_string())?;
        self.project.services.dhcp_clients.insert(id);
        self.project
            .nodes
            .iter_mut()
            .find(|n| n.id == id)
            .unwrap()
            .host = None;
        Ok(())
    }
    pub fn enable_ospf(&mut self, id: u64, rid: Ipv4Addr) -> Result<(), String> {
        if !self
            .node(id)
            .is_some_and(|n| matches!(n.model, Model::CiscoRouter | Model::EltexRouter))
            || self
                .project
                .services
                .ospf
                .iter()
                .any(|(other, r)| *other != id && *r == rid)
        {
            return Err("Invalid router ID".into());
        }
        self.lab
            .ospf(self.id(id)?, rid)
            .map_err(|e| e.to_string())?;
        self.project.services.ospf.insert(id, rid);
        Ok(())
    }
}
