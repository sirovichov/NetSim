//! Composition root. Vendor models are registered here, never in the scheduler.

use netsim_core::{DeviceId, EngineError, EventKind};
use netsim_core::{EngineCommand, SessionId, TimerId};
use netsim_devices::{DeviceContext, DeviceDescriptor, DeviceSnapshot, NetworkDevice};
use netsim_engine::{Engine, EngineLimits, SimulationSnapshot, TraceSnapshot};
use netsim_engine::{RunReport, Scheduler};
use std::collections::BTreeMap;

pub fn catalog() -> BTreeMap<&'static str, &'static DeviceDescriptor> {
    netsim_cisco::PROFILES
        .iter()
        .chain(netsim_eltex::PROFILES)
        .chain(netsim_generic::PROFILES)
        .map(|profile| (profile.profile_id, profile))
        .collect()
}

/// Scheduler smoke test: no device behavior or real packet transmission.
pub fn scheduler_demo() -> Result<RunReport, EngineError> {
    let mut scheduler = Scheduler::new(16);
    for at in [20, 10, 10] {
        scheduler.schedule(at, DeviceId(1), 0, EventKind::DeviceBoot)?;
    }
    scheduler.run_until(30, 16)
}

/// Lifecycle-only placeholder; deliberately does not implement vendor CLI or protocols.
struct DraftDevice {
    id: DeviceId,
    descriptor: DeviceDescriptor,
    hostname: String,
}

impl NetworkDevice for DraftDevice {
    fn id(&self) -> DeviceId {
        self.id
    }

    fn descriptor(&self) -> &DeviceDescriptor {
        &self.descriptor
    }

    fn on_event(&mut self, _event: EventKind, _ctx: &mut DeviceContext) -> Result<(), EngineError> {
        Ok(())
    }

    fn execute_cli(
        &mut self,
        _session: SessionId,
        _command: &str,
        _ctx: &mut DeviceContext,
    ) -> Result<String, EngineError> {
        Err(EngineError::Unsupported)
    }

    fn snapshot(&self) -> DeviceSnapshot {
        DeviceSnapshot {
            id: self.id,
            hostname: self.hostname.clone(),
        }
    }
}

fn draft_factory(
    id: DeviceId,
    descriptor: DeviceDescriptor,
    hostname: String,
) -> Box<dyn NetworkDevice> {
    Box::new(DraftDevice {
        id,
        descriptor,
        hostname,
    })
}

pub fn create_engine(seed: u64, limits: EngineLimits) -> Result<Engine, EngineError> {
    let mut engine = Engine::new(seed, limits);
    for descriptor in catalog().values() {
        engine.register_profile(**descriptor, draft_factory)?;
    }
    Ok(engine)
}

/// Headless lifecycle and timer demonstration, not network traffic.
pub fn core_demo() -> Result<(SimulationSnapshot, TraceSnapshot), EngineError> {
    let mut engine = create_engine(42, EngineLimits::default())?;
    let router = engine.add_device("cisco.router.2911", 1, "R1".into())?;
    let ap = engine.add_device("eltex.ap.wep2ac", 1, "AP1".into())?;
    engine.power_on(router)?;
    engine.power_on(ap)?;
    engine.set_timer(router, TimerId(1), 20)?;
    engine.set_timer(ap, TimerId(1), 10)?;
    engine.set_timer(router, TimerId(1), 5)?;
    engine.set_timer(ap, TimerId(2), 15)?;
    engine.cancel_timer(ap, TimerId(2))?;
    engine.run_until(30, 32)?;
    engine.execute(EngineCommand::Reboot(router))?;
    Ok((engine.snapshot(), engine.trace()))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn all_nine_draft_profiles_present() {
        let registry = catalog();
        assert_eq!(registry.len(), 9);
        for model in netsim_storage::Model::ALL {
            assert!(registry.contains_key(model.profile()), "{model:?}");
        }
        assert!(registry.contains_key("cisco.router.2911"));
        assert!(registry.contains_key("eltex.ap.wep2ac-smart"));
        assert_eq!(
            registry["eltex.ap.wep2ac"].firmware_reference,
            Some("1.25.0")
        );
    }

    #[test]
    fn smoke_demo() {
        let report = scheduler_demo().unwrap();
        assert_eq!(report.events.len(), 3);
        assert_eq!(report.events[0].at, 10);
        assert_eq!(report.now, 30);
    }
}

/// Two hosts resolve IPv4 neighbors through a generic learning bridge.
pub fn l2_demo() -> Result<SimulationSnapshot, EngineError> {
    use netsim_core::{MacAddress, MediaKind};
    use netsim_engine::PortMode;
    use std::net::Ipv4Addr;
    let mut e = create_engine(42, EngineLimits::default())?;
    let a = e.add_device("generic.host.pc", 1, "PC1".into())?;
    let b = e.add_device("generic.host.pc", 1, "PC2".into())?;
    let sw = e.add_device("cisco.switch.2960", 1, "SW1".into())?;
    let pa = e.add_port(a, MediaKind::Ethernet)?;
    let pb = e.add_port(b, MediaKind::Ethernet)?;
    let s1 = e.add_port(sw, MediaKind::Ethernet)?;
    let s2 = e.add_port(sw, MediaKind::Ethernet)?;
    let ip1 = Ipv4Addr::new(192, 168, 1, 1);
    let ip2 = Ipv4Addr::new(192, 168, 1, 2);
    let mac2 = MacAddress([2, 0, 0, 0, 0, 2]);
    e.configure_host(a, pa, ip1, MacAddress([2, 0, 0, 0, 0, 1]))?;
    e.configure_host(b, pb, ip2, mac2)?;
    e.configure_switch(sw, 32768, MacAddress([2, 0, 0, 0, 0, 3]))?;
    for port in [s1, s2] {
        e.configure_switch_port(sw, port, PortMode::Access(10))?;
    }
    for endpoints in [[pa, s1], [pb, s2]] {
        e.execute(EngineCommand::ConnectPorts {
            endpoints,
            bandwidth_bps: 100_000_000,
            delay_ns: 100,
            loss_ppm: 0,
            queue_limit_bytes: 65536,
        })?;
    }
    for id in [a, b, sw] {
        e.power_on(id)?;
    }
    let report = e.run_until(40_000_000_000, 1000)?;
    if report.faulted || report.budget_exhausted {
        return Err(EngineError::DeviceFault);
    }
    e.request_arp(a, ip2)?;
    let report = e.run_until(41_000_000_000, 1000)?;
    if report.faulted || report.budget_exhausted || e.arp_lookup(a, ip2) != Some(mac2) {
        return Err(EngineError::DeviceFault);
    }
    Ok(e.snapshot())
}

mod l3_demo;
pub use l3_demo::l3_demo;

mod cisco_lab;
pub use cisco_lab::{CiscoLab, cisco_demo};
pub use netsim_cisco::ios::Model as CiscoModel;
pub use netsim_core::SessionId as CiscoSessionId;

mod mixed_lab;
pub use mixed_lab::{MixedLab, eltex_demo};
pub use netsim_eltex::Model as EltexModel;

pub mod desktop;

/// Run a saved lab through the same controller used by the GUI.
pub fn wireless_demo() -> Result<String, String> {
    let p =
        netsim_storage::Project::decode(include_bytes!("../../../examples/wireless-dhcp.netsim"))?;
    let mut d = desktop::Desktop::from_project(p)?;
    for _ in 0..50 {
        d.advance(1_000_000_000)?;
    }
    let status = d
        .dhcp_status()
        .into_iter()
        .find(|s| Some(s.device) == d.engine_id(3))
        .ok_or("Missing DHCP client")?;
    if status.phase != netsim_engine::DhcpPhase::Bound {
        return Err("DHCP did not bind".into());
    }
    let token = d.ping(3, "10.0.0.1".parse().map_err(|_| "Invalid example IP")?)?;
    for _ in 0..6 {
        d.advance(1_000_000_000)?;
    }
    let snap = d.snapshot();
    let probe = snap
        .l3
        .nodes
        .iter()
        .find(|n| Some(n.device) == d.engine_id(3))
        .and_then(|n| n.probes.iter().find(|p| p.token == token))
        .ok_or("Missing ping probe")?;
    if !matches!(probe.status, netsim_engine::ProbeStatus::Reply { .. }) {
        return Err(format!("Ping failed: {:?}", probe.status));
    }
    Ok(format!(
        "Wi-Fi associated: {:?}\nDHCP lease: {:?}\nPing: {:?}\nWireless DHCP simulation successful",
        d.associations(),
        status.address,
        probe.status
    ))
}

pub mod beta_labs;
pub mod beta_worker;
