//! Original practice tasks, with separate starter and reference configurations.
use crate::desktop::Desktop;
use netsim_engine::{DhcpPhase, ProbeStatus, RouteOrigin};
pub use netsim_labs::CATALOG;
use netsim_labs::{Check, Grade};
use netsim_storage::{DhcpPool, Endpoint, HostConfig, Model, Project, WifiClient};
use std::net::Ipv4Addr;
pub struct Lab {
    pub title: &'static str,
    pub instructions: String,
    pub starter: Project,
    pub checks: Vec<Check>,
}
fn ip(s: &str) -> Ipv4Addr {
    s.parse().expect("built-in address")
}
fn add(d: &mut Desktop, m: Model, x: f32, y: f32) -> Result<u64, String> {
    d.add(m, [x, y])
}
fn link(d: &mut Desktop, a: u64, pa: &str, b: u64, pb: &str) -> Result<(), String> {
    d.connect(
        Endpoint {
            node: a,
            port: pa.into(),
        },
        Endpoint {
            node: b,
            port: pb.into(),
        },
    )
}
fn host(d: &mut Desktop, n: u64, a: &str, g: Option<&str>) -> Result<(), String> {
    d.configure_host(
        n,
        HostConfig {
            ip: ip(a),
            prefix: 24,
            gateway: g.map(ip),
        },
    )
}
fn cli(d: &mut Desktop, n: u64, lines: &[&str]) -> Result<(), String> {
    for line in lines {
        if *line == "enable" && d.prompt(n)?.ends_with('#') {
            continue;
        }
        let s = d.execute(n, line)?;
        if s.starts_with('%') {
            return Err(format!("{line}: {s}"));
        }
    }
    Ok(())
}
fn access(d: &mut Desktop, n: u64, port: &str, vlan: u16) -> Result<(), String> {
    let a = if port.starts_with("1/") {
        format!("interface gi {port}")
    } else {
        format!("interface {port}")
    };
    let b = format!("vlan {vlan}");
    let c = format!("switchport access vlan {vlan}");
    cli(
        d,
        n,
        &[
            "enable",
            "configure terminal",
            &b,
            "exit",
            &a,
            "switchport mode access",
            &c,
            "end",
        ],
    )
}
fn trunk(d: &mut Desktop, n: u64, port: &str) -> Result<(), String> {
    let a = if port.starts_with("1/") {
        format!("interface gi {port}")
    } else {
        format!("interface {port}")
    };
    cli(
        d,
        n,
        &[
            "enable",
            "configure terminal",
            "vlan 10",
            "exit",
            &a,
            "switchport mode trunk",
            "switchport trunk allowed vlan 10",
            "end",
        ],
    )
}
fn ping(a: u64, b: &str) -> Check {
    Check::Ping {
        source: a,
        destination: ip(b),
        reachable: true,
    }
}
fn make(index: usize, solved: bool) -> Result<Lab, String> {
    let (_, title) = *CATALOG.get(index).ok_or("Unknown lab")?;
    let mut d = Desktop::new(42)?;
    let (instructions, checks) = match index {
        0 | 1 => {
            let a = add(&mut d, Model::Pc, -100., 0.)?;
            let b = add(&mut d, Model::Pc, 100., 0.)?;
            host(&mut d, a, "10.0.0.1", None)?;
            if solved || index == 0 {
                host(&mut d, b, "10.0.0.2", None)?;
            }
            if solved || index == 1 {
                link(&mut d, a, "eth0", b, "eth0")?;
            }
            let mut checks = vec![ping(a, "10.0.0.2")];
            let instructions = if index == 1 {
                checks.push(Check::Arp {
                    node: a,
                    ip: ip("10.0.0.2"),
                });
                "Configure PC2 as 10.0.0.2/24. Ping it from PC1 and inspect the ARP exchange."
            } else {
                "Connect PC1 and PC2 with Ethernet; verify ping and inspect ARP."
            };
            (instructions.into(), checks)
        }
        2 | 9 => {
            let a = add(&mut d, Model::Pc, -100., 80.)?;
            let b = add(&mut d, Model::Pc, 100., 80.)?;
            let (m, p1, p2) = if index == 2 {
                (Model::CiscoSwitch, "FastEthernet0/1", "FastEthernet0/2")
            } else {
                (Model::EltexSwitch, "1/0/1", "1/0/2")
            };
            let s = add(&mut d, m, 0., -60.)?;
            host(&mut d, a, "10.0.0.1", None)?;
            host(&mut d, b, "10.0.0.2", None)?;
            link(&mut d, a, "eth0", s, p1)?;
            link(&mut d, b, "eth0", s, p2)?;
            if solved {
                access(&mut d, s, p1, 10)?;
                access(&mut d, s, p2, 10)?;
            }
            (
                format!(
                    "Configure {p1} and {p2} as access VLAN 10. Verify connectivity and MAC learning."
                ),
                vec![ping(a, "10.0.0.2"), Check::Learned { node: s, vlan: 10 }],
            )
        }
        3 | 10 => {
            let a = add(&mut d, Model::Pc, -100., 0.)?;
            let (m, p) = if index == 3 {
                (Model::CiscoRouter, "GigabitEthernet0/0")
            } else {
                (Model::EltexRouter, "1/0/1")
            };
            let b = add(&mut d, m, 100., 0.)?;
            host(&mut d, a, "10.0.0.2", None)?;
            link(&mut d, a, "eth0", b, p)?;
            if solved {
                if index == 3 {
                    cli(
                        &mut d,
                        b,
                        &[
                            "enable",
                            "conf t",
                            "int gi0/0",
                            "ip address 10.0.0.1 255.255.255.0",
                            "no shut",
                            "end",
                        ],
                    )?;
                } else {
                    cli(
                        &mut d,
                        b,
                        &[
                            "configure",
                            "interface gi 1/0/1",
                            "ip address 10.0.0.1/24",
                            "end",
                            "commit",
                            "confirm",
                        ],
                    )?;
                }
            }
            (
                format!("Configure {p} as 10.0.0.1/24, enable it; for ESR commit and confirm."),
                vec![
                    Check::Address {
                        node: b,
                        ip: ip("10.0.0.1"),
                    },
                    ping(a, "10.0.0.1"),
                ],
            )
        }
        4 | 8 => {
            let a = add(&mut d, Model::CiscoRouter, -70., 0.)?;
            let b = add(&mut d, Model::EltexRouter, 70., 0.)?;
            let h = add(&mut d, Model::Pc, 180., 80.)?;
            cli(
                &mut d,
                a,
                &[
                    "enable",
                    "conf t",
                    "int gi0/0",
                    "ip address 10.0.0.1 255.255.255.0",
                    "no shut",
                    "end",
                ],
            )?;
            cli(
                &mut d,
                b,
                &[
                    "configure",
                    "interface gi 1/0/1",
                    "ip address 10.0.0.2/24",
                    "exit",
                    "interface gi 1/0/2",
                    "ip address 10.1.0.1/24",
                    "end",
                    "commit",
                    "confirm",
                ],
            )?;
            host(&mut d, h, "10.1.0.2", Some("10.1.0.1"))?;
            link(&mut d, a, "GigabitEthernet0/0", b, "1/0/1")?;
            link(&mut d, b, "1/0/2", h, "eth0")?;
            if index == 4 {
                if solved {
                    cli(
                        &mut d,
                        a,
                        &["conf t", "ip route 10.1.0.0 255.255.255.0 10.0.0.2", "end"],
                    )?;
                }
                (
                    "On Cisco add a static route to 10.1.0.0/24 via 10.0.0.2.".into(),
                    vec![ping(a, "10.1.0.2")],
                )
            } else {
                if solved {
                    d.enable_ospf(a, ip("1.1.1.1"))?;
                    d.enable_ospf(b, ip("2.2.2.2"))?;
                }
                ("Enable Area 0 on both routers (router IDs 1.1.1.1 and 2.2.2.2) using service controls.".into(),vec![Check::Ospf{node:a,network:ip("10.1.0.0")},ping(a,"10.1.0.2")])
            }
        }
        5 | 12 => {
            let a = add(&mut d, Model::Pc, -160., 80.)?;
            let b = add(&mut d, Model::Pc, 160., 80.)?;
            let s = add(&mut d, Model::CiscoSwitch, -100., -40.)?;
            let t = add(
                &mut d,
                if index == 5 {
                    Model::CiscoSwitch
                } else {
                    Model::EltexSwitch
                },
                100.,
                -40.,
            )?;
            let (p1, p2) = if index == 5 {
                ("FastEthernet0/1", "GigabitEthernet0/1")
            } else {
                ("1/0/1", "1/0/28")
            };
            host(&mut d, a, "10.0.0.1", None)?;
            host(&mut d, b, "10.0.0.2", None)?;
            link(&mut d, a, "eth0", s, "FastEthernet0/1")?;
            link(&mut d, b, "eth0", t, p1)?;
            link(&mut d, s, "GigabitEthernet0/1", t, p2)?;
            if solved {
                access(&mut d, s, "FastEthernet0/1", 10)?;
                access(&mut d, t, p1, 10)?;
                trunk(&mut d, s, "GigabitEthernet0/1")?;
                trunk(&mut d, t, p2)?;
            }
            (
                format!(
                    "Set edge ports to access VLAN 10 and uplinks GigabitEthernet0/1 and {p2} to trunk allowing VLAN 10."
                ),
                vec![
                    ping(a, "10.0.0.2"),
                    Check::Learned { node: s, vlan: 10 },
                    Check::Learned { node: t, vlan: 10 },
                    Check::Tagged {
                        a: s,
                        b: t,
                        vlan: 10,
                    },
                ],
            )
        }
        6 => {
            let a = add(&mut d, Model::CiscoSwitch, 0., -100.)?;
            let b = add(&mut d, Model::CiscoSwitch, -100., 80.)?;
            let c = add(&mut d, Model::EltexSwitch, 100., 80.)?;
            link(&mut d, a, "FastEthernet0/1", b, "FastEthernet0/1")?;
            link(&mut d, a, "FastEthernet0/2", c, "1/0/1")?;
            if solved {
                link(&mut d, b, "FastEthernet0/2", c, "1/0/2")?;
            }
            ("Complete the triangle between SW2 Fa0/2 and MES3 1/0/2; wait for convergence and inspect STP.".into(),vec![Check::Tree{nodes:vec![a,b,c]}])
        }
        7 | 11 => {
            let server = add(&mut d, Model::Server, -100., 0.)?;
            let client = add(
                &mut d,
                if index == 7 { Model::Pc } else { Model::Laptop },
                100.,
                0.,
            )?;
            host(&mut d, server, "10.0.0.1", None)?;
            if index == 7 {
                link(&mut d, server, "eth0", client, "eth0")?;
            } else {
                let ap = add(&mut d, Model::Wep2acSmart, 0., 0.)?;
                link(&mut d, server, "eth0", ap, "eth0")?;
                if solved {
                    d.configure_wifi(
                        client,
                        Some(WifiClient {
                            ssid: "NetSim".into(),
                            psk: None,
                            radio: 2,
                        }),
                    )?;
                }
            }
            d.configure_dhcp_server(
                server,
                DhcpPool {
                    first: ip("10.0.0.100"),
                    last: ip("10.0.0.120"),
                    prefix: 24,
                    gateway: None,
                    lease_secs: 3600,
                },
            )?;
            if solved {
                d.enable_dhcp(client)?;
            }
            let mut checks = vec![Check::Dhcp { node: client }, ping(client, "10.0.0.1")];
            if index == 11 {
                checks.push(Check::Wifi { node: client });
            }
            (
                "Enable DHCP on the client. For Wi-Fi associate to open SSID NetSim, Radio 2."
                    .into(),
                checks,
            )
        }
        _ => return Err("Unknown lab".into()),
    };
    Ok(Lab {
        title,
        instructions,
        starter: d.export()?,
        checks,
    })
}
pub fn starter(index: usize) -> Result<Lab, String> {
    make(index, false)
}
pub fn reference(index: usize) -> Result<Lab, String> {
    make(index, true)
}
/// Grade a fresh clone, not the live simulation. Every ping is actively exercised.
pub fn grade(project: Project, checks: &[Check]) -> Result<Vec<Grade>, String> {
    if checks.is_empty() {
        return Err("Lab has no checks".into());
    }
    let mut d = Desktop::from_project(project)?;
    for _ in 0..50 {
        d.advance(1_000_000_000)?;
    }
    let mut result = vec![];
    for (i, c) in checks.iter().enumerate() {
        let passed = match c {
            Check::Ping {
                source,
                destination,
                reachable,
            } => {
                let token = d.ping(*source, *destination);
                for _ in 0..6 {
                    d.advance(1_000_000_000)?;
                }
                let reply = token.ok().is_some_and(|t| {
                    d.snapshot()
                        .l3
                        .nodes
                        .iter()
                        .filter(|n| Some(n.device) == d.engine_id(*source))
                        .any(|n| {
                            n.probes.iter().any(|p| {
                                p.token == t && matches!(p.status, ProbeStatus::Reply { .. })
                            })
                        })
                });
                reply == *reachable
            }
            Check::Address { node, ip } => d.snapshot().l3.nodes.iter().any(|n| {
                Some(n.device) == d.engine_id(*node)
                    && n.interfaces
                        .iter()
                        .any(|f| f.active && f.config.address == *ip)
            }),
            Check::Learned { node, vlan } => d.snapshot().l2.switches.iter().any(|(id, b)| {
                Some(*id) == d.engine_id(*node) && b.macs.iter().any(|m| m.0 == *vlan)
            }),
            Check::Tagged { a, b, vlan } => {
                let snap = d.snapshot();
                let links: Vec<_> = d
                    .cables()
                    .iter()
                    .filter(|c| {
                        c.ends.iter().any(|e| e.node == *a) && c.ends.iter().any(|e| e.node == *b)
                    })
                    .filter_map(|c| d.link_id(c, &snap))
                    .collect();
                d.capture().records().iter().any(|r| {
                    links.contains(&r.link)
                        && r.bytes.get(12..16).is_some_and(|p| {
                            p[0..2] == [0x81, 0]
                                && (u16::from_be_bytes([p[2], p[3]]) & 4095) == *vlan
                        })
                })
            }
            Check::Arp { node, ip } => d.snapshot().l3.nodes.iter().any(|n| {
                Some(n.device) == d.engine_id(*node)
                    && n.interfaces
                        .iter()
                        .any(|f| f.arp.iter().any(|a| a.0 == *ip))
            }),
            Check::Tree { nodes } => {
                let s = d.snapshot();
                let bs: Vec<_> =
                    s.l2.switches
                        .iter()
                        .filter(|(id, _)| nodes.iter().any(|n| d.engine_id(*n) == Some(*id)))
                        .collect();
                let edges = d
                    .cables()
                    .iter()
                    .filter(|c| c.ends.iter().all(|e| nodes.contains(&e.node)))
                    .count();
                edges == 3
                    && bs.len() == 3
                    && bs.iter().all(|(_, b)| b.root == bs[0].1.root)
                    && bs
                        .iter()
                        .flat_map(|(_, b)| b.ports.iter())
                        .filter(|(_, role, _)| *role == netsim_protocols::bridge::Role::Alternate)
                        .count()
                        >= 1
            }
            Check::Dhcp { node } => d
                .dhcp_status()
                .iter()
                .any(|s| Some(s.device) == d.engine_id(*node) && s.phase == DhcpPhase::Bound),
            Check::Ospf { node, network } => d.snapshot().l3.nodes.iter().any(|n| {
                Some(n.device) == d.engine_id(*node)
                    && n.routes
                        .iter()
                        .any(|r| r.origin == RouteOrigin::Ospf && r.prefix.network() == *network)
            }),
            Check::Wifi { node } => d.associations().iter().any(|a| a.client == *node),
        };
        let count = checks.len() as u32;
        let points = 100 / count + u32::from((i as u32) < 100 % count);
        result.push(Grade {
            label: format!("{c:?}"),
            passed,
            points: if passed { points } else { 0 },
        });
    }
    Ok(result)
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn all_references_pass() {
        for i in 0..CATALOG.len() {
            let l = reference(i).unwrap();
            let g = grade(l.starter, &l.checks).unwrap();
            assert!(g.iter().all(|x| x.passed), "{i}: {g:?}");
        }
    }
    #[test]
    fn empty_checks_rejected() {
        assert!(grade(Project::new(42), &[]).is_err());
    }
    #[test]
    fn disconnected_starter_fails() {
        let l = starter(0).unwrap();
        assert!(!grade(l.starter, &l.checks).unwrap()[0].passed);
    }
}
