//! UI-independent desktop document controller. The simulation is the source of forwarding state.
mod endpoint_cli;
mod history;
mod service_cli;
mod wireless;
use crate::{CiscoModel, CiscoSessionId, EltexModel, MixedLab};
pub use history::History;
use netsim_core::{DeviceId, LinkId, PortId, PowerState};
use netsim_engine::{SimulationSnapshot, TraceSnapshot};
use netsim_storage::{Cable, Endpoint, HostConfig, Model, Node, Project};
use std::{collections::BTreeMap, net::Ipv4Addr};
pub use wireless::{Association, VisibleNetwork};

pub struct Desktop {
    lab: MixedLab,
    project: Project,
    ids: BTreeMap<u64, DeviceId>,
    next_id: u64,
    associations: BTreeMap<u64, Association>,
}
impl Desktop {
    pub fn new(seed: u64) -> Result<Self, String> {
        Ok(Self {
            lab: MixedLab::new(seed).map_err(|e| e.to_string())?,
            project: Project::new(seed),
            ids: BTreeMap::new(),
            next_id: 1,
            associations: BTreeMap::new(),
        })
    }
    pub fn nodes(&self) -> &[Node] {
        &self.project.nodes
    }
    pub fn cables(&self) -> &[Cable] {
        &self.project.cables
    }
    pub fn node(&self, id: u64) -> Option<&Node> {
        self.project.nodes.iter().find(|n| n.id == id)
    }
    pub fn engine_id(&self, id: u64) -> Option<DeviceId> {
        self.ids.get(&id).copied()
    }
    fn id(&self, id: u64) -> Result<DeviceId, String> {
        self.engine_id(id).ok_or("Unknown node".into())
    }
    pub fn port_names(model: Model) -> Vec<String> {
        match model {
            Model::CiscoRouter => CiscoModel::Isr2911.port_names(),
            Model::CiscoSwitch => CiscoModel::Catalyst2960.port_names(),
            Model::EltexSwitch => EltexModel::Mes2428.port_names(),
            Model::EltexRouter => EltexModel::Esr100.port_names(),
            _ => vec!["eth0".into()],
        }
    }
    pub fn port(&self, e: &Endpoint) -> Option<PortId> {
        let n = self.node(e.node)?;
        if !Self::port_names(n.model).contains(&e.port) {
            return None;
        }
        self.lab.port(self.engine_id(e.node)?, &e.port)
    }
    pub fn add(&mut self, model: Model, position: [f32; 2]) -> Result<u64, String> {
        let id = self.next_id;
        let prefix = match model {
            Model::CiscoSwitch => "SW",
            Model::CiscoRouter => "R",
            Model::EltexSwitch => "MES",
            Model::EltexRouter => "ESR",
            Model::Pc => "PC",
            Model::Laptop => "Laptop",
            Model::Server => "Server",
            Model::Wep2ac | Model::Wep2acSmart => "AP",
        };
        let n = Node {
            id,
            model,
            hostname: format!("{prefix}{id}"),
            position,
            powered: true,
            host: None,
            vendor: None,
        };
        self.add_node(n)?;
        if model.ap() {
            self.configure_ap(id, netsim_storage::ApConfig::default())?;
        }
        Ok(id)
    }
    fn add_node(&mut self, n: Node) -> Result<(), String> {
        if self.ids.contains_key(&n.id)
            || n.id == u64::MAX
            || n.position
                .iter()
                .any(|v| !v.is_finite() || v.abs() > 1_000_000.0)
        {
            return Err("Invalid node".into());
        }
        let eid = match n.model {
            Model::CiscoSwitch => self.lab.add_cisco(CiscoModel::Catalyst2960, &n.hostname),
            Model::CiscoRouter => self.lab.add_cisco(CiscoModel::Isr2911, &n.hostname),
            Model::EltexSwitch => self.lab.add_eltex(EltexModel::Mes2428, &n.hostname),
            Model::EltexRouter => self.lab.add_eltex(EltexModel::Esr100, &n.hostname),
            Model::Wep2ac | Model::Wep2acSmart => self.lab.add_ap(n.model.profile(), &n.hostname),
            _ => self.lab.add_host(n.model.profile(), &n.hostname),
        }
        .map_err(|e| e.to_string())?;
        let result = (|| {
            if let Some(v) = &n.vendor {
                self.lab.import_config(eid, v.clone())?;
            }
            if let Some(h) = &n.host {
                self.lab
                    .configure_host_ip(eid, h)
                    .map_err(|e| e.to_string())?;
            }
            if !n.powered {
                self.lab.set_power(eid, false).map_err(|e| e.to_string())?;
            }
            Ok::<(), String>(())
        })();
        if let Err(e) = result {
            let _ = self.lab.remove(eid);
            return Err(e);
        }
        self.next_id = self.next_id.max(n.id + 1);
        self.ids.insert(n.id, eid);
        self.project.nodes.push(n);
        Ok(())
    }
    pub fn move_node(&mut self, id: u64, pos: [f32; 2]) -> Result<(), String> {
        if pos.iter().any(|v| !v.is_finite() || v.abs() > 1_000_000.0) {
            return Err("Invalid position".into());
        }
        self.project
            .nodes
            .iter_mut()
            .find(|n| n.id == id)
            .ok_or("Unknown node")?
            .position = pos;
        self.reconcile_wifi()?;
        Ok(())
    }
    pub fn remove(&mut self, id: u64) -> Result<(), String> {
        self.detach_related(id)?;
        self.lab.remove(self.id(id)?).map_err(|e| e.to_string())?;
        self.project.wireless.aps.remove(&id);
        self.project.wireless.clients.remove(&id);
        self.project.services.dhcp_clients.remove(&id);
        self.project.services.dhcp_servers.remove(&id);
        self.project.services.ospf.remove(&id);
        self.ids.remove(&id);
        self.project.nodes.retain(|n| n.id != id);
        self.project
            .cables
            .retain(|c| c.ends.iter().all(|e| e.node != id));
        self.reconcile_wifi()?;
        Ok(())
    }
    pub fn connect(&mut self, a: Endpoint, b: Endpoint) -> Result<(), String> {
        if self.project.wireless.clients.contains_key(&a.node)
            || self.project.wireless.clients.contains_key(&b.node)
        {
            return Err("Disable Wi-Fi before connecting cable".into());
        }
        if a.node == b.node {
            return Err("Self-link not supported".into());
        }
        let port = |end: &Endpoint| {
            self.port(end)
                .ok_or_else(|| format!("Unknown port {:?} on node {}", end.port, end.node))
        };
        let x = port(&a)?;
        let y = port(&b)?;
        self.lab.connect(x, y).map_err(|e| e.to_string())?;
        self.project.cables.push(Cable { ends: [a, b] });
        Ok(())
    }
    pub fn link_id(&self, c: &Cable, s: &SimulationSnapshot) -> Option<LinkId> {
        let a = self.port(&c.ends[0])?;
        let b = self.port(&c.ends[1])?;
        s.links
            .iter()
            .find(|(_, l)| l.endpoints.contains(&a) && l.endpoints.contains(&b))
            .map(|(id, _)| *id)
    }
    pub fn disconnect(&mut self, index: usize) -> Result<(), String> {
        let c = self.project.cables.get(index).ok_or("Unknown cable")?;
        let id = self
            .link_id(c, &self.lab.snapshot())
            .ok_or("Missing engine link")?;
        self.lab.disconnect(id).map_err(|e| e.to_string())?;
        self.project.cables.remove(index);
        Ok(())
    }
    pub fn configure_host(&mut self, id: u64, h: HostConfig) -> Result<(), String> {
        if self.project.services.dhcp_clients.contains(&id)
            || self.project.services.dhcp_servers.contains_key(&id)
        {
            return Err("DHCP is configured on this host".into());
        }
        self.lab
            .configure_host_ip(self.id(id)?, &h)
            .map_err(|e| e.to_string())?;
        self.project
            .nodes
            .iter_mut()
            .find(|n| n.id == id)
            .ok_or("Unknown node")?
            .host = Some(h);
        Ok(())
    }
    pub fn power(&mut self, id: u64, on: bool) -> Result<(), String> {
        self.lab
            .set_power(self.id(id)?, on)
            .map_err(|e| e.to_string())?;
        self.refresh();
        self.reconcile_wifi()?;
        Ok(())
    }
    pub fn execute(&mut self, id: u64, line: &str) -> Result<String, String> {
        if line.starts_with(":dhcp") || line.starts_with(":ospf") {
            return self.service_cli(id, line);
        }
        if self
            .node(id)
            .is_some_and(|n| n.model.host() || n.model.ap())
        {
            return self.endpoint_cli(id, line);
        }
        let output = self
            .lab
            .execute(self.id(id)?, CiscoSessionId(1), line)
            .map_err(|e| e.to_string())?;
        self.refresh();
        Ok(output)
    }
    pub fn completion(&self, id: u64, line: &str) -> Option<String> {
        self.lab
            .completion(self.engine_id(id)?, CiscoSessionId(1), line)
    }
    pub fn prompt(&self, id: u64) -> Result<String, String> {
        if let Some(n) = self.node(id).filter(|n| n.model.host() || n.model.ap()) {
            return Ok(format!("{}>", n.hostname));
        }
        self.lab
            .prompt(self.id(id)?, CiscoSessionId(1))
            .map_err(|e| e.to_string())
    }
    pub fn ping(&mut self, id: u64, dst: Ipv4Addr) -> Result<u32, String> {
        self.lab
            .ping_start(self.id(id)?, dst)
            .map_err(|e| e.to_string())
    }
    pub fn step(&mut self) -> Result<(), String> {
        let r = self.lab.step().map_err(|e| e.to_string());
        self.refresh();
        r.map(|_| ())
    }
    pub fn advance(&mut self, ns: u64) -> Result<(), String> {
        let r = self.lab.advance(ns, 4096).map_err(|e| e.to_string());
        self.refresh();
        r
    }
    pub fn snapshot(&self) -> SimulationSnapshot {
        self.lab.snapshot()
    }
    pub fn capture(&self) -> &netsim_capture::Capture {
        self.lab.capture()
    }
    pub fn trace(&self) -> TraceSnapshot {
        self.lab.trace()
    }
    fn refresh(&mut self) {
        let s = self.lab.snapshot();
        for n in &mut self.project.nodes {
            if let Some(d) = s
                .devices
                .iter()
                .find(|d| Some(&d.id) == self.ids.get(&n.id))
            {
                n.hostname = d.hostname.clone();
                n.powered = d.power == PowerState::On;
            }
        }
    }
    pub fn export(&self) -> Result<Project, String> {
        let mut p = self.project.clone();
        let snap = self.lab.snapshot();
        for n in &mut p.nodes {
            let id = self.id(n.id)?;
            let d = snap
                .devices
                .iter()
                .find(|d| d.id == id)
                .ok_or("Missing engine node")?;
            n.hostname = d.hostname.clone();
            n.powered = d.power == PowerState::On;
            n.vendor = self.lab.export_config(id)?;
        }
        p.validate()?;
        Ok(p)
    }
    /// Transactional load: construct a replacement, do not mutate the current document on error.
    pub fn from_project(p: Project) -> Result<Self, String> {
        p.validate()?;
        let mut d = Self::new(p.seed)?;
        let wireless = p.wireless;
        let services = p.services;
        for n in p.nodes {
            let id = n.id;
            d.add_node(n).map_err(|e| format!("Node {id}: {e}"))?;
        }
        for c in p.cables {
            let [a, b] = c.ends;
            d.connect(a, b)?;
        }
        for (id, ap) in wireless.aps {
            d.configure_ap(id, ap)?;
        }
        for (id, c) in wireless.clients {
            d.configure_wifi(id, Some(c))?;
        }
        for (id, pool) in services.dhcp_servers {
            d.configure_dhcp_server(id, pool)?;
        }
        for id in services.dhcp_clients {
            d.enable_dhcp(id)?;
        }
        for (id, rid) in services.ospf {
            d.enable_ospf(id, rid)?;
        }
        d.refresh();
        Ok(d)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn ep(node: u64, port: &str) -> Endpoint {
        Endpoint {
            node,
            port: port.into(),
        }
    }
    #[test]
    fn save_restore_vendor_config_and_cables() {
        let mut d = Desktop::new(42).unwrap();
        let a = d.add(Model::CiscoRouter, [10., 20.]).unwrap();
        let b = d.add(Model::EltexRouter, [100., 20.]).unwrap();
        for cmd in [
            "enable",
            "conf t",
            "hostname R1",
            "int gi0/0",
            "ip address 10.0.0.1 255.255.255.0",
            "no shut",
            "end",
            "copy run start",
        ] {
            assert!(!d.execute(a, cmd).unwrap().starts_with('%'), "{cmd}");
        }
        for cmd in [
            "configure",
            "interface gi 1/0/1",
            "ip address 10.0.0.2/24",
            "end",
            "commit",
            "confirm",
        ] {
            assert!(!d.execute(b, cmd).unwrap().starts_with('%'), "{cmd}");
        }
        d.connect(ep(a, "GigabitEthernet0/0"), ep(b, "1/0/1"))
            .unwrap();
        let p = d.export().unwrap();
        let mut other =
            Desktop::from_project(Project::decode(&p.encode().unwrap()).unwrap()).unwrap();
        assert_eq!(other.cables(), p.cables);
        assert_eq!(other.node(a).unwrap().hostname, "R1");
        other.execute(a, "enable").unwrap();
        assert!(
            other
                .execute(a, "show startup-config")
                .unwrap()
                .contains("10.0.0.1")
        );
        assert!(
            other
                .execute(b, "show running-config")
                .unwrap()
                .contains("10.0.0.2/24")
        );
    }
    #[test]
    fn host_ping_and_step() {
        let mut d = Desktop::new(42).unwrap();
        let a = d.add(Model::Pc, [0., 0.]).unwrap();
        let b = d.add(Model::Pc, [100., 0.]).unwrap();
        for (id, ip) in [(a, "10.0.0.1"), (b, "10.0.0.2")] {
            d.configure_host(
                id,
                HostConfig {
                    ip: ip.parse().unwrap(),
                    prefix: 24,
                    gateway: None,
                },
            )
            .unwrap();
        }
        d.connect(ep(a, "eth0"), ep(b, "eth0")).unwrap();
        d.advance(1_000_000_000).unwrap();
        d.ping(a, "10.0.0.2".parse().unwrap()).unwrap();
        for _ in 0..32 {
            d.step().unwrap();
        }
        let id = d.engine_id(a).unwrap();
        assert!(
            d.snapshot()
                .l3
                .nodes
                .iter()
                .find(|n| n.device == id)
                .unwrap()
                .probes
                .iter()
                .any(|p| matches!(p.status, netsim_engine::ProbeStatus::Reply { .. }))
        );
    }
    #[test]
    fn rejected_cable_and_delete() {
        let mut d = Desktop::new(1).unwrap();
        let a = d.add(Model::Pc, [0., 0.]).unwrap();
        let b = d.add(Model::Pc, [10., 0.]).unwrap();
        d.connect(ep(a, "eth0"), ep(b, "eth0")).unwrap();
        assert!(d.connect(ep(a, "eth0"), ep(b, "eth0")).is_err());
        d.remove(a).unwrap();
        assert!(d.cables().is_empty());
        assert!(d.snapshot().links.is_empty());
    }
    #[test]
    fn pending_esr_prevents_save() {
        let mut d = Desktop::new(1).unwrap();
        let a = d.add(Model::EltexRouter, [0., 0.]).unwrap();
        for cmd in ["configure", "hostname ESR2", "end", "commit"] {
            assert!(!d.execute(a, cmd).unwrap().starts_with('%'));
        }
        assert!(d.export().is_err());
        d.execute(a, "confirm").unwrap();
        assert!(d.export().is_ok());
    }
    #[test]
    fn rejects_unknown_port_on_load() {
        let mut d = Desktop::new(1).unwrap();
        let a = d.add(Model::Pc, [0., 0.]).unwrap();
        let b = d.add(Model::Pc, [0., 0.]).unwrap();
        let mut p = d.export().unwrap();
        p.cables.push(Cable {
            ends: [ep(a, "bogus"), ep(b, "eth0")],
        });
        assert!(Desktop::from_project(p).is_err());
    }
}
