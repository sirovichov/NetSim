//! One bounded background job at a time. The document is moved, never shared mutably.
use crate::desktop::Desktop;
use std::sync::mpsc::{self, Receiver, SyncSender, TryRecvError};
use std::thread::{self, JoinHandle};
pub enum Action {
    Step,
    Advance(u64),
    Cli { node: u64, line: String },
    Grade(usize),
}
pub enum Reply {
    Done,
    Cli { node: u64, output: String },
    Grade(String),
}
type Job = (Desktop, Action);
pub type Finished = (Desktop, Result<Reply, String>);
pub struct Worker {
    tx: Option<SyncSender<Job>>,
    rx: Receiver<Finished>,
    join: Option<JoinHandle<()>>,
}
impl Worker {
    pub fn new() -> Result<Self, String> {
        let (tx, jobs) = mpsc::sync_channel::<Job>(1);
        let (done, rx) = mpsc::channel();
        let join = thread::Builder::new()
            .name("netsim-desktop".into())
            .spawn(move || {
                while let Ok((mut d, a)) = jobs.recv() {
                    let result = match a {
                        Action::Step => d.step().map(|()| Reply::Done),
                        Action::Advance(ns) => d.advance(ns).map(|()| Reply::Done),
                        Action::Cli { node, line } => d
                            .execute(node, &line)
                            .map(|output| Reply::Cli { node, output }),
                        Action::Grade(index) => d.export().and_then(|p| {
                            let l = crate::beta_labs::starter(index)?;
                            let g = crate::beta_labs::grade(p, &l.checks)?;
                            Ok(Reply::Grade(format!(
                                "{}/100\n{}",
                                g.iter().map(|x| x.points).sum::<u32>(),
                                g.iter()
                                    .map(|x| format!(
                                        "{} {}",
                                        if x.passed { "PASS" } else { "FAIL" },
                                        x.label
                                    ))
                                    .collect::<Vec<_>>()
                                    .join("\n")
                            )))
                        }),
                    };
                    if done.send((d, result)).is_err() {
                        break;
                    }
                }
            })
            .map_err(|e| e.to_string())?;
        Ok(Self {
            tx: Some(tx),
            rx,
            join: Some(join),
        })
    }
    pub fn submit(&self, d: Desktop, a: Action) -> Result<(), Desktop> {
        match &self.tx {
            Some(tx) => tx.try_send((d, a)).map_err(|e| match e {
                mpsc::TrySendError::Full((d, _)) | mpsc::TrySendError::Disconnected((d, _)) => d,
            }),
            None => Err(d),
        }
    }
    pub fn poll(&self) -> Result<Option<Finished>, String> {
        match self.rx.try_recv() {
            Ok(v) => Ok(Some(v)),
            Err(TryRecvError::Empty) => Ok(None),
            Err(TryRecvError::Disconnected) => Err("Simulation worker disconnected".into()),
        }
    }
}
impl Drop for Worker {
    fn drop(&mut self) {
        self.tx.take();
        if let Some(j) = self.join.take() {
            let _ = j.join();
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn moves_document_and_advances() {
        let w = Worker::new().unwrap();
        assert!(
            w.submit(Desktop::new(42).unwrap(), Action::Advance(100))
                .is_ok()
        );
        let (d, r) =
            w.rx.recv_timeout(std::time::Duration::from_secs(5))
                .unwrap();
        r.unwrap();
        assert_eq!(d.snapshot().now, 100);
    }
}
