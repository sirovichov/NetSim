//! One simulation engine shared by Cisco and Eltex consoles.
use netsim_cisco::ios::{CiscoDevice, Model as CiscoModel};
use netsim_core::{DeviceId, EngineCommand, EngineError, PortId, SessionId};
use netsim_eltex::{EltexDevice, Model as EltexModel};
use netsim_engine::{Engine, EngineLimits, SimulationSnapshot};
use std::collections::BTreeMap;

enum Device {
    Cisco(CiscoDevice),
    Eltex(EltexDevice),
    Host(PortId),
    Ap(PortId, Vec<PortId>),
}
pub struct MixedLab {
    engine: Engine,
    devices: BTreeMap<DeviceId, Device>,
}
impl MixedLab {
    pub fn new(seed: u64) -> Result<Self, EngineError> {
        Ok(Self {
            engine: crate::create_engine(seed, EngineLimits::default())?,
            devices: BTreeMap::new(),
        })
    }
    pub fn add_cisco(&mut self, model: CiscoModel, name: &str) -> Result<DeviceId, EngineError> {
        let dev = CiscoDevice::create(&mut self.engine, model, name)?;
        let id = dev.id();
        self.devices.insert(id, Device::Cisco(dev));
        Ok(id)
    }
    pub fn add_eltex(&mut self, model: EltexModel, name: &str) -> Result<DeviceId, EngineError> {
        let dev = EltexDevice::create(&mut self.engine, model, name)?;
        let id = dev.id();
        self.devices.insert(id, Device::Eltex(dev));
        Ok(id)
    }
    pub fn port(&self, id: DeviceId, name: &str) -> Option<PortId> {
        match self.devices.get(&id)? {
            Device::Cisco(d) => d.port(name),
            Device::Eltex(d) => d.port(name),
            Device::Host(p) => (name == "eth0").then_some(*p),
            Device::Ap(p, _) => (name == "eth0").then_some(*p),
        }
    }
    pub fn connect(&mut self, a: PortId, b: PortId) -> Result<(), EngineError> {
        self.engine.execute(EngineCommand::ConnectPorts {
            endpoints: [a, b],
            bandwidth_bps: 100_000_000,
            delay_ns: 1000,
            loss_ppm: 0,
            queue_limit_bytes: 65536,
        })?;
        Ok(())
    }
    pub fn prompt(&self, id: DeviceId, session: SessionId) -> Result<String, EngineError> {
        Ok(
            match self.devices.get(&id).ok_or(EngineError::UnknownDevice)? {
                Device::Cisco(d) => d.prompt(session),
                Device::Eltex(d) => d.prompt(session),
                Device::Host(_) => "PC>".into(),
                Device::Ap(..) => "WEP>".into(),
            },
        )
    }
    fn expire(&mut self) -> Result<(), EngineError> {
        for d in self.devices.values_mut() {
            if let Device::Eltex(d) = d {
                d.expire(&mut self.engine)
                    .map_err(|_| EngineError::DeviceFault)?;
            }
        }
        Ok(())
    }
    fn next_deadline(&self) -> Option<u64> {
        self.devices
            .values()
            .filter_map(|d| match d {
                Device::Eltex(d) => d.deadline(),
                _ => None,
            })
            .min()
    }
    pub fn execute(
        &mut self,
        id: DeviceId,
        session: SessionId,
        line: &str,
    ) -> Result<String, EngineError> {
        self.expire()?;
        if !self
            .engine
            .snapshot()
            .devices
            .iter()
            .any(|d| d.id == id && d.power == netsim_core::PowerState::On)
        {
            return Err(EngineError::InvalidState);
        }
        // Existing Cisco diagnostics advance time internally. Do not let them
        // cross an outstanding ESR deadline without dispatching its rollback.
        let first = line
            .split_whitespace()
            .next()
            .unwrap_or("")
            .to_ascii_lowercase();
        let second = line
            .split_whitespace()
            .nth(1)
            .unwrap_or("")
            .to_ascii_lowercase();
        let diagnostic =
            |s: &str| !s.is_empty() && ("ping".starts_with(s) || "traceroute".starts_with(s));
        if self.next_deadline().is_some()
            && (diagnostic(&first) || (first == "do" && diagnostic(&second)))
        {
            return Ok("% Confirm or restore pending ESR configuration before diagnostics".into());
        }
        Ok(
            match self
                .devices
                .get_mut(&id)
                .ok_or(EngineError::UnknownDevice)?
            {
                Device::Cisco(d) => d.execute(&mut self.engine, session, line),
                Device::Eltex(d) => d.execute(&mut self.engine, session, line),
                Device::Host(_) => "% Use host properties and ping".into(),
                Device::Ap(..) => "% Use Web UI".into(),
            },
        )
    }
    pub fn run_for(&mut self, ns: u64) -> Result<(), EngineError> {
        let end = self
            .engine
            .now()
            .checked_add(ns)
            .ok_or(EngineError::TimeOverflow)?;
        self.expire()?;
        while self.engine.now() < end {
            let at = self.next_deadline().map_or(end, |d| d.min(end));
            let report = self.engine.run_until(at, 100_000)?;
            if report.faulted || report.budget_exhausted {
                return Err(EngineError::DeviceFault);
            }
            self.expire()?;
        }
        Ok(())
    }
    pub fn add_ap(&mut self, profile: &str, name: &str) -> Result<DeviceId, EngineError> {
        if !matches!(profile, "eltex.ap.wep2ac" | "eltex.ap.wep2ac-smart") {
            return Err(EngineError::UnknownProfile);
        }
        let id = self.engine.add_device(profile, 1, name.into())?;
        let result = (|| {
            let uplink = self.engine.add_port(id, netsim_core::MediaKind::Ethernet)?;
            let b = id.0.to_be_bytes();
            self.engine.configure_switch(
                id,
                32768,
                netsim_core::MacAddress([2, 0x57, b[4], b[5], b[6], b[7]]),
            )?;
            self.engine
                .configure_switch_port(id, uplink, netsim_engine::PortMode::Access(1))?;
            let mut radios = Vec::new();
            for _ in 0..32 {
                let p = self.engine.add_port(id, netsim_core::MediaKind::Ethernet)?;
                self.engine
                    .configure_switch_port(id, p, netsim_engine::PortMode::Access(1))?;
                radios.push(p);
            }
            self.engine.power_on(id)?;
            self.devices.insert(id, Device::Ap(uplink, radios));
            Ok(id)
        })();
        if result.is_err() {
            let _ = self.engine.remove_device(id);
        }
        result
    }
    pub fn configure_ap(
        &mut self,
        id: DeviceId,
        c: &netsim_storage::ApConfig,
    ) -> Result<(), EngineError> {
        c.validate().map_err(|_| EngineError::InvalidInput)?;
        let Some(Device::Ap(port, _)) = self.devices.get(&id) else {
            return Err(EngineError::InvalidInput);
        };
        let mut allowed: std::collections::BTreeSet<u16> = c
            .vaps
            .iter()
            .filter(|v| v.enabled)
            .map(|v| v.vlan)
            .collect();
        allowed.insert(c.native_vlan);
        self.engine.set_switch_port_mode(
            id,
            *port,
            netsim_engine::PortMode::Trunk {
                native: Some(c.native_vlan),
                allowed,
            },
        )
    }
    pub fn attach_wifi(
        &mut self,
        ap: DeviceId,
        client: DeviceId,
        vlan: u16,
        rate: u64,
        loss: u32,
    ) -> Result<netsim_core::LinkId, EngineError> {
        let Some(Device::Ap(_, ports)) = self.devices.get(&ap) else {
            return Err(EngineError::InvalidInput);
        };
        let Some(Device::Host(client_port)) = self.devices.get(&client) else {
            return Err(EngineError::InvalidInput);
        };
        let snapshot = self.engine.snapshot();
        let busy = |p| snapshot.links.iter().any(|(_, l)| l.endpoints.contains(&p));
        if busy(*client_port) {
            return Err(EngineError::PortBusy);
        }
        let port = ports
            .iter()
            .copied()
            .find(|p| !busy(*p))
            .ok_or(EngineError::ResourceLimit)?;
        self.engine
            .set_switch_port_mode(ap, port, netsim_engine::PortMode::Access(vlan))?;
        match self.engine.execute(EngineCommand::ConnectPorts {
            endpoints: [port, *client_port],
            bandwidth_bps: rate,
            delay_ns: 100_000,
            loss_ppm: loss,
            queue_limit_bytes: 65536,
        })? {
            netsim_engine::CommandResult::LinkAdded(id) => Ok(id),
            _ => Err(EngineError::InvalidState),
        }
    }
    pub fn add_host(&mut self, profile: &str, name: &str) -> Result<DeviceId, EngineError> {
        if !netsim_generic::PROFILES
            .iter()
            .any(|entry| entry.profile_id == profile)
        {
            return Err(EngineError::UnknownProfile);
        }
        let id = self.engine.add_device(profile, 1, name.into())?;
        let result = (|| {
            let p = self.engine.add_port(id, netsim_core::MediaKind::Ethernet)?;
            self.engine.power_on(id)?;
            self.devices.insert(id, Device::Host(p));
            Ok(id)
        })();
        if result.is_err() {
            let _ = self.engine.remove_device(id);
        }
        result
    }
    pub fn configure_host_ip(
        &mut self,
        id: DeviceId,
        h: &netsim_storage::HostConfig,
    ) -> Result<(), EngineError> {
        let Device::Host(p) = self.devices.get(&id).ok_or(EngineError::UnknownDevice)? else {
            return Err(EngineError::InvalidInput);
        };
        let p = *p;
        let b = p.0.to_be_bytes();
        let config = netsim_engine::InterfaceConfig {
            key: netsim_engine::InterfaceKey {
                port: p,
                vlan: None,
            },
            address: h.ip,
            prefix_len: h.prefix,
            mac: netsim_core::MacAddress([2, 0x48, b[4], b[5], b[6], b[7]]),
        };
        if self
            .engine
            .snapshot()
            .l3
            .nodes
            .iter()
            .any(|n| n.device == id)
        {
            return self.engine.update_ipv4_host(id, config, h.gateway);
        }
        if !config.valid()
            || h.gateway.is_some_and(|g| {
                g == h.ip
                    || !config
                        .prefix()
                        .is_some_and(|p| netsim_protocols::routing::usable(p, g))
            })
        {
            return Err(EngineError::InvalidInput);
        }
        let on = self
            .engine
            .snapshot()
            .devices
            .iter()
            .any(|d| d.id == id && d.power == netsim_core::PowerState::On);
        if on {
            self.engine.power_off(id)?;
        }
        let result = self.engine.configure_ipv4_host(id, config, h.gateway);
        if on {
            self.engine.power_on(id)?;
        }
        result
    }
    pub fn dhcp_client(&mut self, id: DeviceId) -> Result<(), EngineError> {
        let Some(Device::Host(p)) = self.devices.get(&id) else {
            return Err(EngineError::InvalidInput);
        };
        self.engine.enable_dhcp_client(id, *p)
    }
    pub fn dhcp_server(
        &mut self,
        id: DeviceId,
        p: &netsim_storage::DhcpPool,
    ) -> Result<(), EngineError> {
        self.engine.enable_dhcp_server(
            id,
            netsim_engine::DhcpPool {
                first: p.first,
                last: p.last,
                prefix: p.prefix,
                gateway: p.gateway,
                lease_secs: p.lease_secs,
            },
        )
    }
    pub fn ospf(&mut self, id: DeviceId, rid: std::net::Ipv4Addr) -> Result<(), EngineError> {
        self.engine.enable_ospf(id, rid)
    }
    pub fn dhcp_status(&self) -> Vec<netsim_engine::DhcpStatus> {
        self.engine.dhcp_status()
    }
    pub fn ospf_status(&self) -> Vec<netsim_engine::OspfStatus> {
        self.engine.ospf_status()
    }
    pub fn ping_start(
        &mut self,
        id: DeviceId,
        dst: std::net::Ipv4Addr,
    ) -> Result<u32, EngineError> {
        self.expire()?;
        self.engine.ping(id, dst, 64, 5_000_000_000)
    }
    pub fn completion(&self, id: DeviceId, session: SessionId, line: &str) -> Option<String> {
        match self.devices.get(&id)? {
            Device::Cisco(d) => d.complete_line(session, line),
            _ => None,
        }
    }
    pub fn export_config(&self, id: DeviceId) -> Result<Option<serde_json::Value>, String> {
        match self.devices.get(&id).ok_or("Unknown device")? {
            Device::Cisco(d) => Ok(Some(d.export_config())),
            Device::Eltex(d) => d.export_config().map(Some),
            Device::Host(_) | Device::Ap(..) => Ok(None),
        }
    }
    pub fn import_config(&mut self, id: DeviceId, value: serde_json::Value) -> Result<(), String> {
        match self.devices.get_mut(&id).ok_or("Unknown device")? {
            Device::Cisco(d) => d.import_config(&mut self.engine, value),
            Device::Eltex(d) => d.import_config(&mut self.engine, value),
            Device::Host(_) | Device::Ap(..) => Err("Use device properties".into()),
        }
    }
    pub fn disconnect(&mut self, id: netsim_core::LinkId) -> Result<(), EngineError> {
        self.engine.disconnect(id)
    }
    pub fn set_power(&mut self, id: DeviceId, on: bool) -> Result<(), EngineError> {
        if self
            .devices
            .get(&id)
            .is_some_and(|d| matches!(d,Device::Eltex(e) if e.deadline().is_some()))
        {
            return Err(EngineError::InvalidState);
        }
        if on {
            self.engine.power_on(id)
        } else {
            self.engine.power_off(id)
        }
    }
    pub fn step(&mut self) -> Result<Option<netsim_engine::ProcessedEvent>, EngineError> {
        self.expire()?;
        if let Some(deadline) = self.next_deadline() {
            if self.engine.next_event_time().is_none_or(|t| t > deadline) {
                self.engine.run_until(deadline, 0)?;
                self.expire()?;
                return Ok(None);
            }
        }
        let event = self.engine.step();
        if self
            .engine
            .next_event_time()
            .is_none_or(|t| t > self.engine.now())
        {
            self.expire()?;
        }
        if event
            .as_ref()
            .is_some_and(|e| matches!(e.outcome, netsim_engine::Outcome::Failed(_)))
        {
            return Err(EngineError::DeviceFault);
        }
        Ok(event)
    }
    pub fn capture(&self) -> &netsim_capture::Capture {
        self.engine.capture()
    }
    pub fn trace(&self) -> netsim_engine::TraceSnapshot {
        self.engine.trace()
    }
    /// Bounded real-time tick; UI can resume at the next frame if budget exhausted.
    pub fn advance(&mut self, ns: u64, budget: usize) -> Result<(), EngineError> {
        self.expire()?;
        let end = self
            .engine
            .now()
            .checked_add(ns)
            .ok_or(EngineError::TimeOverflow)?;
        let mut remaining = budget;
        loop {
            let stop = self
                .next_deadline()
                .map_or(end, |deadline| deadline.min(end));
            let report = self.engine.run_until(stop, remaining)?;
            if report.faulted {
                return Err(EngineError::DeviceFault);
            }
            if report.budget_exhausted {
                break;
            }
            remaining -= report.events.len();
            self.expire()?;
            if stop == end {
                break;
            }
        }
        Ok(())
    }
    pub fn snapshot(&self) -> SimulationSnapshot {
        self.engine.snapshot()
    }
    pub fn remove(&mut self, id: DeviceId) -> Result<(), EngineError> {
        self.engine.remove_device(id)?;
        self.devices.remove(&id);
        Ok(())
    }
}
pub fn eltex_demo() -> Result<String, EngineError> {
    let mut l = MixedLab::new(42)?;
    let a = l.add_cisco(CiscoModel::Isr2911, "R1")?;
    let b = l.add_eltex(EltexModel::Esr100, "ESR")?;
    let s = l.add_eltex(EltexModel::Mes2428, "MES")?;
    let p = |l: &MixedLab, id, n| l.port(id, n).ok_or(EngineError::UnknownPort);
    let ends = [
        (p(&l, a, "Gi0/0")?, p(&l, s, "gi1/0/1")?),
        (p(&l, b, "gi1/0/1")?, p(&l, s, "gi1/0/2")?),
    ];
    for (x, y) in ends {
        l.connect(x, y)?;
    }
    let session = SessionId(1);
    for (id, commands) in [
        (
            a,
            vec![
                "enable",
                "conf t",
                "int gi0/0",
                "ip address 10.10.10.1 255.255.255.0",
                "no shut",
                "end",
            ],
        ),
        (
            b,
            vec![
                "configure",
                "interface gigabitethernet 1/0/1",
                "ip address 10.10.10.2/24",
                "exit",
                "exit",
                "commit",
                "confirm",
            ],
        ),
        (
            s,
            vec![
                "enable",
                "configure terminal",
                "vlan 10",
                "exit",
                "interface gigabitethernet 1/0/1",
                "switchport mode access",
                "switchport access vlan 10",
                "exit",
                "interface gigabitethernet 1/0/2",
                "switchport mode access",
                "switchport access vlan 10",
                "end",
                "write startup-config",
            ],
        ),
    ] {
        for cmd in commands {
            if l.execute(id, session, cmd)?.starts_with('%') {
                return Err(EngineError::InvalidInput);
            }
        }
    }
    l.run_for(40_000_000_000)?;
    let ping = l.execute(a, session, "ping 10.10.10.2")?;
    if !ping.contains("100 percent") {
        return Err(EngineError::DeviceFault);
    }
    Ok(format!(
        "{ping}\n{}\nCisco/Eltex simulation successful",
        l.execute(s, session, "show mac-address-table")?
    ))
}
