//! Draft model identities only. No firmware or protocol implementation.

use netsim_devices::DeviceDescriptor;

pub const PROFILES: &[DeviceDescriptor] = &[
    DeviceDescriptor {
        profile_id: "generic.host.pc",
        profile_version: 1,
        vendor: "Generic",
        model: "PC",
        firmware_reference: None,
    },
    DeviceDescriptor {
        profile_id: "generic.host.laptop",
        profile_version: 1,
        vendor: "Generic",
        model: "Laptop",
        firmware_reference: None,
    },
    DeviceDescriptor {
        profile_id: "generic.host.server",
        profile_version: 1,
        vendor: "Generic",
        model: "Server",
        firmware_reference: None,
    },
];
