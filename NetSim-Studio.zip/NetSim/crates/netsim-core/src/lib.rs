//! Cross-crate events, commands and structured errors; no I/O or wall clock.

pub use netsim_types::*;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum EventKind {
    PacketReceive {
        port: PortId,
        packet: PacketId,
        link: LinkId,
        link_generation: u64,
    },
    FrameReceive {
        port: PortId,
        packet: PacketId,
        link: LinkId,
        source: PortId,
        source_generation: u64,
        bytes: std::sync::Arc<[u8]>,
    },
    L2Tick,
    L3Tick,
    TimerExpired {
        timer: TimerId,
        generation: u64,
    },
    LinkChanged {
        link: LinkId,
        up: bool,
    },
    DeviceBoot,
    DeviceShutdown,
    CliCommand {
        session: SessionId,
        command: String,
    },
    ConfigChanged,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SimEvent {
    pub at: SimTime,
    pub sequence: u64,
    pub target: DeviceId,
    pub generation: u64,
    pub kind: EventKind,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum EngineCommand {
    AddDevice {
        profile_id: String,
        profile_version: u32,
        hostname: String,
    },
    RemoveDevice(DeviceId),
    ConnectPorts {
        endpoints: [PortId; 2],
        bandwidth_bps: u64,
        delay_ns: SimTime,
        loss_ppm: u32,
        queue_limit_bytes: u64,
    },
    DisconnectLink(LinkId),
    ApplyConfig {
        device: DeviceId,
        config_schema_version: u32,
        document: String,
    },
    SendPacket {
        source: DeviceId,
        destination: std::net::Ipv4Addr,
    },
    PowerOn(DeviceId),
    PowerOff(DeviceId),
    Reboot(DeviceId),
    ExecuteCli {
        device: DeviceId,
        session: SessionId,
        command: String,
    },
    Reset,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum EngineError {
    PastEvent,
    QueueFull,
    SequenceExhausted,
    Unsupported,
    UnknownDevice,
    UnknownProfile,
    DuplicateProfile,
    InvalidInput,
    InvalidState,
    UnknownPort,
    UnknownLink,
    PortBusy,
    ResourceLimit,
    TimeOverflow,
    DeviceFault,
    WorkerClosed,
}

impl std::fmt::Display for EngineError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::PastEvent => f.write_str("event precedes virtual time"),
            Self::QueueFull => f.write_str("event queue capacity reached"),
            Self::SequenceExhausted => f.write_str("event sequence exhausted"),
            Self::Unsupported => f.write_str("operation not implemented"),
            Self::UnknownDevice => f.write_str("unknown device"),
            Self::UnknownProfile => f.write_str("unknown profile or version"),
            Self::DuplicateProfile => f.write_str("profile already registered"),
            Self::InvalidInput => f.write_str("invalid input"),
            Self::InvalidState => f.write_str("invalid device state"),
            Self::UnknownPort => f.write_str("unknown port"),
            Self::UnknownLink => f.write_str("unknown link"),
            Self::PortBusy => f.write_str("port already connected"),
            Self::ResourceLimit => f.write_str("resource limit reached"),
            Self::TimeOverflow => f.write_str("virtual time overflow"),
            Self::DeviceFault => f.write_str("device handler failed"),
            Self::WorkerClosed => f.write_str("simulation worker closed"),
        }
    }
}

impl std::error::Error for EngineError {}
