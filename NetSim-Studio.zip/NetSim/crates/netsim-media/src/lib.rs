//! Virtual-media arithmetic; no real network sockets.

/// Serialization time in ns, rounded up. Returns None on zero rate or overflow.
pub fn serialization_delay_ns(bytes: u64, rate_bps: u64) -> Option<u64> {
    if rate_bps == 0 {
        return None;
    }
    let bits_ns = u128::from(bytes) * 8 * 1_000_000_000;
    u64::try_from(bits_ns.div_ceil(u128::from(rate_bps))).ok()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rounds_up_and_checks_rate() {
        assert_eq!(serialization_delay_ns(1000, 1_000_000_000), Some(8000));
        assert_eq!(serialization_delay_ns(1, 3_000_000_000), Some(3));
        assert_eq!(serialization_delay_ns(1, 0), None);
        assert_eq!(serialization_delay_ns(u64::MAX, 1), None);
    }
}
