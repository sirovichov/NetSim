# Device evidence

Use the supplied WEP-2ac/WEP-2ac Smart manual 1.25.0, pp. 2–4 for menu names.
Cisco ICND1/ICND2 course materials are educational scans and not model-specific
conformance evidence. MES2428/ESR-100 exact documentation and firmware remain open.
Each profile must obtain a conformance CSV before vendor behavior is accepted.
No supplied PDF is included in this repository.
