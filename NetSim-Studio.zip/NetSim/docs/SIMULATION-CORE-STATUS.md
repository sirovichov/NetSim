# Simulation Core — v0.0.2 (pending compiler verification)

## Implemented source

- Single-owner `Engine`, versioned profile factories, monotonically allocated device/port/link IDs.
- Off/On lifecycle, synchronous boot/shutdown at the current virtual timestamp,
  reboot invalidates old device work. Removal drops the instance (no shutdown callback).
- Queue dispatch by `(at, sequence)`; timer replacement/cancellation removes old entries
  immediately. Device generation, timer token and non-reused link ID protect against stale work.
- `DeviceContext` exposes virtual time, deterministic RNG, local port/link attachment and
  a bounded list of timer requests. Last request per timer wins; remaining requests are
  applied in order of their final occurrence. All timer effects are validated as a batch.
- SplitMix64 v1: master seed -> one derived seed per callback, then independent draws
  in that callback. No OS RNG or wall clock.
- Bounded ring trace with count of overwritten entries, event type, IDs and outcome;
  raw CLI commands, CLI output and packet payloads are not recorded.
- Immutable read-only snapshots (owned data; latest worker snapshot is an `Arc`).
- Worker has a bounded command queue, individual reply channels, nonblocking submission,
  explicit shutdown and maximum run batch of 4096 events. No autonomous real-time pacing.
- Basic structural point-to-point wired links and explicit ports; link generation is
  its monotonically allocated ID. Notifications describe attachment, not physical carrier.
  Receive events carry only an opaque packet ID; there is no wire transmission/packet store.
- CLI requests dispatch to model handlers; unsupported draft CLI returns an error without
  powering the device off.

## Semantics and fault handling

Commands are applied at current virtual time between events. Boot/shutdown callbacks
are synchronous lifecycle operations, separately logged; timers and receive/CLI/link
notifications use the event queue. Boot sees existing local port attachments. Shutdown
effects are discarded, and queued work targeting the instance is purged. Power-on increments
the instance generation. Reboot is shutdown followed by boot, only for powered-on instances.
Reset clears state, trace and virtual clock, restarts RNG and event sequence, retains profiles
and all monotonic allocation counters. Reset starts a new epoch; old event sequences are not
valid in the new epoch.

Queue-full on externally requested operations rejects the operation before mutation.
A handler error or failure to commit its timer effects quarantines that instance (Off),
purges its pending work and stops the current `run_until` batch. Model-internal state
is not transactional; the next boot must reset volatile state. Ordinary unsupported CLI is
not considered a fatal handler error. Handler panics are not isolated; model implementations
are trusted Rust code, not arbitrary external plugins. Timer cancellation is idempotent.
Event budget includes skipped events. Zero-delay events cannot bypass the budget.
A discarded worker reply receiver does not cancel an accepted request. Concurrent producer
ordering is defined by arrival at the channel; replay requires the same ordered inputs.
Worker shutdown stops accepting work; pending requests after shutdown receive a disconnected
reply. Trace excludes raw CLI data, but callers must also avoid logging command/results themselves.

## Known gaps

Nine profile identities remain draft lifecycle-only instances without vendor-specific ports,
CLI semantics or protocols. `ApplyConfig` and `SendPacket` return `Unsupported`. Packet
serialization, Ethernet forwarding, physical carrier/propagation and protocol state machines
are WP3/WP4. Project persistence, full checkpoints, GUI, real-time pacing and session
management remain later milestones. Snapshot includes only public instance metadata and
active timer deadlines, not restorable private protocol state. Topology lookups and queue
purging use simple scans; performance targets are not yet measured.

## Verification

Static repository checks, JSON Schema validation, workflow YAML parse and ZIP integrity
are performed at delivery. Rust 1.85.1 remains pinned; cargo, rustc and rustfmt were not
available locally. Run `cargo fmt --all` before committing; new source has not been normalized by rustfmt.
No compilation, formatting check, clippy, Rust test execution,
cross-platform run or GitHub release has been verified. Run CI before accepting WP2.

Delivery checks: repository checker PASS; two JSON Schemas, nine profiles and empty project PASS; two workflow YAML files parsed. 28 Rust tests present (14 retained, 14 new), not executed.
