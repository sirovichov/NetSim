# v0.0.3 — L2 Networking

Исходный код поверх v0.0.2, ожидает компиляции и запуска тестов.

## Основные файлы

| Crate | Файлы | Назначение |
|---|---|---|
| netsim-packet | ethernet.rs | Ethernet II, 802.3 length/LLC, одна метка 802.1Q |
| netsim-protocols | arp.rs | ARP request/reply, кэш |
| netsim-protocols | bridge.rs | MAC-learning, VLAN, BPDU, дерево и состояния портов |
| netsim-engine | engine/l2.rs | виртуальная доставка, привязка компонентов, L2 snapshots |
| netsim-engine | engine.rs, worker.rs | интеграция с DES, жизненным циклом и worker |
| netsim-app | tests/l2.rs | интеграционные тесты |

## Использование

```
cargo run --locked --offline -p netsim-cli -- l2-demo
cargo test --locked --offline -p netsim-app --test l2
cargo test --workspace --locked --offline
```

Ожидаемый финальный вывод демо: `ARP resolution successful`.
Это ожидаемый результат, не журнал выполненной сборки.

### API

```rust
use netsim_app::create_engine;
use netsim_core::{EngineCommand, MacAddress, MediaKind};
use netsim_engine::{EngineLimits, PortMode};
use std::net::Ipv4Addr;

fn main() -> Result<(), netsim_core::EngineError> {
    let mut e = create_engine(42, EngineLimits::default())?;
    let a = e.add_device("generic.host.pc", 1, "PC1".into())?;
    let b = e.add_device("generic.host.pc", 1, "PC2".into())?;
    let s = e.add_device("cisco.switch.2960", 1, "SW".into())?;
    let pa = e.add_port(a, MediaKind::Ethernet)?;
    let pb = e.add_port(b, MediaKind::Ethernet)?;
    let p1 = e.add_port(s, MediaKind::Ethernet)?;
    let p2 = e.add_port(s, MediaKind::Ethernet)?;
    let ip2 = Ipv4Addr::new(10,0,0,2);
    e.configure_host(a, pa, Ipv4Addr::new(10,0,0,1), MacAddress([2,0,0,0,0,1]))?;
    e.configure_host(b, pb, ip2, MacAddress([2,0,0,0,0,2]))?;
    e.configure_switch(s, 32768, MacAddress([2,0,0,0,0,3]))?;
    for port in [p1,p2] {
        e.configure_switch_port(s, port, PortMode::Access(10))?;
    }
    for endpoints in [[pa,p1],[pb,p2]] {
        e.execute(EngineCommand::ConnectPorts {
            endpoints, bandwidth_bps: 100_000_000, delay_ns: 100,
            loss_ppm: 0, queue_limit_bytes: 65536,
        })?;
    }
    for id in [a,b,s] { e.power_on(id)?; }
    e.run_until(40_000_000_000, 1000)?;
    e.request_arp(a, ip2)?;
    e.run_until(41_000_000_000, 1000)?;
    assert_eq!(e.arp_lookup(a, ip2), Some(MacAddress([2,0,0,0,0,2])));
    println!("{:?}", e.snapshot().l2);
    Ok(())
}
```

В `WorkerRequest` доступны ConfigureSwitch, ConfigureSwitchPort, ConfigureHost,
SendFrame, RequestArp. Результаты отправки FrameTx возвращают время доставки
либо причину сброса; запланированный кадр всё ещё может быть отменён при отключении.

## Правила моделирования

- Размер полезной нагрузки до 1500 байт. Пакет хранится без FCS/преамбулы,
  но время линии включает padding до минимального кадра, FCS, преамбулу/SFD и IFG.
  Для направления `finish = max(now, last_finish) + ceil(wire_bytes*8*1e9/rate)`;
  время приёма равно `finish + propagation`. Очереди full-duplex независимы.
- Очередь ограничена параметром link.queue_limit_bytes (в wire bytes) и 4096
  резервированиями на направление; потерянный в линии кадр тоже занимает
  время передачи. RNG фиксирован. Событие получает PacketId отдельной L2
  последовательности, сбрасываемой при Reset. Это ID передачи, не сквозной ID PDU.
  Оpaque PacketReceive из v0.0.2 оставлен для прежних моделей.
- MAC-таблица `(VLAN, MAC) -> порт`, срок жизни 300 виртуальных секунд,
  8192 записей на коммутатор. Неизвестный unicast, multicast и broadcast
  распространяются в пределах VLAN; известный unicast на входной порт не
  пересылается. Зарезервированные link-local MAC не пересылаются.
- Access принимает untagged и priority-tagged (VID 0); trunk принимает
  разрешённые VLAN, untagged только при указанном native VLAN. На access
  метка снимается; на trunk native VLAN передаётся без метки. VLAN 1..4094.
- ARP IPv4 на одном Ethernet-интерфейсе хоста, cache 60 виртуальных секунд,
  не более 1024 записей. Явный request_arp, автоматический reply, пассивное
  обновление известных/адресованных записей. Нет маски подсети, маршрутизации,
  автоматических повторов, разрешения next hop или очереди IPv4 на время ARP.
- STP использует конфигурационные BPDU с LLC, bridge ID, root ID, path cost,
  port ID и message age. Один общий spanning tree; стоимость каждого порта 19,
  hello 2 с, max age 20 с, listening 15 с, learning 15 с. При изменении
  root/role происходит консервативная блокировка и очистка MAC.
  Root выбирается локально по полученным BPDU, не по глобальному графу.
- При выключении устройства/удалении кабеля доставка отменяется или
  инвалидируется; состояние L2 очищается при reboot, настройки остаются.
- Снимки L2 содержат последние принятые кадры хостов. Журнал событий
  ограничен и не хранит сырые payload/CLI; снимки не являются checkpoint.

## Ограничения / не входит в этап

STP — учебное подмножество, без TCN/TCA, PVST+/RSTP/MSTP, PortFast, guard,
изменения таймеров и стоимости порта, полной проверки соответствия IEEE 802.1D.
Гарантия отсутствия петель при произвольных потерях BPDU не заявляется;
ограничения очереди и бюджет событий защищают выполнение от неограниченного шага.
Нет FCS validation, QinQ, jumbo, collision/half-duplex, Ethernet autonegotiation,
IPv4/ICMP, IP forwarding, DHCP, OSPF, GUI, PCAP, IOS/Eltex CLI.
Общий L2-компонент одинаков для Cisco и Eltex; модели не подтверждены на
физическом оборудовании. Конфигурация портов доступна только в состоянии Off.
Нагрузочные испытания и кроссплатформенная проверка не выполнены.

## Приёмка

Rust-тесты: 42 функции `#[test]` (28 сохранено, 14 добавлено).
Статические проверки: манифесты, lockfile, 20 crates, 9 черновых профилей,
схемы JSON, YAML и ZIP. Cargo, rustfmt, clippy отсутствуют в среде подготовки.
Перед публикацией запустить `cargo fmt --all`, CI, исправить замечания и
повторить проверки. Не ставить релизный тег до успешного CI.

## Ссылки на протоколы

- ARP: RFC 826, https://www.rfc-editor.org/rfc/rfc826
- IEEE 802.1Q и исторический 802.1D: нормативные ориентиры, полная
  проверка соответствия не выполнена. Учебный алгоритм описан в ADR-004.
