# ADR-008 — Native desktop and project schema v2

Status: implemented in source, pending compilation.

Use eframe with OpenGL backend and a UI-independent Desktop controller on
MixedLab. The controller maps stable document IDs to runtime device IDs.
Do not duplicate packet processing in the GUI; render snapshots and FrameTx
trace entries. Use bounded time advances on the GUI thread for the first
desktop implementation. A worker owning MixedLab is deferred; this deviates
from SPEC-001 and prevents a claim of production-grade responsiveness.

Persist typed vendor configurations and host settings; regenerate runtime
port identities, MAC addresses, forwarding tables and timers on load.
Reject pending ESR commits rather than persist an incomplete rollback state.
Schema v2 supersedes the draft v1; only the old empty template is migrated.
A new dependency lockfile must be generated and committed after verification.
