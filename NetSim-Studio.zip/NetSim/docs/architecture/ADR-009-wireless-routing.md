# ADR-009 — Educational wireless and dynamic routing

Status: proposed implementation, unverified by compiler.

- Reuse DES Ethernet link/bridge machinery for each associated client.
- Persist settings independently of transient wireless links and protocol state.
- Handle DHCP packets before L3 unicast filtering, including unconfigured hosts.
- Use separate local LSDBs and SPF; prohibit direct inspection of the global graph for routing.
- Use a native subset of Eltex management views rather than an HTTP server.
- Preserve v0.0.7 dependencies and schema migration. No actual network sockets.
- Limitations and manual page references: ../WIRELESS-ROUTING-STATUS.md.
