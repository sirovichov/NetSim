# ADR-010 — Beta infrastructure

## Decision
Capture records store the bytes accepted by the virtual egress queue. A ring
of 4096 records bounds memory. Classic nanosecond PCAP is Ethernet-only and
does not encode simulator link IDs, loss flags or actual physical timestamps.
The packet inspector reports only decoded protocol layers.

A lab is a typed catalog entry with a generated starter and reference topology;
grading reconstructs the project, advances virtual time and actively probes
connectivity. Project IDs are part of the exercise identity. No arbitrary scripts
from a lab file are executed. No vendor PDFs are redistributed.

Desktop ownership moves to a bounded worker for advance, CLI and grade jobs.
The GUI temporarily shows a busy indicator; topology mutations are synchronous.
Undo/Redo stores up to 32 project snapshots, not engine snapshots. ESR pending
commit prevents checkpoint/export. Restore discards transient state.

## Consequences
Native vendor DHCP/OSPF configuration is not implemented. Service CLI is explicitly
namespaced. Lab reference tests and cross-platform builds must pass before release.
