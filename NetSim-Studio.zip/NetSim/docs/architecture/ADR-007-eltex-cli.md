# ADR-007 — Eltex management and mixed-vendor lab

Status: implemented in source, pending validation.

Use independent Eltex command dispatch and typed configuration, not Cisco CLI
translation. MES configuration changes apply immediately. ESR has candidate,
running, simulated boot configuration and a pending confirmation deadline.
MixedLab owns one engine and dispatches commands by vendor; the existing CiscoLab
is unchanged. Reuse the L2 bridge, route table, ARP and frame event mechanisms.

Tradeoffs: configuration structure is local to each vendor for now (future
refactor toward a neutral management model); expiry is coordinated by the
application rather than registered as an engine event. Direct low-level Engine
and Worker calls do not manage Eltex lifecycle. Config is in memory.
MES SVI and ESR switchport mode are deferred. No additional Rust dependencies.
