# ADR-002: Versioned device profiles

Status: accepted design, draft schema.

Profile ID and version select a model, CLI family, ports and capabilities.
Generic protocol components are shared; vendor-specific syntax and defaults are
separate. In Foundation, all profiles are draft, ports intentionally unspecified,
implemented_features empty. WEP firmware reference 1.25.0 identifies the supplied
manual, not a tested implementation. JSON is currently descriptive; application
registry uses Rust constants. WP2/WP5/WP6/WP8 add factories, verified profiles,
deserialization and conformance tests. Never mark a planned feature implemented
until acceptance tests and evidence exist.
