# ADR-006: Cisco CLI as management adapter

Status: proposed implementation, pending compiler/CI verification.

The engine retains vendor-neutral APIs and no dependency on Cisco.
`netsim-cisco` depends on engine, and `netsim-app` composes them.
The adapter owns typed running/startup configuration and per-session CLI state.
Engine remains authoritative for topology, link/port status, MAC/ARP/RIB and traffic.
A single-owner application calls management operations at virtual event boundaries.
Changing a port purges queued Ethernet frames involving it; bridge convergence
is restarted for changed ports. A router config replacement validates the entire
candidate interface and directly reachable route set before committing, then
flushes dynamic IPv4 state and resynchronizes carrier. Old powered-off APIs stay.
VLAN database and trunk policy are mapped into bridge port modes; effective
allowed VLANs are the intersection with the local VLAN database.

Alternative considered: placing Cisco grammar in Engine or implementing CLI
callbacks that read global state. Rejected to avoid vendor dependencies and
duplicate state in protocol models. Existing worker API does not expose Cisco
session ownership; a future app-level worker can call this adapter.
