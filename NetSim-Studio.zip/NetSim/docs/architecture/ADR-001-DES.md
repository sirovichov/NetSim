# ADR-001: Deterministic discrete-event simulation

Status: accepted design, implemented for Simulation Core subject to CI; see ADR-003 for operational details.

Use a single owner of simulation state; events ordered by (virtual nanoseconds,
monotonic sequence). BinaryHeap with reversed key, bounded queue and event budgets.
No wall-clock access in protocol code; real-time pacing is a future worker concern.
No direct recursive delivery. WP2 adds device/link/timer generations, dispatch,
seeded versioned RNG, snapshots, trace and bounded worker channels.
Alternative: one OS thread per device; rejected for reproducibility and overhead.
