# ADR-003: Instance lifecycle and deferred effects

Status: accepted for v0.0.2, pending compiler/CI validation.

The engine owns all instances, topology, timer tokens, scheduler, RNG and trace.
A model callback can inspect only local port attachments and request timer changes.
Deferred timer effects are validated together and applied after the callback;
no recursive delivery or global topology access. Handler failure quarantines the model,
rather than claiming rollback of arbitrary Rust state.

Lifecycle commands are synchronous at event boundaries; virtual timer and network
notifications are ordered by the scheduler. Non-reused link IDs double as generation
tokens. Link attachment notifications are structural, not carrier simulation.

Use `BTreeMap` for iteration that influences ordering. Use a fixed SplitMix64
algorithm and explicit master seed. Retain old scheduler API for Foundation compatibility.
The worker owns Engine on one OS thread, with bounded requests and a private reply
channel per request. Latest snapshots may replace previous ones without dropping replies.
No dependencies beyond the standard library are introduced at this milestone.
