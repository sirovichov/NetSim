# v0.0.8 Wireless & Routing — implementation notes

Status: source implementation; compiler and runtime tests not available in the authoring environment.

## Reference and scope
Eltex WEP-2ac / WEP-2ac Smart, user manual 1.25.0 (attached, not redistributed):
- pp. 7–9: one Ethernet uplink, two radios (5 GHz and 2.4 GHz), 32 VAP total.
- pp. 42, 45–47: Ethernet Settings, Radio, Radio 1 = 5 GHz, Radio 2 = 2.4 GHz, channel lists.
- pp. 55–58: VAP, 16 per radio, VLAN ID, SSID, Broadcast SSID, WPA Personal, WPA2-AES, 8–63 character Key, Update.
- p. 31: Status / Client Associations.
- p. 59: minimal signal is a configurable device feature; the simulator instead uses a fixed educational threshold.

The native UI reproduces a **subset of settings and names** from the manual, not the original
HTML or HTTP API. It does not implement administration login, management IP, PoE,
SNMP, enterprise auth, RADIUS, WDS, Mesh, roaming protocols or the whole web menu.
Both models use the same forwarding model; Smart-specific antenna/mesh behavior is deferred.

## Radio model
Desktop coordinates are interpreted as metres. The simulated RSSI is
`-35 - 20*log10(max(distance_m,1)) - band_penalty`, band penalty 7 dB on 5 GHz
and zero on 2.4 GHz; threshold -82 dBm. These are **design assumptions**, not
manufacturer RF measurements. The strongest matching enabled VAP is selected,
ties by project ID/VAP number. SSID and optional PSK must match, including hidden SSIDs
when supplied manually. Radio channel is saved and displayed but no co-channel
interference, scanning frames, DFS or automatic channel selection is modeled.
A client has one active logical port, wired or wireless. The AP has up to 32
simultaneous virtual client ports (implementation cap, not hardware capacity).
Each connection is a DES link with fixed 54 or 86 Mbit/s, 100 us propagation,
per-direction serialization queues and loss=0. The existing L2 bridge maps access
VLANs to the uplink native/tagged VLANs, preserving broadcast and MAC learning.
STP can require 30+ simulated seconds before forwarding starts. Power changes,
position changes and AP configuration changes cause association reconciliation.
PSK checks are simple string equality: no PBKDF2, AES, four-way handshake,
management frame simulation or real wireless networking. Never use real PSKs.

## DHCPv4
BOOTP header, UDP ports 67/68, broadcast IPv4 and MAC, DHCP magic cookie,
options 53/54/50/1/3/51 and End. IPv4 UDP checksum zero (allowed).
Client state machine Selecting -> Requesting -> Bound, 4-second discovery retry,
leases expire in virtual time. Lease expiry removes the IPv4 address and restarts
DORA; no T1/T2 renewal, DHCP relay, DNS options, DHCPv6, conflict detection or NVRAM.
One statically configured Server IP per pool, one IPv4 subnet, max 256 addresses,
lease 60–86400 s; pool excludes server and configured gateway. Existing pool changes
are rejected rather than discarding active leases. Offers reserve an address for
30 seconds; ACK installs the lease in the L3 host. DHCP frames pass through the
same Ethernet bridge/VLAN/link events as other packets. DHCP is exposed in GUI/API,
not vendor DHCP CLI. Actual test execution remains outstanding.

## OSPF teaching model
Area 0 only, unit link cost, AD 110. Local active IPv4 interfaces send multicast
Hello and LSA messages every second, neighbor expiry 6 seconds and LSDB expiry 12
seconds (teaching timers, not default RFC timers). Messages use protocol 89 with
private `NSH1`/`NSO1` payloads. LSAs flood through neighbor interfaces, sequence
suppression prevents repeated floods, and SPF uses reciprocal advertised links.
No global topology lookup is used. Routes enter the same IPv4 RIB as static routes.
The subset does **not** implement RFC 2328 packet formats, DD/LSR/LSAck, reliable
flooding, DR/BDR, network LSAs, area types, authentication, ECMP or vendor OSPF CLI.
Config is via a GUI property / API, all active IPv4 interfaces participate.
These limitations preclude interoperability with physical routers.

## Project persistence
Schema 3: wireless.aps, wireless.clients, services.dhcp_servers, services.dhcp_clients,
services.ospf. IDs map to project nodes. v2 migrates to v3 with empty new settings;
legacy empty v1 remains supported. Runtime leases, neighbor state, packet queue,
and association links are rebuilt, not persisted. PSK is plaintext in JSON.
The same GUI-thread controller remains in use; worker migration is outstanding.

## Validation and release gates
Run `cargo generate-lockfile`, `cargo fetch --locked`, `cargo fmt --all`,
`cargo test --workspace --locked`, `cargo clippy --workspace --all-targets --locked -- -D warnings`,
`cargo build --workspace --release --locked`, `cargo run -p netsim-cli -- wireless-demo`.
Do not mark the release production-ready until compilation, all tests and GUI smoke
have passed on the supported platforms. Current environment has no cargo/rustc/rustfmt.
`Cargo.lock` needs resolution; the historical v0.0.6 lock is not a build input.
