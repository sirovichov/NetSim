# Eltex CLI — educational subset (v0.0.6)

## Official sources consulted

- [MES14xx/MES24xx/MES3400/MES37xx user manual 10.4.2.1](https://api.prod.eltex-co.ru/storage/upload_center/files/41/MES_Series_user_manual_10.4.2.1.pdf): hardware table p.18; configuration files p.81; VLAN and Ethernet modes pp.88–90. PDF text available; screenshot fetch failed.
- [MES trunk design guide](https://docs.eltex-co.ru/pages/viewpage.action?pageId=619644036).
- [ESR 1.34 hardware description](https://docs.eltex-co.ru/pages/viewpage.action?pageId=593366804), table 30: four logical Combo Ethernet interfaces.
- [ESR 1.34 CLI index](https://docs.eltex-co.ru/pages/viewpage.action?pageId=593367210).
- [ESR 1.34 interface configuration](https://docs.eltex-co.ru/pages/viewpage.action?pageId=593366909).
- [ESR 1.34 configuration lifecycle](https://docs.eltex-co.ru/pages/viewpage.action?pageId=593367218).
- [ESR 1.34 static routes](https://docs.eltex-co.ru/pages/viewpage.action?pageId=593367245).

References are a baseline, not a claim of exact firmware reproduction. No manuals redistributed.

## MES2428

28 logical GigabitEthernet ports (24 copper + 4 Combo); all modeled as Ethernet.
The teaching profile starts in access VLAN 1, unlike the documented default general mode.
User EXEC `enable`, privileged `configure terminal`, global `vlan VID`,
`interface gigabitethernet 1/0/N` (also `gi 1/0/N`), interface `shutdown` / `no shutdown`,
`description`, `switchport mode access` / `trunk`, `switchport access vlan VID`,
`switchport trunk native vlan VID`, `exit`, `end`.
Trunk allowed list replacement/add/remove, VLAN `name`, `no vlan` are educational
extensions; not asserted identical to every MES release. `general` and Q-in-Q unsupported.
`show vlan`, `show interfaces status`, `show interfaces switchport`,
`show mac-address-table`, `show spanning-tree`, `show running-config`,
`show startup-config`, `show system information`, `write startup-config`,
`copy running-config startup-config`, `reload`.

## ESR-100

Four logical Combo ports in routeport-like lab mode. No factory bridge, firewall,
security zones, access authentication or real management service. `configure`
(not Cisco configure terminal), `interface gigabitethernet 1/0/N[.VID]`,
`ip address A.B.C.D/LEN`, `no ip address`, `shutdown`, `no shutdown`,
`ip route NETWORK/LEN NEXT_HOP`, `no ip route NETWORK/LEN NEXT_HOP`,
`exit`, `end`, `hostname`. VLAN subinterface tag comes from the suffix.
`show interfaces`, `show interfaces status`, `show ip interface`, `show ip route`,
`show ip arp`, `show running-config`, `show candidate-config`, `show startup-config`.
`show startup-config` is a simulator extension for inspecting boot configuration.
`ping IP` sends one virtual ICMP probe. `?` gives mode help, not full prefix completion.

`commit` applies candidate; `confirm` makes it persistent within the device instance;
`commit confirm-timeout SECONDS` supports 120–86400 seconds (default 600).
`rollback` discards candidate changes; `restore` restores the previous configuration
if a commit is outstanding. `save` saves candidate to simulated boot memory
when no commit is pending. `reboot` restores boot configuration.
Global-mode commit/confirm also accepted (documented operational examples).
All commands are local only, no real device interaction.

## Limitations

No abbreviations beyond `gi`, no history/Tab editor, no SVI on MES, no ESR L2
switchport/bridge mode, no OSPF, DHCP, secondary addresses, VRF, firewall, NAT,
or real filesystem persistence. The existing L2/STP/L3 limitations remain.
MixedLab drives commit expiry at a virtual-time boundary; it rejects ping/traceroute
while a commit is pending to prevent the older diagnostic APIs bypassing that
boundary. Raw Engine users must call EltexDevice::expire themselves. Events at the
same timestamp as expiry may be processed before rollback. Outputs are original
simplified diagnostics, not golden-verified transcripts. Tests not executed.
