# Cisco IOS — учебное подмножество v0.0.5

## Источники

Использованы приложенные сканированные руководства Cisco ICND1/ICND2 v1.0
(2007). Страницы ниже — печатные номера, не номера PDF. Сверены визуально
таблицы команд и примеры; исходные PDF не включены в MIT-репозиторий.

| Источник | Область | Реализация |
|---|---|---|
| ICND1, лабораторное руководство, стр. 35 (PDF 43) | enable, configure terminal, hostname, end, copy running-config, erase startup-config, shutdown | поддержаны; SVI/пароли/VTY отложены |
| ICND1, лабораторное руководство, стр. 65–66 (PDF 73–74) | контекстная справка, show history, show interfaces, running-config | поддержаны; настройка history size/clock/terminal отложена |
| ICND1, лабораторное руководство, стр. 96 (PDF 104) | running/startup configuration | поддержаны; setup отложен |
| ICND1, лабораторное руководство, стр. 141, 145 (PDF 149, 153) | ip address, ip route, ping, traceroute, show ip route, gateway of last resort | поддержано на Ethernet; PPP/serial отложены |
| ICND2, лабораторное руководство, стр. 4 (PDF 10) | базовые команды конфигурации и сохранения | подмножество |
| ICND2, лабораторное руководство, стр. 11, 14, 16, 19 (PDF 17, 20, 22, 25) | VLAN/name/access/trunk, show vlan, show interfaces switchport | поддержаны в учебном объёме |
| ICND2, лабораторное руководство, стр. 12, 19 (PDF 18, 25) | Rapid-PVST/VTP | не реализованы; show spanning-tree выводит только общее дерево |
| ICND2, том 1, оглавление (PDF 3–4), раздел 2-75–2-79 | маршрутизация между VLAN 802.1Q | router-on-a-stick, без native subinterface |

Модели 2960/2911 — выбранные проектом профили, не подтверждение соответствия
конкретной IOS из руководств 2007 года. Дополнительные команды (allowed/native,
`do`, `write memory`, `show ip arp`, `show mac address-table`) —
самостоятельно реализованное расширение CLI; вывод не копирует оригинальные
таблицы, а формируется из состояния симуляции.

## EXEC

`enable`, `disable`, `exit`, `show version`, `show interfaces`,
`show ip interface brief`, `ping A.B.C.D`, `traceroute A.B.C.D`.
Privileged EXEC: `configure terminal`, `show running-config`, `show startup-config`,
`show history`, `copy running-config startup-config`, `write memory`,
`erase startup-config`, `reload`, `show interfaces INTERFACE`.

Switch: `show vlan [brief]`, `show mac address-table`, `show spanning-tree`,
`show interfaces trunk`, `show interfaces INTERFACE switchport`.
Router: `show ip route`, `show ip arp`, `show arp`.

## Global config

`hostname NAME`, `interface INTERFACE`, `exit`, `end`.
Switch: `vlan ID`, `no vlan ID` (VLAN 1 нельзя удалить), `name NAME` (config-vlan).
Router: `ip route NETWORK MASK NEXT_HOP [DISTANCE]`,
`no ip route NETWORK MASK NEXT_HOP [DISTANCE]`. Неразрешённый next hop
остаётся в конфигурации, но не устанавливается в RIB.

## Interface config

`description TEXT`, `no description`, `shutdown`, `no shutdown`.
Switch: `switchport mode access|trunk`, `switchport access vlan ID`,
`switchport trunk native vlan ID`, `switchport trunk allowed vlan LIST`,
`switchport trunk allowed vlan all|none`, `switchport trunk allowed vlan add LIST`,
`switchport trunk allowed vlan remove LIST`, `no switchport trunk allowed vlan`.
LIST = comma-separated VLAN IDs or inclusive ranges, e.g. 10,20-22.
Router: `ip address IP MASK`, `no ip address`, `encapsulation dot1q ID`
(subinterface only). Configure the tag before setting the subinterface IP.
Physical router ports start administratively down; switch ports up.

`do show ...` / `do ping ...` / `do traceroute ...` supported from config modes.
Unique case-insensitive keyword prefixes, `?`, Tab via `complete_line`,
abbreviated physical interface names. `help` lists available commands.
Unsupported commands report an error; no simulated success for absent features.
