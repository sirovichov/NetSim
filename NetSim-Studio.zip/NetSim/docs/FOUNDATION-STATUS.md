# Foundation status

| Item | Status |
|---|---|
| Workspace, local dependency graph, lockfile manifest parity | Static check available |
| Typed IDs, contracts, queue, sample primitives | Source written; Rust tests not run |
| 9 JSON draft profiles and matching static registry IDs | Static check available |
| Rust compiler, rustfmt, clippy, tests, release build | Not executed in delivery environment |
| GitHub CI and source release | Configured, not run |
| Full DES dispatch, topology mutations, generation cancellation, RNG | WP2/WP3 |
| JSON schema runtime validation, GUI, packet codecs, CLI and network protocols | Future |
| Eltex MES/ESR and Cisco exact versions | Documentation/hardware verification pending |

Baseline Rust 1.85.1 is a deliberate minimal Edition 2024 toolchain, not a latest
version claim. Revisit it before adding external dependencies and audit security
updates. The selected runner labels are hosted-platform defaults; explicit CPU
architecture coverage and installer tests are later work. No claim of successful
compilation or production readiness until GitHub matrix has actually passed.
The project/profile JSON Schemas are structural drafts; reference integrity,
unique global IDs and vendor-specific configuration validation remain future work.

M1 sign-off requires fmt, clippy, tests and release build on all three OS runners.
M2: implement registry factories, device generation checks, real event dispatch,
virtual timer cancellation, deterministic RNG, snapshots and trace, then build
two-host Ethernet/ARP/ICMP vertical slice with WP3/WP4.

## Delivery validation

- `scripts/check_repository.py`: passed (20 crates, acyclic graph, lockfile parity, nine draft profiles).
- JSON Schema Draft 2020-12: both schemas checked; nine profile instances and the empty project validated.
- GitHub workflow YAML: parsed; no GitHub runner execution.
- Rust compilation and all 14 Rust tests: not run (toolchain unavailable in delivery environment).
