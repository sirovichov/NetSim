# v0.0.6 — Eltex Edition

Source implementation only; compiler, rustfmt, clippy and test execution unavailable.
The full v0.0.5 tree is retained. The new `netsim-eltex` console uses vendor-specific
commands and the existing L2/L3 APIs. `MixedLab` composes both vendors on one Engine.
See [CLI reference](cli-reference/ELTEX.md) for command coverage, sources and limitations.

Acceptance: run repository checks, format, build, test, clippy and `eltex-demo`
on all three platforms. Do not mark release accepted until CI is green.
MES and ESR profiles are still draft, despite documented port counts.
