# v0.0.4 — L3 Networking

Status: source implementation, pending compiler/CI verification. Based on the exact
v0.0.3 ZIP. All 20 crates and previous tests are retained. No third-party dependencies.

## Model and API

- `netsim-packet::ipv4`: 20-byte IPv4 header, 1500-byte MTU, Internet checksum;
  ICMP Echo (types 0/8), Destination Unreachable (3), Time Exceeded (11);
  error quote of original IPv4 header and first eight payload bytes.
- `netsim-protocols::routing`: interface identity `(PortId, Option<VLAN>)`,
  interface config, connected/static route data, longest prefix first then
  administrative distance, metric and deterministic interface/next-hop tie-break.
- `netsim-engine::engine::l3`: each node has its own RIB, interface ARP caches,
  pending datagrams, probe state. No routing through global topology search.
  The link state lookup is local carrier detection. Ethernet transmission is
  the existing DES medium. On routing, TTL is decremented and checksum recalculated.
- `configure_ipv4_host(id, InterfaceConfig, Option<gateway>)` attaches an untagged
  endpoint; the gateway becomes a default route. `configure_router(id)` and
  `configure_router_interface(id, InterfaceConfig)` attach generic IPv4 routing
  to a model. Configure while off. Tagged interfaces may share a MAC on the same
  physical port. The switch must be configured with matching allowed VLANs.
- `add_static_route(id, Route)` and `remove_static_route(id, Route)` while off;
  `RouteOrigin::Static`, distance 1–254, directly on-link unicast gateway.
  Connected routes are derived from interfaces. `route_lookup` selects a usable
  route through a powered, connected physical port; no recursive next-hop.
- `ping(id, destination, ttl, timeout_ns)` returns a monotonic probe token;
  `probe(id, token)` exposes pending/reply/time-exceeded/unreachable/no-route/timeout.
  `EngineCommand::SendPacket` starts a 64-TTL, 5-second echo probe.
- `traceroute(id, destination, max_hops, timeout_per_hop_ns, event_budget)`
  executes one echo per TTL, returns a list of `Probe`s, stops at reply,
  unreachable or no-route; budget is shared and exhaustion returns an error
  with simulation already advanced. For GUI use incremental `WorkerRequest::Ping`
  and `Probe`, with `RunUntil`/`Step`; the blocking traceroute is headless only.
- `SimulationSnapshot::l3` contains configured interfaces, local carrier flags,
  active-neighbor cache entries, configured routes (including inactive ones),
  probes, pending count and accepted-forward count (not delivery count).
  `TraceAction::IpDrop` records diagnostic drop reasons.
- Power-off/reboot clears ARP, pending traffic, probes and counters while keeping
  configuration. Device removal/reset removes L3 state. Carrier loss clears the
  affected interface cache/pending packets.

## Timing and limits

Virtual time only. One periodic L3 tick per powered IPv4 node, every second;
up to three ARP requests per resolution (initial + two retries), pending timeout
3 s, tick granularity can delay cleanup by less than one second. Probe deadline
is evaluated against virtual time (late replies ignored). A short probe timeout
does not cancel an already queued datagram. ARP cache expiry 60 s (inherited);
128 pending datagrams per node, 256 probe records (completed records evicted
in token order), 256 interfaces and 4096 static routes per node. Ethernet queue,
loss, and scheduler limits are inherited. No load test performed.

## Example

```rust
use netsim_app::create_engine;
use netsim_core::{EngineError, MacAddress, MediaKind};
use netsim_engine::{EngineLimits, InterfaceConfig, InterfaceKey};
use std::net::Ipv4Addr;

fn main() -> Result<(), EngineError> {
    let mut engine = create_engine(42, EngineLimits::default())?;
    let pc = engine.add_device("generic.host.pc", 1, "PC1".into())?;
    let p = engine.add_port(pc, MediaKind::Ethernet)?;
    engine.configure_ipv4_host(pc, InterfaceConfig {
        key: InterfaceKey { port: p, vlan: None },
        address: Ipv4Addr::new(192, 168, 10, 10),
        prefix_len: 24,
        mac: MacAddress([2, 0, 0, 0, 0, 1]),
    }, Some(Ipv4Addr::new(192, 168, 10, 1)))?;
    Ok(())
}
```

Runnable complete two-subnet example: `crates/netsim-app/src/l3_demo.rs`.
Mixed Cisco/Eltex router-on-a-stick and two-router routes:
`crates/netsim-app/tests/l3.rs`.

## Acceptance

Run `python3 scripts/check_repository.py`, `cargo fmt --all`, then
`cargo fmt --all -- --check`, `cargo clippy --workspace --all-targets --locked
--offline -- -D warnings`, `cargo test --workspace --locked --offline`,
`cargo build --workspace --release --locked --offline`, and
`cargo run --locked --offline -p netsim-cli -- l3-demo`.
CI checks Windows, Linux and macOS; release is gated on CI.
Cargo/rustc/rustfmt not present in delivery runtime; no compiler/test result claimed.
Static inspection is not a substitute for protocol or compiler validation.

## Limitations

Educational unicast IPv4 only; no IP options, fragmentation/reassembly, multicast,
broadcast routing, ICMP redirects/rate limiting, TCP/UDP endpoint delivery,
DHCP, IPv6, NAT, ACL, RIP, OSPF, EIGRP, recursive routes, ECMP, VRF or dynamic
interface configuration. Non-ICMP IPv4 unicast may be forwarded but is not handled
by a local application. ICMP traceroute only (not UDP or TCP traceroute). ARP
timeout on transit packets can produce host unreachable; locally originated
probes without resolution time out. No full RFC conformance or actual vendor
firmware fidelity claimed. No real network I/O.

## Delivery checks

- Structural repository script: pass (20 crates, acyclic dependencies, lock parity).
- JSON Schema and nine draft device profiles: pass.
- GitHub workflow YAML parsing: pass (not executed).
- 54 Rust test declarations (42 inherited, 12 new).
- Cargo build, rustfmt, Clippy and Rust tests: not executed (toolchain absent).
