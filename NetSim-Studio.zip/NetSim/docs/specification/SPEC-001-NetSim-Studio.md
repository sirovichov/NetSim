# SPEC-001-NetSim-Studio

**Редакция:** 1.0 — 26.11.2026  
**Статус:** спецификация для начала разработки; ПО ещё не реализовано  
**Лицензия:** MIT · **Репозиторий:** публичный GitHub (планируется)  
**Платформы:** Windows, Linux, macOS · **Язык:** Rust, Edition 2024  
**Подход:** Production-ready · **Первый релиз:** v0.1.0 MVP

Background, Requirements, Method и Implementation согласованы в диалоге. Milestones, критерии приёмки, уточнения технических контрактов и пороги производительности — предлагаемые решения.

## Background

NetSim Studio — независимый аналог Cisco Packet Tracer для обучения, проектирования сетей и лабораторных работ с оборудованием Cisco и Eltex. Пользователь строит топологию, соединяет порты, настраивает устройства через CLI и виртуальные Web-панели, наблюдает пакеты и диагностирует ошибки без физического оборудования.

Движок моделирует наблюдаемое поведение устройств, а не исполняет оригинальные прошивки или эмулирует процессоры и ASIC. Точность интерфейсов ограничена подтверждённым набором функций и выбранным профилем ПО.

### Исходные материалы

| Предоставленный документ | Основание для функций (по оглавлениям PDF) |
|---|---|
| ICND1, том 1, v1.0, 2007, стр. 3–8 | Ethernet, ARP, TCP/IP, IOS, коммутация, WLAN |
| ICND1, том 2, стр. 3–7 | IPv4, DHCP, маршрутизация, NAT/PAT, RIP, CDP |
| ICND2, том 1, стр. 3–6 | VLAN, VTP, STP/RSTP, OSPF |
| ICND2, том 2, стр. 3–6 | EIGRP, ACL, NAT/PAT, IPv6, PPP, Frame Relay |
| ICND1, лабораторные, стр. 3–7 | Базовая диагностика, CLI, маршрутизация |
| ICND2, лабораторные, стр. 3–5 | VLAN, OSPF, EIGRP, ACL, IPv6 |
| WEP-2ac / WEP-2ac Smart, руководство ПО 1.25.0, стр. 2–4 | Web UI, Ethernet, VAP, VLAN, радио, аутентификация, мониторинг, службы |

Шесть PDF Cisco — сканы учебных материалов; не выполнена постраничная проверка всех команд. Они не гарантируют точность для поздних моделей IOS. В предоставленном комплекте Eltex нет специализированных руководств MES/ESR. Дополнительные официальные материалы приведены в Method.

## Requirements

### Must have — целевой продукт

| ID | Требование | Релиз |
|---|---|---|
| M01 | Приложение и ядро на Rust | MVP |
| M02 | Кроссплатформенный GUI | MVP |
| M03 | Редактор топологии, порты, кабели, перемещение, масштаб | MVP |
| M04 | Каталог Cisco и Eltex | 6 моделей MVP, 18 целевых |
| M05 | Реалистичный CLI Cisco IOS | MVP: подтверждённое подмножество |
| M06 | Реалистичный CLI Eltex MES/ESR/WEP | MVP: подтверждённое подмножество |
| M07 | Web-интерфейс управления WEP | MVP: основные страницы |
| M08 | Моделирование сетевых протоколов | По матрице |
| M09 | Real-Time и Simulation | MVP |
| M10 | Пошаговые события и PDU | MVP |
| M11 | Просмотр PDU по OSI и причин отбрасывания | MVP |
| M12 | Сохранение и загрузка проектов | MVP |
| M13 | Встроенные лабораторные | 13 в MVP |
| M14 | Автономная работа без интернета | MVP |
| M15 | Модульность, расширяемые профили | MVP |
| M16 | Русский и английский UI | MVP |

### Should have

S01 автоматическая проверка лабораторий (MVP); S02 экспорт PCAP (MVP); S03 физический вид оборудования (упрощённый выбор порта в MVP); S04 питание и reboot (MVP); S05 отказ линий и устройств (MVP); S06 задержки, потери, bandwidth (MVP); S07 импорт/экспорт конфигураций (после MVP, вывод running-config в MVP); S08 Undo/Redo (после MVP); S09 справочник команд (контекстная помощь в MVP).

### Could have

Многопользовательский режим, конструктор устройств и лабораторий, визуализация покрытия Wi-Fi, серверные стойки, скрипты, калькулятор подсетей, плагины.

### Won't have в MVP

Оригинальные прошивки и аппаратная эмуляция, подключение реальных сетей, гарантированная совместимость .pkt, физическое RF-моделирование. Подключение к физическим сетям не утверждено как обязательная будущая функция.

### Матрица протоколов

| Область | MVP | После MVP |
|---|---|---|
| Среда | Ethernet, виртуальное Wi-Fi, скорость, задержки, потери | Serial, расширенная оптика/RF |
| L2 | Ethernet, ARP, VLAN, 802.1Q, базовый совместимый STP | RSTP, PVST+, VTP, CDP, LLDP, LACP, PPP, HDLC, Frame Relay |
| L3 | IPv4, ICMP, connected/static/default routes, OSPFv2 area 0 | IPv6/NDP, RIP, EIGRP, ACL, NAT/PAT, расширенный OSPF |
| L4 | UDP | TCP |
| Службы | DHCPv4, локальные CLI/Web-панели | DNS, HTTP(S), FTP/TFTP, виртуальные SSH/Telnet, SNMP, NTP |
| Wi-Fi | SSID, VAP/VLAN, ассоциация, открытая сеть, логическая WPA2-PSK | RADIUS, roaming, Mesh, QoS, Captive Portal |

MVP Wi-Fi не реализует физический радиообмен и полноценную WPA-криптографию. Web/CLI в MVP доступны через локальный виртуальный интерфейс, а не реальные сетевые сокеты. OSPF MVP: одна область, point-to-point и broadcast с DR/BDR, без внешних LSA, перераспределения и аутентификации. STP: один совместимый режим, подтверждённый профилями; специфические варианты дерева по VLAN позже.

### Каталог

| Семейство | MVP | После MVP |
|---|---|---|
| Cisco ISR | 2911 | 1841, 1941, 2811, 4321, 4331 |
| Cisco Catalyst | 2960 | 3560, 3650, 3850 |
| Eltex MES | MES2428 | MES2324, MES3324 |
| Eltex ESR | ESR-100 | ESR-10, ESR-200 |
| Eltex WEP | WEP-2ac, WEP-2ac Smart | Расширение функций |
| Generic | PC, Laptop, Server | Hub, IP-phone, Printer, Firewall |

Итого 6 из 18 моделей производителей плюс три универсальных устройства в MVP. Точные аппаратные ревизии и версии ПО должны быть определены для каждого профиля.

### Нефункциональные требования

Детерминизм для одинаковых seed, входных команд с виртуальным временем и версий профилей; независимость GUI; отсутствие реального сетевого трафика; никакого исполнения CLI через shell хоста; структурированные ошибки, ограниченные очереди, переносимые файлы. Цель развития: 1000 устройств, 5000 линий, 100 000 событий/сек, 60 FPS; минимум 4 ГБ RAM, рекомендуется 8–16 ГБ. Это цели, не измерения.

## Method

### 3.1. Архитектура

Модульный монолит: однопоточное детерминированное ядро дискретно-событийной симуляции (DES) и отдельный GUI-поток. Headless CLI использует тот же движок. Не требуются виртуальные машины, Docker, реальные образы прошивок или сетевые драйверы.

Packet Tracer — концепция редактора, CLI, PDU; [GNS3](https://docs.gns3.com/docs) — расширяемый каталог моделей/образов; [ns-3](https://www2.nsnam.org/docs/manual/html/) — дискретные события и разделение симулятора и моделей. Не копировать их код и ресурсы.

```plantuml
@startuml
skinparam componentStyle rectangle
[Desktop GUI] as GUI
[Headless CLI] as CLI
[App API / Worker] as APP
[Simulation Engine] as ENG
[Device Contracts] as DEV
[Cisco / Eltex / Generic] as VEND
[Protocol Stack] as PROTO
[Virtual Media] as MEDIA
[Services] as SVC
[Registry] as REG
[Storage] as STORE
[Lab Engine] as LAB
[PCAP Export] as CAP
GUI --> APP
CLI --> APP
APP --> ENG
APP --> REG
APP --> STORE
APP --> LAB
APP --> CAP
REG --> VEND
ENG --> DEV
ENG --> MEDIA
VEND ..|> DEV
VEND --> PROTO
VEND --> SVC
@enduml
```

### 3.2. Технологии

| Компонент | Библиотека |
|---|---|
| GUI | [egui](https://docs.rs/egui/), [eframe](https://docs.rs/eframe/) |
| Графы | [petgraph](https://docs.rs/petgraph/) |
| Пакеты | [etherparse](https://docs.rs/etherparse/), собственные недостающие кодеки |
| Сериализация | [serde](https://docs.rs/serde/), [serde_json](https://docs.rs/serde_json/) |
| Межпоточные каналы | [crossbeam-channel](https://docs.rs/crossbeam-channel/) |
| PCAP/PCAPNG | [pcap-file](https://docs.rs/pcap-file/) |
| CLI приложения | [clap](https://docs.rs/clap/) |
| DES | BinaryHeap, BTreeMap, FSM, собственный scheduler |
| Хранилище | Версионированный JSON, без СУБД в MVP |
| CI/CD | GitHub Actions |

Проверенные по страницам документации кандидаты на 26.11.2026: egui/eframe 0.37.0, petgraph 0.8.3, etherparse 0.21.1. Их совместная сборка не проверена. Точные версии остальных зависимостей и toolchain фиксируются на M1 после сборки на трёх ОС, через workspace.dependencies и Cargo.lock. Tokio в ядре не требуется.

### 3.3. Границы crates

| Crate | Ответственность | Основные внутренние зависимости (без префикса netsim-) |
|---|---|---|
| netsim-types | ID, адреса, время, базовые enum | — |
| netsim-core | Контракты событий, ошибок, команд | types |
| netsim-packet | Буферы, кодеки, PDU | types |
| netsim-topology | Граф, порты, линии | types |
| netsim-media | Передача, очереди, виртуальная среда | core, packet, topology |
| netsim-devices | NetworkDevice, DeviceContext, descriptor, config contracts | core, packet |
| netsim-protocols | L2/L3/L4 FSM | core, packet |
| netsim-services | DHCP и другие службы | protocols, packet |
| netsim-terminal | Parser framework, сессии, помощь | core |
| netsim-cisco | IOS и модели Cisco | devices, protocols, services, terminal |
| netsim-eltex | MES, ESR, WEP | devices, protocols, services, terminal |
| netsim-generic | PC, Laptop, Server | devices, protocols, services |
| netsim-engine | DES, dispatch, trace | core, devices, topology, media |
| netsim-webui | View-model и действия Web-панели | core, devices |
| netsim-storage | JSON, валидация, миграции | core, topology, devices |
| netsim-capture | PCAP/PCAPNG | packet, core |
| netsim-labs | Правила и выполнение проверок | engine, storage |
| netsim-app | Реестр фабрик, worker API, проекты | engine, vendor crates, storage, capture, labs |
| netsim-cli | Headless runner | app |
| netsim-gui | eframe, редактор, панели | app, webui |

Ядро не зависит от vendor crates; приложение регистрирует фабрики. DeviceContext находится в нижнем слое. Циклические зависимости запрещены.

### 3.4. Ядро DES

```rust
pub type SimTime = u64; // ns
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct DeviceId(pub u64);
// Аналогично PortId, LinkId, PacketId, TimerId, SessionId.
pub struct SimEvent {
    pub at: SimTime,
    pub sequence: u64,
    pub target: DeviceId,
    pub generation: u64,
    pub kind: EventKind,
}
pub enum EventKind {
    PacketReceive { port: PortId, packet: PacketId, link: LinkId, link_generation: u64 },
    TimerExpired { timer: TimerId, generation: u64 },
    LinkChanged { link: LinkId, up: bool },
    DeviceBoot, DeviceShutdown,
    CliCommand { session: SessionId, command: String },
    ConfigChanged,
}
pub trait SimulationEngine {
    fn now(&self) -> SimTime;
    fn execute(&mut self, command: EngineCommand) -> Result<CommandResult, EngineError>;
    fn step(&mut self) -> Result<Option<ProcessedEvent>, EngineError>;
    fn run_until(&mut self, time: SimTime, event_budget: usize) -> Result<RunReport, EngineError>;
    fn snapshot(&self) -> SimulationSnapshot;
}
```

Контракты концептуальные, не готовые компилируемые исходники. События сортируются по (at, sequence), обратный Ord для BinaryHeap; Eq соответствует ключу. ID и sequence монотонные, не переиспользуются; checked arithmetic. Поколения устройств, линий и таймеров отменяют устаревшие события после удаления, reboot или перепланирования.

Алгоритм: извлечь ближайшее событие в пределах дедлайна; установить now=at; проверить ID/поколение; передать локальному обработчику; получить упорядоченный набор действий send/schedule/log; присвоить sequence новым событиям и записать trace. Никакой рекурсивной доставки. При исчерпании очереди или следующем событии позже дедлайна run_until продвигает время до дедлайна; при исчерпании бюджета — не перескакивает через события. Недопустимы события в прошлом. Перебор, влияющий на порядок событий, только сортированный. RNG фиксирован и версионирован.

EngineCommand: AddDevice, RemoveDevice, ConnectPorts, DisconnectLink, PowerOn/Off, Reboot, ExecuteCli, ApplyConfig, SendPacket, Reset. Валидировать структурные изменения до применения; удаление закрывает сессии, удаляет линии, инвалидирует таймеры. Переполнение очереди приводит к паузе и диагностике.

Real-Time синхронизируется с монотонными часами только на уровне worker; Simulation использует виртуальное время; Step Event обрабатывает одно событие; Step PDU — до следующего видимого PDU с лимитом событий; Fast Forward — выполнение порциями с заданным дедлайном.

GUI отправляет команды через bounded queue (стартовый лимит 1024), ответы коррелируются request_id и не теряются. Неизменяемые снимки публикуются в отдельный latest-slot; промежуточные снимки можно заменять. GUI читает snapshot/trace, не изменяет ядро. Worker проверяет паузу между порциями событий (256–4096). Trace и буферы ограничены; пропущенная история явно отмечается. Никакого I/O в обработчиках протоколов.

```plantuml
@startuml
actor User
participant GUI
participant Worker
participant Engine
participant Device
User -> GUI : command
GUI -> Worker : request_id, command
Worker -> Engine : execute / step
Engine -> Device : event
Device --> Engine : actions
Engine -> Engine : queue, trace, state
Engine --> Worker : result, snapshot
Worker --> GUI : reply + latest snapshot
@enduml
```

### 3.5. Устройства и каталог

```rust
pub trait NetworkDevice: Send {
    fn id(&self) -> DeviceId;
    fn descriptor(&self) -> &DeviceDescriptor;
    fn on_event(&mut self, event: DeviceEvent, ctx: &mut DeviceContext)
        -> Result<(), DeviceError>;
    fn execute_cli(&mut self, session: SessionId, command: &str,
        ctx: &mut DeviceContext) -> CliResult;
    fn snapshot(&self) -> DeviceSnapshot;
}
```

Контракт дополняется типизированным чтением/применением конфигурации, сбросом и reboot. DeviceContext предоставляет виртуальное время, RNG, emit/schedule и локальные свойства портов; не произвольный доступ к глобальной топологии. DeviceFactory создаёт экземпляр по ID, профилю, конфигурации и seed; Registry собирается в netsim-app.

Композиция SwitchingEngine, RoutingEngine, WirelessEngine, HostStack. Вендор задаёт CLI, defaults и особенности поведения; общие протоколы не дублируются.

```json
{
  "schema_version": 1,
  "id": "cisco.router.2911",
  "profile_version": 1,
  "vendor": "Cisco",
  "model": "2911",
  "device_type": "router",
  "cli_family": "cisco_ios",
  "firmware_reference": null,
  "verification_status": "draft",
  "ports": [
    {"id": 1, "name": "GigabitEthernet0/0", "media": "ethernet", "speed_mbps": 1000},
    {"id": 2, "name": "GigabitEthernet0/1", "media": "ethernet", "speed_mbps": 1000},
    {"id": 3, "name": "GigabitEthernet0/2", "media": "ethernet", "speed_mbps": 1000}
  ],
  "implemented_features": ["ipv4", "icmp", "static_route", "ospfv2"],
  "planned_features": ["ipv6", "rip", "eigrp", "nat", "acl"]
}
```

Пример чернового описания, не проверенная конфигурация реального оборудования. До выпуска firmware_reference обязателен. Каждая функция или команда имеет запись в `docs/devices/<profile>/conformance.csv`: profile_id, firmware, feature_or_command, mode, args, expected_state, expected_output, source_locator, evidence_type, test_id, status. Статусы planned/doc_verified/hardware_verified/unsupported. Не выдавать документальную сверку за физическое испытание.

Дополнительные источники:
- [Eltex ESR, каталог документации](https://docs.eltex-co.ru/pages/viewpage.action?pageId=52497571).
- [ESR CLI 1.34](https://docs.eltex-co.ru/pages/viewpage.action?pageId=593367210) и [материалы обновления с ESR-100](https://docs.eltex-co.ru/pages/viewpage.action?pageId=593367296). Версия профиля пока не утверждена.
- [Eltex MES, база знаний с упоминанием MES2428](https://docs.eltex-co.ru/pages/viewpage.action?pageId=170852414). Не заменяет полное руководство CLI.
- [Cisco Support](https://www.cisco.com/c/en/us/support/index.html) — источник для выбора конкретной версии IOS.
- WEP-2ac / Smart: предоставленное руководство версии 1.25.0.

### 3.6. Алгоритмы протоколов

| Модуль | Контракт MVP |
|---|---|
| Media | Каждое направление линка: bounded FIFO, next_free_at, bandwidth_bps, delay_ns, loss_ppm. start=max(now,next_free_at); tx=ceil(bits*1e9/bps), arrival=start+tx+delay_ns; u128 для промежуточных вычислений. Потеря после передачи занимает время линии. Overhead документировать. |
| Ethernet | Проверять admin/oper, ingress VLAN и STP. FDB: ключ (VLAN,MAC), срок жизни по виртуальному времени. Учить валидный unicast source только при learning/forwarding. Flood broadcast/unknown unicast только в VLAN, исключая ingress. Known unicast на том же порту фильтровать. BPDU — отдельный control plane. |
| VLAN | Access: untagged ingress в PVID. Trunk: allowed/native VLAN, tag/untag при egress. Нестандартные комбинации и tagged ingress на access — по профилю. |
| STP | BPDU, выбор root, root/designated/blocked ports; tie-break по root ID, cost, sender bridge/port, local port; timers и learning/forwarding. Не строить дерево из глобального графа. |
| ARP | Кэш (interface,IPv4), bounded pending packets, запросы/повторы/expiry. Отправлять кадры после разрешения MAC next hop. |
| IPv4 | Проверка длины и checksum; local delivery отдельно. Longest Prefix Match по FIB; RIB выбирает по административной дистанции, метрике и стабильному tie-break. Connected routes зависят от oper state. На транзите decrement TTL/checksum, ICMP при отсутствии маршрута или TTL exhaustion. Фрагментация вне MVP; oversized frames диагностируются, ICMP где применимо. |
| ICMP | Echo Request/Reply, Unreachable, Time Exceeded; не генерировать ошибки на запрещённые категории, включая ICMP error. Ping — настоящий виртуальный обмен, не глобальный reachability shortcut. |
| UDP | Кодеки, длина/checksum по IPv4, доставка IP/port. |
| DHCPv4 | DORA, NAK, pool/exclusions, lease/renewal/expiry; одна broadcast domain, relay позже. |
| OSPFv2 | Per-router neighbor FSM, Hello/Dead, DR/BDR, DBD/LSR/LSU/LSAck, LSDB/flooding, SPF Dijkstra по локальной LSDB, intra-area RIB. Отказ линии вызывает сходимость. Не использовать глобальный граф для маршрутизации. |
| Wi-Fi | Виртуальная радиосреда: band/channel/SSID, проверка режима безопасности и PSK, ассоциация и disassociation, VAP/VLAN bridge в Ethernet. Без RF и реального криптографического обмена. |
| После MVP | RIP distance vector; EIGRP DUAL; TCP FSM, ACK, retransmit; IPv6/NDP; NAT/PAT state table; ACL first-match и default action. |

Протокольные таймеры виртуальны, defaults по источнику профиля. Сетевой шторм при выключенном STP не скрывать искусственным TTL Ethernet; ограничивать ресурсами и диагностикой.

```plantuml
@startuml
start
:Receive frame;
if (Port and VLAN valid?) then (yes)
  if (Control frame?) then (yes)
    :Control plane;
  else (no)
    if (STP learning or forwarding?) then (yes)
      :Learn valid source MAC;
    endif
    if (Ingress forwarding?) then (yes)
      if (Known unicast?) then (yes)
        :Select FDB port except ingress;
      else (no)
        :Flood within VLAN;
      endif
      :Filter egress by STP/VLAN/link;
      :Queue transmission;
    else (no)
      :Trace drop;
    endif
  endif
else (no)
  :Trace drop;
endif
stop
@enduml
```

### 3.7. CLI и Web UI

Pipeline: tokenizer → grammar по профилю → validation режима, privilege, arguments → typed command → config/state mutation → protocol effects → format output. Сессия: mode, privilege, selected interface, history, completion. Сокращения только однозначные. Tab и контекстная справка ?. Ошибки не меняют конфигурацию.

IOS backlog MVP (команды активируются только на подтверждённых профилях): enable/disable, configure terminal, exit/end, hostname, interface, ip address, shutdown/no shutdown, vlan, switchport access/trunk/native/allowed, ip route, router ospf, network ... area 0, DHCP pool, ping/traceroute; show running-config/startup-config/ip interface brief/vlan brief/interfaces trunk/mac address-table/spanning-tree/ip route/ip ospf neighbor/ip ospf database/ip dhcp binding; copy running-config startup-config, reload. Команды show читают фактические таблицы и состояние. Golden tests проверяют формат и данные.

MES/ESR/WEP имеют независимые грамматики; не копировать IOS как универсальный CLI. Если профиль использует candidate/commit/confirm, хранить candidate, active и persistent отдельно, реализовать commit/rollback по документации. Running/startup сохраняются по семантике модели. Неподдерживаемые команды возвращают явное сообщение, а не имитацию успеха.

Web UI WEP-2ac/Smart 1.25.0 реализуется средствами egui, без HTTP listener хоста. MVP: Basic Settings, Status/Interfaces, Status/Client Associations, Manage/Ethernet Settings, Wireless Settings, Radio, VAP, Maintenance/Configuration. Поля связаны с типизированными командами ядра; аутентификация и сеанс виртуальные. Расширение: Services, SNMPv3, Cluster, Captive Portal, Client QoS, Mesh только для поддерживающей модели. Неактивные функции помечаются unsupported.

### 3.8. Схема данных

Состояние в памяти; JSON DTO не сериализуют trait objects. Стабильные ID, физические порты и логические интерфейсы разделены.

| Сущность | Поля и ограничения |
|---|---|
| Project | schema_version:u32, project_id:String, name:String, seed:u64, next_id:u64, devices[], links[], configurations[], settings |
| Device | id:u64 PK, profile_id, profile_version, hostname, position finite f64 x/y, power_state, ports[] |
| Port | id:u64 PK, device_id FK, profile_port_id, mac:[u8;6], media, mtu:u32, speed_bps:u64, admin_state, oper_state; имя уникально внутри устройства |
| Interface | id:u64 PK, device_id FK, kind physical/subif/SVI/loopback/wireless, port_id?, vlan_id?, ipv4_prefix?, admin_state |
| Link | id:u64 PK, два различных port_id FK, media, bandwidth_bps>0, delay_ns, loss_ppm 0..1000000, queue_limit_bytes>0, state |
| VLAN | (device_id,vlan_id) PK; name; VLAN 1..4094 и ограничения профиля |
| Config | device_id PK/FK, config_schema_version, running, startup, candidate?; typed vendor DTO |
| FDB | (device_id,vlan_id,mac) PK, port_id, expires_at |
| ARP | (device_id,interface_id,ip) PK, mac, state, expires_at |
| RIB | device_id, vrf(default в MVP), prefix, source, next_hop?, interface_id, metric, distance, state |
| FIB | device_id, vrf, prefix, selected_next_hop, interface_id; из RIB |
| Packet | id:u64, parent_id?, immutable bytes (Arc<[u8]>), link_type, metadata |
| Event | (at,sequence) unique, target, generation, kind |
| Trace | sequence, at, device_id?, port_id?, link_id?, packet_id?, direction, protocol, reason, summary |
| Lab | id, schema_version, localized title/objectives, topology_ref, checks[], time_limit?, seed |

PK/FK — логические ограничения, не SQL. Один Ethernet линк на порт, оба endpoint обязательны; wireless associations отдельно. Удаление очищает ссылки. Буферы пакетов разделяются при неизменной пересылке; при изменении — новый PacketId и parent_id.

```plantuml
@startuml
entity Project
entity Device
entity Port
entity Interface
entity Link
entity Config
entity VLAN
entity FDB
entity ARP
entity RIB
Project ||--o{ Device
Project ||--o{ Link
Device ||--o{ Port
Device ||--o{ Interface
Device ||--|| Config
Device ||--o{ VLAN
Device ||--o{ FDB
Device ||--o{ ARP
Device ||--o{ RIB
Port ||--o| Link : endpoint A/B
Interface }o--o| Port
@enduml
```

### 3.9. Формат .netsim

```json
{
  "format": "netsim-studio",
  "schema_version": 1,
  "project_id": "first-network",
  "name": "First Network",
  "seed": 42,
  "next_id": 5,
  "devices": [
    {"id": 1, "profile_id": "cisco.router.2911", "profile_version": 1,
     "hostname": "R1", "position": {"x": 320.0, "y": 140.0},
     "power_state": "on", "ports": [
       {"id": 2, "profile_port_id": 1},
       {"id": 3, "profile_port_id": 2},
       {"id": 4, "profile_port_id": 3}
     ]}
  ],
  "links": [],
  "configurations": [
    {"device_id": 1, "config_schema_version": 1,
     "running": {"kind": "cisco_ios", "interfaces": []},
     "startup": {"kind": "cisco_ios", "interfaces": []}}
  ],
  "simulation_settings": {"mode": "paused", "speed": 1.0}
}
```

Компактная DTO: профиль восстанавливает остальные свойства портов. Running восстанавливается при открытии проекта; startup используется при reboot по семантике профиля. ARP/FDB/RIB, пакеты, trace, очередь событий перестраиваются с now=0. Полные checkpoint snapshots после MVP.

Сохранение через временный файл в том же каталоге и платформенно корректную замену. При ошибке не терять предыдущий проект. Версионированные миграции; отказ при неизвестной более новой схеме, без молчаливой потери полей. Начальные лимиты: 32 MiB файл, 1000 устройств и 5000 линий, ограничение глубины и строк. Загрузка: read/validate/construct/swap. Не исполнять скрипты, не загружать ресурсы по сети; пути лабораторий ограничены каталогом проекта. Предупреждать о секретах при экспорте, не журналировать пароли.

### 3.10. GUI, trace, лаборатории

Каталог слева, topology canvas в центре, свойства/CLI/Web справа или в окнах, список событий снизу, панель времени. Drag/drop, zoom, pan, выбор портов, удаление, инспектор PDU, фильтры протоколов. GUI не блокируется при симуляции; списки виртуализированы. Графика собственная, не фирменная.

Packet Inspector показывает заголовки, реальные байты, события, причины Drop и lineage. PCAP экспортирует кадры выбранного виртуального интерфейса с виртуальными timestamp и корректным link type; для разных интерфейсов — PCAPNG либо отдельные PCAP. Документировать отсутствие FCS, если не моделируется. Не выдавать виртуальную Wi-Fi ассоциацию за физический 802.11 capture.

Lab runner декларативный: interface_ip, interface_up, vlan_membership, route_present, ospf_neighbor, ping, ping_blocked, dhcp_lease, wifi_associated, stp_port_state. Ссылки по ID, сумма баллов 100. Активные проверки в MVP явно продвигают виртуальное время и отправляют пакеты, с предупреждением; изолированные копии состояния позже. Отчёт содержит ожидаемое и фактическое значение.

## Implementation

### 4.1. Структура исходного кода

```text
netsim-studio/
  Cargo.toml
  Cargo.lock
  rust-toolchain.toml
  LICENSE
  README.md
  CHANGELOG.md
  CONTRIBUTING.md
  SECURITY.md
  .cargo/config.toml
  .github/workflows/{ci,release}.yml
  crates/
    netsim-types/      netsim-core/
    netsim-engine/     netsim-topology/
    netsim-packet/     netsim-media/
    netsim-protocols/  netsim-devices/
    netsim-cisco/      netsim-eltex/
    netsim-generic/    netsim-terminal/
    netsim-webui/      netsim-services/
    netsim-storage/    netsim-capture/
    netsim-labs/       netsim-app/
    netsim-cli/        netsim-gui/
  catalog/{cisco,eltex,generic}/
  assets/{icons,devices,fonts,themes,locales}/
  labs/{icnd1,icnd2,eltex,mixed}/
  tests/              # fixtures; executable tests inside crates
  benchmarks/
  examples/
  packaging/
  scripts/
  docs/{architecture,protocols,devices,cli-reference,specification}/
```

```toml
[workspace]
resolver = "3"
members = ["crates/*"]

[workspace.package]
version = "0.1.0"
edition = "2024"
license = "MIT"

[workspace.lints.rust]
unsafe_code = "forbid"

[workspace.lints.clippy]
all = "warn"

[profile.release]
opt-level = 3
lto = "thin"
```

Каждый crate наследует package metadata и `[lints] workspace = true`. Unsafe запрещён в собственном коде; зависимости отдельно аудируются. Версии в workspace.dependencies и Cargo.lock.

### 4.2. Файлы подсистем

```text
netsim-engine/src/
  lib.rs engine.rs clock.rs event.rs event_queue.rs scheduler.rs
  dispatcher.rs context.rs state.rs snapshot.rs trace.rs random.rs error.rs
netsim-protocols/src/
  lib.rs
  ethernet/{frame,switching,mac_table}.rs
  arp/{packet,cache,engine}.rs
  vlan/{database,access,trunk,dot1q}.rs
  stp/{bpdu,bridge,port,state_machine}.rs
  ipv4/{packet,forwarding,routing_table}.rs
  icmp/ udp/ ospf/
netsim-cisco/src/
  lib.rs
  ios/{parser,lexer,modes,session,completion,help}.rs
  ios/commands/  # enable, configure, interface, vlan, routing, show, copy
  ios/config/    # running, startup, renderer
  routers/isr2911.rs
  switches/catalyst2960.rs
netsim-eltex/src/
  lib.rs
  mes/{cli,commands,mes2428}.rs
  esr/{cli,commands,esr100}.rs
  wep/{wep2ac,wep2ac_smart,cli,radio,vap,authentication,config,management}.rs
netsim-gui/src/
  main.rs app.rs theme.rs localization.rs workspace.rs
  panels/{toolbar,device_catalog,properties,event_list,status_bar}.rs
  topology/{canvas,node,link,viewport,selection,interaction}.rs
  windows/{device,terminal,web_interface,packet_inspector,lab}.rs
  widgets/{port_indicator,device_icon,packet_animation}.rs
```

Модули имеют mod.rs или эквивалентный module.rs. Пустые заглушки не считаются поддерживаемыми функциями.

### 4.3. Пакеты работ

| WP | Реализация | Definition of Done |
|---|---|---|
| WP1 | Workspace, CI, toolchain, ADR, contracts | fmt/clippy/test/build, лицензия, нет циклов |
| WP2 | DES, queue, timers, snapshots, worker | headless, cancel, budget, determinism |
| WP3 | Topology/media, Ethernet/ARP/VLAN/STP | VLAN isolation, FDB aging, loop tests |
| WP4 | IPv4/ICMP/UDP, RIB/FIB, hosts | routing, TTL/no-route, LPM |
| WP5 | Cisco models/IOS parser | оба профиля и CLI golden tests |
| WP6 | Eltex MES/ESR | vendor grammar и смешанная топология |
| WP7 | GUI, storage, terminal, PDU | create/connect/config/save/open |
| WP8 | DHCP, OSPF, Wi-Fi, WEP UI | lease, convergence, association/VAP |
| WP9 | Labs, PCAP, localization, beta | 13 lab tests, регресс, benchmarks |
| WP10 | Packaging, audit, release | все gates, публичный v0.1.0 |

Каждый PR содержит тесты, review, docs для изменённого контракта, migration для схемы; main защищён CI и ревью. GitHub Issues с критериями приёмки. Профили имеют источники и версии. До v0.1.0 не обещать стабильный API.

### 4.4. Лаборатории

| ID | Тема | Релиз |
|---|---|---|
| LAB-001 | Два ПК | MVP |
| LAB-002 | ARP/ICMP | MVP |
| LAB-003 | Cisco switch | MVP |
| LAB-004 | Cisco router | MVP |
| LAB-005 | Статическая маршрутизация | MVP |
| LAB-006 | VLAN/trunk | MVP |
| LAB-007 | STP/отказ линии | MVP |
| LAB-008 | DHCP | MVP |
| LAB-009 | OSPF | MVP |
| LAB-010 | Eltex MES | MVP |
| LAB-011 | Eltex ESR | MVP |
| LAB-012 | Eltex WEP | MVP |
| LAB-013 | Смешанная сеть | MVP |
| LAB-014–018 | NAT/PAT, ACL, EIGRP, IPv6, Frame Relay | После MVP |

```json
{
  "schema_version": 1,
  "id": "LAB-005",
  "title": {"ru": "Статическая маршрутизация", "en": "Static Routing"},
  "topology": "topology.netsim",
  "checks": [
    {"type": "interface_ip", "device_id": 1, "interface_id": 12,
     "expected": "192.168.1.1/24", "points": 25},
    {"type": "interface_up", "device_id": 1, "interface_id": 12, "points": 25},
    {"type": "ping", "source_device_id": 2, "destination": "192.168.2.10",
     "timeout_ms": 5000, "points": 50}
  ]
}
```

Для каждой лаборатории начальная топология, эталонный (не единственный) способ решения, позитивные и негативные тесты. Самостоятельные формулировки заданий; оригинальные PDF не коммитить без разрешения.

### 4.5. CI/CD

```bash
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --locked -- -D warnings
cargo test --workspace --locked
cargo build --workspace --release --locked
```

Матрица Windows/Linux/macOS, заявленные CPU архитектуры проверяются на подходящих runners. Unit, integration, interoperability, CLI golden, deterministic, GUI smoke, fuzz, benchmark, license/security audit. Actions закреплять проверенными версиями/SHA, разрешения минимальны.

Публикация GitHub Releases: Windows MSI/EXE x86-64; Linux AppImage/DEB x86-64, ARM64 после проверки; macOS APP/DMG Intel/Apple Silicon после проверки. SHA256, SBOM, changelog, known limitations. Сертификаты и ключи подписи пока отсутствуют; неподписанные сборки не выдавать за подписанные. MIT относится к собственному коду, не автоматически к документации, ресурсам и зависимостям.

## Milestones

Плановый сценарий: 8 месяцев с начала разработки, команда 3–5 специалистов. Не гарантированный срок; зависит от объёма CLI, документации, оборудования и сложности протоколов. Роли: Rust Lead/Architect, Network Developer, Device Simulation Developer, GUI Developer, QA/Network Engineer. Роли могут совмещаться. Версии ниже — внутренние контрольные теги.

| Версия | Этап | Период от старта | Условие приёмки |
|---|---|---|---|
| v0.0.1 | Foundation | М1 | Workspace, CI, ADR, схемы, toolchain |
| v0.0.2 | Simulation Core | М1–М2 | Headless, очередь, стабильный trace |
| v0.0.3 | L2 Networking | М2–М3 | Ethernet, ARP, VLAN, STP |
| v0.0.4 | L3 Networking | М2–М4 | IPv4, ICMP, UDP, static routing |
| v0.0.5 | Cisco Edition | М3–М5 | 2960, 2911, проверенный IOS CLI |
| v0.0.6 | Eltex Edition | М3–М5 | MES2428, ESR-100, CLI и interoperability |
| v0.0.7 | Desktop Edition | М2–М6 | GUI, storage, terminal, trace |
| v0.0.8 | Wireless & Routing | М4–М7 | DHCP, OSPF, Wi-Fi, WEP UI |
| v0.0.9 | Beta | М6–М8 | 13 labs, PCAP, регресс и платформы |
| v0.1.0 | MVP Release | М8 | Все блокирующие gates, пакеты, docs |

Критический путь: Foundation → Core → L2/L3 → профили → advanced protocols → beta → release. GUI и профили могут разрабатываться параллельно после фиксации API. Отсутствие подтверждения критического профиля блокирует его milestone даже при успешной сборке.

После MVP: v0.2.x IPv6/TCP/RIP/NAT/PAT/ACL; v0.3.x EIGRP/RSTP/VTP/CDP/LLDP/LACP; v0.4.x PPP/HDLC/Frame Relay и дополнительные модели; v0.5.x+ Wi-Fi, лаборатории, каталог, оптимизация. v1.0.0 — выполнение всех обязательных требований целевого продукта. Группировка последующих релизов предварительная.

## Gathering Results

### 6.1. Функциональная приёмка

Все обязательные тесты MVP проходят; unsupported не засчитывается как успех, если функция заявлена в scope.

| ID | Проверка | Измеримый критерий |
|---|---|---|
| AT01 | Ethernet/ARP | FDB содержит корректные записи; ARP request/reply и cache expiry видны в trace |
| AT02 | ICMP | 10/10 echo reply при loss=0 после разрешения ARP |
| AT03 | VLAN | 0/10 cross-VLAN ping без L3 пути, внутри VLAN 10/10 |
| AT04 | Cisco/Eltex trunk | Теги VLAN 10/20, allowed/native VLAN; изоляция и корректный egress |
| AT05 | STP triangle | Избыточный путь блокируется; после отказа активной линии восстановление за ≤60 с виртуального времени в фиксированном тестовом профиле |
| AT06 | Static routing | Connected/static/default routes, LPM, 10/10 ping; удаление маршрута и TTL exhaustion дают диагностику |
| AT07 | OSPF area 0 | Соседства, LSDB и корректный FIB; после отказа в тестовой топологии восстановление ping ≤60 с виртуального времени при Hello/Dead 10/40 с |
| AT08 | DHCP | DORA, уникальный IP, маска, шлюз, lease/renewal/expiry, отказ при исчерпании пула |
| AT09 | WEP и Smart | Корректный SSID/PSK и VLAN дают ассоциацию и доставку; неверные параметры — отказ; Status показывает клиента |
| AT10 | CLI/Web | Все заявленные команды/поля меняют либо читают соответствующее состояние; golden tests, ошибки, save/reboot |
| AT11 | Project storage | Round-trip topology/config/seed/profile; runtime сбрасывается; ошибочный файл не уничтожает открытый проект |
| AT12 | Packet inspector/PCAP | Wireshark/tshark подтверждает заголовки поддерживаемых кадров и корректные timestamps; trace соответствует доставке |
| AT13 | 13 лабораторий | Корректные решения 100/100; отрицательные сценарии не дают полного балла |
| AT14 | GUI и платформы | Создание/настройка/сохранение/загрузка/симуляция без интернета на каждой заявленной ОС; обе локализации |
| AT15 | Устойчивость | Некорректные пакеты, CLI, JSON, дубликаты ID, удалённые объекты не приводят к panic |
| AT16 | Детерминизм | 10 повторов эталонных сценариев дают один canonical trace hash для фиксированной версии и seed; проверка на трёх ОС |

Порог сходимости — критерий конкретного тестового сценария, не гарантия физического времени любого устройства. Дополнительные тесты режимов: pause не меняет часы; Step Event обрабатывает ровно одно событие; скорость не меняет сетевой результат; Step PDU ограничен бюджетом. Для STP/OSPF проверять несовместимые параметры.

### 6.2. Производительность

Референсный стенд (предложение): x86-64, 4+ физических ядра, 16 ГБ RAM, SSD. Фиксировать CPU/GPU/OS/toolchain/commit/seed; macOS ARM — отдельный отчёт.

| Метрика | Gate MVP | Цель развития |
|---|---:|---:|
| Топология, устройств / линий | 100 / 200 | 1000 / 5000 |
| Headless throughput без GUI/экспорта | ≥20 000 событий/с | ≥100 000 |
| GUI FPS при редактировании | медиана ≥45 | 60 |
| P95 GUI-команды (без сходимости) | ≤150 мс | ≤100 мс |
| RSS приложения на топологии MVP | ≤1 ГиБ | отдельный замер большой сети |
| Открытие тестового проекта | ≤3 с | ≤5 с для крупной сети |
| Детерминизм контрольных повторов | 100% | 100% |

Методика: release --locked, 3 прогрева, 10 замеров, throughput медиана; p95 по ≥1000 команд. Зафиксировать topology, traffic mix ARP/ICMP/UDP, event count, seed и конфигурацию trace в fixtures. Отдельный замер full trace/PCAP. Нагрузочный тест 60 с плюс soak 30 мин. Baseline M2; уточнение порогов только через документированное решение, не молчаливое изменение при провале.

### 6.3. Качество и точность

- Все CI проверки проходят; 100% обязательных функциональных тестов; нет открытых критических/блокирующих дефектов и необработанных критических уязвимостей.
- Целевое покрытие строк core/engine ≥80%, protocols ≥70%. Покрытие не заменяет тестирование поведения.
- Все заявленные CLI команды имеют источник и положительный/отрицательный тест; отдельно публикуется доля hardware_verified. Все заявленные Web UI поля работают с реальным состоянием симуляции.
- Fuzz CLI, JSON, packet parsers: ≥30 минут на цель перед MVP на доступном стенде; воспроизводимые panic исправить.
- Пилот: 5–10 добровольцев, цель ≥80% завершают базовую лабораторию без помощи разработчика (предварительное предложение).

### 6.4. Отчёт и сопровождение

`docs/quality/releases/v0.1.0.md`: commit, toolchain, профили/версии ПО, стенд, результаты AT01–AT16, CI URLs, benchmark CSV/JSON, coverage, conformance matrix, unsupported, известные дефекты, go/no-go и ответственный. Непроведённый тест помечать not run, а не pass.

GitHub Issues: bug/protocol/device/CLI, severity, воспроизводимая топология, версия профиля, ожидаемый и фактический результат. Диагностический bundle экспортируется по явному действию с предупреждением о конфиденциальности конфигураций. Обязательной телеметрии нет. Предлагаемый процесс: ежемесячный triage, обновление roadmap и регрессионных fixtures.

### 6.5. Блокеры и открытые решения

| Риск | Действие |
|---|---|
| Нет полных MES/ESR руководств среди вложений | Для ESR найден официальный справочник 1.34 и каталог; для MES найдено упоминание MES2428 в базе знаний, но нужен точный CLI reference. Определить аппаратную ревизию и профиль ПО. |
| Cisco ICND 2007 — учебные сканы | Сверить конкретные модели и версии IOS, собрать эталонные CLI сессии. |
| Реалистичная симуляция увеличивает объём | Поэтапные профили, матрица поддерживаемых функций, явный unsupported. |
| Зависимости Rust не испытаны вместе | Сборка M1, фиксация MSRV и lockfile, audit. |
| Нагрузочные показатели гипотетические | Baseline M2, фиксированный benchmark, измеряемые gates. |
| Нет подтверждения на физическом оборудовании | Hardware tests либо явная маркировка doc_verified. |
| GitHub, подпись релизов | Репозиторий ещё не создан; аккаунт, runners и сертификаты не предоставлены. |
| Лицензии документации и ресурсов | Не распространять оригинальные PDF, фирменные ресурсы или прошивки без разрешений. |

### 6.6. Следующий шаг

M1/Foundation: создать локальный Cargo Workspace, MIT LICENSE, README, ADR-001 (DES), ADR-002 (profile schema), contracts, CI workflow; проверить сборку. Первый вертикальный срез после ядра: два ПК и коммутатор с ARP/ICMP, затем VLAN и маршрутизаторы. Репозиторий, бинарники и испытания не входят в текущую поставку документа.

## Need Professional Help in Developing Your Architecture?

Please contact me at [sammuti.com](https://sammuti.com) :)
