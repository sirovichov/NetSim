# NetSim Studio 0.0.9 — actual verification report

## Performed in the delivery environment

| Check | Result |
|---|---|
| Read exact v0.0.8 ZIP and extract | PASS |
| Retain all 160 previous files | PASS |
| Repository check script (Python) | PASS |
| 20 local crates, dependency DAG, manifest inheritance | PASS |
| JSON Schema definition validation (4 schemas) | PASS |
| Device profile JSON validation (9 profiles) | PASS |
| Example projects validated against their declared schemas (3 projects) | PASS |
| YAML syntax parse (3 files) | PASS |
| `cargo`, `rustc`, `rustfmt` lookup | NOT FOUND |
| Dependency resolution and new Cargo.lock | NOT RUN |
| Compilation / cargo test / clippy / rustfmt | NOT RUN |
| Native GUI smoke and Wireshark interoperability | NOT RUN |
| Throughput / memory benchmarks | NOT RUN |

The test annotation count from the source tree is 98 (previous 88,
new 10). This is a textual count, not a cargo test execution result.
The 13 lab reference scenarios are covered by one loop test; none has been
executed in this environment.

## Known gaps and decisions

- No compiler, no dependency download; no verified lockfile. Existing Rust
  formatting is not guaranteed. CI runs build/tests before formatting so that
  formatting failures do not mask compile diagnostics.
- Corrected stale release workflow tag (0.0.7 → 0.0.9).
- Original vendor DHCP and OSPF configuration syntax is not implemented;
  simulator service commands are separate and persisted through Project v3.
- Worker executes Step, Advance, CLI and Grade, but is not a permanent actor:
  editor operations use the GUI thread and the GUI is blocked during jobs.
- Undo/Redo is document-based and discards transient state; failed edits may
  leave a redundant history checkpoint. No separate CLI configuration undo.
- PCAP uses transmitted Ethernet bytes, virtual enqueue timestamps, no FCS,
  merged links, includes frames lost after scheduling. Radio encapsulation
  and full layer-5/6 inspection are not modeled.
- Labs are original exercises with generated starter/reference topologies,
  not copies of vendor guides. Lab instructions are English; no full authoring UI.
- Existing educational OSPF/STP/WPA2/DHCP limitations remain.
- No verified binary distributions or GitHub release have been created.

## Reproduction

```bash
cargo generate-lockfile
cargo fetch --locked
cargo fmt --all
cargo test --workspace --locked
cargo clippy --workspace --all-targets --locked -- -D warnings
cargo build --workspace --release --locked
cargo test -p netsim-app --test beta --locked -- --nocapture
cargo run --locked -p netsim-cli -- labs
cargo run --locked -p netsim-cli -- capture-ping examples/two-pcs.netsim 1 10.0.0.2 capture.pcap
cargo run --locked -p netsim-gui
```

The release is **not accepted** until these checks succeed on the target OSes.
