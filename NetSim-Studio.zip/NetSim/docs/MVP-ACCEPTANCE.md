# v0.1.0 release gates (not yet satisfied)

The source ZIP is a release candidate, not a verified release. Do not tag
or publish a final release until the following have been checked.

| Gate | How to verify |
|---|---|
| Dependency resolution | Use the committed Cargo.lock with --locked on every target |
| Compilation/tests | cargo check, cargo test, cargo build --release with --locked |
| Lints | cargo fmt --all -- --check and cargo clippy --workspace --all-targets --locked -- -D warnings |
| Lab references | `netsim-cli lab-verify`: LAB-001 to LAB-013 each 100/100 and exit zero |
| PCAP | `verify_release.py --tshark` on Linux checks ARP and ICMP against actual capture |
| Native GUI smoke | load two-pc topology; render and exit through --gui-smoke |
| Installation | install DEB/Setup, mount DMG and run installed CLI; GUI smoke on Linux |
| Manual GUI | drag/drop, connect/delete, undo/redo, CLI, Wi-Fi, RU/EN, save/load, inspect/export, restart |
| Performance | run scheduler and capacity tests in release mode; record host, events/s, peak RSS and frame time |
| Dependency licenses | review Cargo metadata and include all required third-party notices before distribution |
| Security | review dependency advisories, file import and credentials; fix blocking defects |
| Distribution | verify package checksums, Windows reputation/signing and Apple notarization decisions |

CI matrix uses Linux 24.04 x64/ARM64, Windows Server 2022 x64, macOS 15 Intel/ARM.
It does not establish support for every older OS version. macOS ad-hoc signing
is not notarization; Windows installer is unsigned. No binary is included in the
source candidate. Linux DEB is built against the runner's system libraries;
older distributions need separate compatibility testing.

The current educational implementation still has the documented Beta limitations:
non-RFC OSPF messages, simplified STP/DHCP/WPA2, no original vendor DHCP/OSPF CLI,
subset of WEP Web UI, blocking edits while worker owns the document, limited localization.
No performance thresholds have been measured; 1000 devices and 100k events/s are
design targets, not claims. See approved specification and BETA-VERIFICATION.md.
