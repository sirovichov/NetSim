# Desktop Edition v0.0.7 — verification status

The input was the complete v0.0.6 source ZIP, not a reimplementation.
No cargo, rustc, or rustfmt executable is available in the delivery environment.
The source is not a verified release; no binary is claimed.

## Dependency decision
Use eframe 0.31.1 (glow, default_fonts, x11, wayland) instead of the
latest release to retain the existing Rust 1.85.1 toolchain. The upstream 0.31.1 workspace declares rust-version=1.81 (https://raw.githubusercontent.com/emilk/egui/0.31.1/Cargo.toml). See
https://docs.rs/crate/eframe/0.31.1 and
https://docs.rs/crate/eframe/0.31.1/features .
serde and serde_json are exact direct dependencies. Compatibility with the full
resolved graph and target OS libraries still requires Cargo and matrix CI.

The old lockfile is archived, not valid for this revision. Generate the root
Cargo.lock; CI shares it between runners. Commit it once verified.

## Design
Desktop owns MixedLab. Topology positions and stable document IDs are separate
from runtime IDs. Port name + stable node ID is the persistent link endpoint.
Loading builds a new engine before replacing the active document; vendor configs
are deserialized as data and their port IDs/MACs are remapped to created ports.
Imported IPv4 prefixes use a validated deserializer. Save uses a bounded JSON
format and a same-directory exclusive temporary file + sync + rename. No arbitrary
CLI replay. Pending ESR commits are rejected by export.

The UI advances the same event scheduler as earlier demos. An individual
step can process a management deadline instead of a packet event; event trace is
not a full PDU inspector. Real-time advancement is limited per update, drops
wall-clock catch-up under load, and does not promise exact synchronization.
Existing synchronous vendor CLI diagnostics can advance time even in Simulation;
the separate Send packet button provides asynchronous ICMP.

## Verification
Rust tests are supplied for JSON round-trip, invalid version and cable,
migration of the old empty template, mixed-vendor config persistence,
host ping via stepping, cable removal, pending ESR save rejection and
invalid port loading. None executed in delivery environment.
CI strict formatting and Clippy may fail on preexisting code; resolve issues
before any release. Native smoke launches a window and closes after two frames
on Linux/Xvfb; interactive UI tests still need manual verification.

## Manual acceptance
- Drop and move each of seven active model types; zoom/pan.
- Connect distinct free ports, reject occupied ports, delete cable/node.
- Configure Cisco/Eltex through CLI and host IP via properties.
- Open two-PC project, run ping in Simulation and Real-Time; inspect trace.
- Save/reopen running/startup config, topology and coordinates.
- Verify invalid file leaves current project unchanged; reject pending ESR commit.
- Switch RU/EN; verify Cyrillic rendering and DPI on Windows/Linux/macOS.

Static checks performed: local 20-crate graph acyclic; all JSON schemas and nine device profiles validated; both example projects validated; YAML parsed. No compilation, rustfmt, Clippy, Cargo resolution, or Rust test execution.
