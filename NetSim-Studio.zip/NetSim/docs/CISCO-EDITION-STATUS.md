# v0.0.5 Cisco Edition — статус и приёмка

Основа: ZIP v0.0.4 L3 Networking. Все 20 crates и прежние файлы сохранены.
Новые компоненты: `netsim-cisco/src/ios/{config,parser,mod}.rs`,
`netsim-engine/src/engine/management.rs`, `netsim-app/src/cisco_lab.rs`.
Состояние L2 и L3 меняется через typed API без системных сетевых операций.

## Контрольные сценарии

- Режимы User/Privileged/Global/Interface/VLAN, независимые сессии.
- Сокращения, уникальная Tab-подстановка, неоднозначный/неполный ввод.
- Сохранение startup config, восстановление после reload и erase.
- VLAN/trunk/native/allowed, отключение интерфейсов.
- CLI настраивает живую виртуальную сеть; ARP и ICMP через коммутатор.
- Router-on-a-stick и отключение физического интерфейса.
- Статические маршруты, default route, вывод активных маршрутов.
- Ошибочные маски, VLAN, duplicate dot1Q не должны менять конфигурацию.
- Процесс `netsim-cli` в режиме scripted stdin.

## Известные ограничения

Учебный профиль 2960 с 24 FastEthernet и 2 GigabitEthernet — выбранный вариант,
2911 — три гигабитных интерфейса; нет модулей, serial, PoE и SKU-вариантов.
Адаптер создаётся через `CiscoDevice::create` или `CiscoLab::add`; фабрики
черновых устройств, worker и старый `EngineCommand::ExecuteCli` остаются
совместимыми с v0.0.4, но старый callback не обслуживает этот IOS CLI.
GUI и асинхронный IOS API будут отдельным этапом.

Нет SVI (interface vlan), IP default-gateway на коммутаторе, паролей, VTY,
SSH, CDP, VTP, DTP, PVST+/Rapid-PVST, `interface range`, `setup`, динамической
маршрутизации, native dot1Q подынтерфейса, ECMP/recursive routes и файловой
NVRAM. На коммутаторе используется общее STP, не отдельное дерево для каждой VLAN.
Вывод show синтетический и не побайтовая копия IOS. CLI reload не запрашивает
подтверждения, startup хранится в памяти; внешний power cycle через Engine
самостоятельно startup не восстанавливает. Не реализованы полноформатный
терминальный редактор и paging. Время движется явно, ping/traceroute используют
бюджеты событий. При изменениях маршрутизатора динамические ARP/pending/probes
консервативно очищаются; физический порт не перезагружается.
VLAN membership находится в running/startup вместо отдельной vlan.dat.
Сетевые параметры коммутатора настраиваются через физические порты;
нет полной идентичности реальному оборудованию.

Компилятор, cargo, rustfmt и clippy в среде поставки отсутствуют. Тесты
написаны, но не исполнялись. Нужен успешный CI до приёмки.

## Статические проверки поставки

- 20 crates, Cargo.lock согласован с Cargo.toml; граф без циклов.
- Все 124 файла предыдущего архива присутствуют (часть обновлена).
- 9 черновых JSON-профилей проверены по JSON Schema.
- YAML GitHub Actions синтаксически разобран.
- 63 Rust test annotations (54 прежних + 9 новых).
- Компиляция, форматирование, Clippy и запуск тестов не выполнялись.
