# NetSim Studio — v0.0.6 Eltex Edition

Независимый учебный симулятор сетей на Rust Edition 2024, MIT.
Целевые платформы: Windows, Linux, macOS. Источники подготовлены, компиляция не подтверждена.

## Eltex Edition

```bash
cargo run -p netsim-cli -- eltex mes
cargo run -p netsim-cli -- eltex esr
cargo run -p netsim-cli -- eltex-demo
```

В ESR используйте `configure`, `ip address 10.0.0.1/24`, `end`, `commit`, `confirm`.
В MES — `enable`, `configure terminal`, `write startup-config`.
В обеих консолях `:quit` завершает работу; `:advance 120` продвигает виртуальное время
на 120 секунд. `eltex-demo` использует общую топологию Cisco ISR / MES / ESR.
Ожидаемый результат (не проверен запуском): `Cisco/Eltex simulation successful`.
[Команды и официальные источники](docs/cli-reference/ELTEX.md).
[Статус и ограничения](docs/ELTEX-EDITION-STATUS.md).

## Запуск

Установите [rustup](https://rustup.rs/) и системный linker (MSVC Build Tools на Windows,
Xcode Command Line Tools на macOS). Toolchain 1.85.1 закреплён в rust-toolchain.toml.
Внешних Rust-зависимостей нет.

```bash
cargo fmt --all
cargo build --workspace --locked --offline
cargo test --workspace --locked --offline
cargo run -p netsim-cli -- cisco router
cargo run -p netsim-cli -- cisco switch
cargo run -p netsim-cli -- cisco-demo
```

Пример консоли маршрутизатора:

```text
Router> en
Router# conf t
Router(config)# hostname R1
R1(config)# int gi0/0
R1(config-if)# ip address 192.168.1.1 255.255.255.0
R1(config-if)# no shut
R1(config-if)# end
R1# show ip interface brief
R1# copy running-config startup-config
R1# :quit
```

Без кабеля интерфейс остаётся operational down. В `cisco-demo` создаются два
маршрутизатора и коммутатор; настройки через CLI, реальная виртуальная передача
ARP/ICMP, вывод MAC-таблицы. Ожидаемый, не подтверждённый запуском результат:
`Cisco IOS simulation successful`. `?` или `help` показывают доступные команды.
Для Tab API возвращает дополненную строку; в line-oriented консоли Tab
обрабатывается после Enter, если терминал передаёт символ табуляции.
`:quit` завершает консоль. Время продвигается при ping/traceroute или через API.

Команды `catalog`, `demo`, `core-demo`, `l2-demo`, `l3-demo` сохранены.
`netsim-gui` всё ещё зарезервированная точка входа.

## Документация и проверка

- [Спецификация](docs/specification/SPEC-001-NetSim-Studio.md)
- [Статус Cisco Edition](docs/CISCO-EDITION-STATUS.md)
- [Справочник команд и соответствие источникам](docs/cli-reference/CISCO-IOS.md)
- [ADR-006](docs/architecture/ADR-006-cisco-cli.md)
- [L3 Networking](docs/L3-NETWORKING-STATUS.md)
- [L2 Networking](docs/L2-NETWORKING-STATUS.md)
- [Simulation Core](docs/SIMULATION-CORE-STATUS.md)

```bash
python3 scripts/check_repository.py
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --locked --offline -- -D warnings
cargo test --workspace --locked --offline
cargo build --workspace --release --locked --offline
```

Python 3.11+ для статической проверки. Lockfile составлен из локальных
манифестов, Cargo ещё не проверял его. Если `--locked` требует изменения,
запустите `cargo generate-lockfile --offline` и проверьте diff.
GitHub Actions на Windows/Linux/macOS выполняет эти проверки, выпуск
черновика Release после успешного CI по тегу v0.0.5.

## Архитектура

`netsim-cisco::ios::CiscoDevice` — адаптер Cisco поверх vendor-neutral `Engine`.
`netsim-app::CiscoLab` владеет движком и экземплярами консолей, обрабатывает
команды на границе событий. Старый `create_engine` сохранён для низкоуровневого API:
`Engine::add_device` по-прежнему создаёт черновой профиль без автопортов.
Для Cisco с CLI используйте `CiscoDevice::create` либо `CiscoLab::add`.

Каталог из 9 JSON-профилей остаётся черновым. Поддержка CLI относится к
реализации адаптера, а не к сертифицированному совпадению с определённой IOS.
Startup config хранится в памяти объекта и восстанавливается командой `reload`;
не сохраняется между запусками программы. Нет SVI, оригинальных прошивок,
SSH/Telnet, аутентификации, VTP/PVST+, DHCP/OSPF и графического интерфейса.
Исходники и тесты требуют проверки компилятором.
