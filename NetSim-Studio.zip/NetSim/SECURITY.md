# Security

Foundation is pre-release and not a production network tool. Do not use it with
untrusted projects until parsers and resource limits are implemented. Report
security issues privately via GitHub Security Advisories once the repository
owner enables them. Do not post credentials, private configurations or sensitive
packet captures publicly.
