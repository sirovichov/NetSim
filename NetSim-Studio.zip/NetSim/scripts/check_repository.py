"""Offline structural checks. Not a replacement for Cargo or full JSON Schema validation."""
from pathlib import Path
import json
import re
import tomllib

ROOT = Path(__file__).resolve().parents[1]
workspace = tomllib.loads((ROOT / "Cargo.toml").read_text(encoding="utf-8"))
version = workspace["workspace"]["package"]["version"]
crates = {}
for manifest in sorted(ROOT.glob("crates/*/Cargo.toml")):
    doc = tomllib.loads(manifest.read_text(encoding="utf-8"))
    name = doc["package"]["name"]
    assert name == manifest.parent.name
    assert doc["package"]["version"]["workspace"]
    assert doc["lints"] == {"workspace": True}, f"Unexpected keys under [lints] in {name}"
    declared = set(doc.get("dependencies", {})) | set(doc.get("dev-dependencies", {}))
    namespaces = {d.replace("-", "_") for d in declared} | {name.replace("-", "_")}
    for source in manifest.parent.rglob("*.rs"):
        used = set(re.findall(r"\b(netsim_[a-z_]+|serde_json|serde|eframe)::", source.read_text(encoding="utf-8")))
        assert used <= namespaces, f"Undeclared namespace(s) in {source}: {used-namespaces}"
    assert name not in crates
    assert any((manifest.parent / "src" / entry).is_file() for entry in ("lib.rs", "main.rs"))
    crates[name] = {d for d in doc.get("dependencies", {}) if d.startswith("netsim-")}
assert len(crates) == 20
assert {d for d in workspace["workspace"]["dependencies"] if d.startswith("netsim-")} == set(crates)
assert set(workspace["workspace"]["dependencies"])-set(crates)=={"eframe","serde","serde_json"}
assert all(d in crates for ds in crates.values() for d in ds)
assert not {"netsim-cisco", "netsim-eltex", "netsim-generic"} & crates["netsim-engine"]

def visit(name, active, visited):
    assert name not in active, f"Dependency cycle: {name}"
    if name in visited:
        return
    for dep in crates[name]:
        visit(dep, active | {name}, visited)
    visited.add(name)

visited = set()
for name in crates:
    visit(name, set(), visited)

lock_path = ROOT / "Cargo.lock"
lock = tomllib.loads(lock_path.read_text(encoding="utf-8"))
assert lock["version"] == 4
local = {p["name"]:p for p in lock["package"] if "source" not in p}
assert set(local) == set(crates)
assert all(p["version"] == version for p in local.values())
for name,p in local.items():
    assert {d.split()[0] for d in p.get("dependencies",[]) if d.startswith("netsim-")} == crates[name]

schema = json.loads((ROOT / "schemas/device-profile-v1.schema.json").read_text(encoding="utf-8"))
profiles = {}
for path in sorted((ROOT / "catalog").rglob("*.json")):
    data = json.loads(path.read_text(encoding="utf-8"))
    assert set(data) == set(schema["required"])
    assert data["id"] == path.stem and data["id"] not in profiles
    assert data["schema_version"] == data["profile_version"] == 1
    assert data["verification_status"] == "draft"
    if data["id"] in ("eltex.switch.mes2428", "eltex.router.esr100"):
        assert len(data["ports"]) == (28 if data["device_type"] == "switch" else 4)
        assert "cli" in data["implemented_features"]
        assert len({p["id"] for p in data["ports"]}) == len(data["ports"])
    elif data["device_type"] == "access_point":
        assert len(data["ports"]) == 3 and "wifi_association_model" in data["implemented_features"]
    else:
        assert not data["implemented_features"]
        assert data["ports"] == []
    profiles[data["id"]] = data
assert len(profiles) == 9

# Detect drift between static Rust registry and draft JSON files.
registered = set()
for vendor in ("cisco", "eltex", "generic"):
    source = (ROOT / f"crates/netsim-{vendor}/src/lib.rs").read_text(encoding="utf-8")
    registered.update(re.findall(r'profile_id: "([^"]+)"', source))
assert registered == set(profiles)
for path in (ROOT / "schemas").glob("*.json"):
    json.loads(path.read_text(encoding="utf-8"))
json.loads((ROOT / "examples/empty.netsim").read_text(encoding="utf-8"))
assert not list(ROOT.rglob("*.pdf")), "Vendor PDFs must not be redistributed"
print(f"OK: {len(crates)} crates, acyclic graph, local manifest checks, {len(profiles)} draft profiles")

# Optional full validation (installed explicitly in release CI).
try:
    import jsonschema
except ImportError:
    print("NOTICE: install jsonschema for full schema validation")
else:
    schemas = {p.stem: json.loads(p.read_text(encoding="utf-8")) for p in (ROOT/"schemas").glob("*.json")}
    for spec in schemas.values():
        jsonschema.Draft202012Validator.check_schema(spec)
    for profile in profiles.values():
        jsonschema.validate(profile, schemas["device-profile-v1.schema"])
    for example in (ROOT/"examples").glob("*.netsim"):
        doc = json.loads(example.read_text(encoding="utf-8"))
        jsonschema.validate(doc, schemas[f'project-v{doc["schema_version"]}.schema'])
    print("OK: full JSON Schema validation")
