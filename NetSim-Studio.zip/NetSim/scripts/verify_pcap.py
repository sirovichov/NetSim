"""Independent classic PCAP structural and ARP/ICMP smoke validator."""
import struct
import sys
from pathlib import Path

def validate(data: bytes):
    if len(data) < 24:
        raise ValueError("truncated PCAP header")
    magic, major, minor, _, _, snaplen, link = struct.unpack_from("<IHHIIII", data)
    if (magic, major, minor, link) != (0xA1B23C4D, 2, 4, 1) or not snaplen:
        raise ValueError("expected nanosecond Ethernet PCAP 2.4")
    pos, count, previous = 24, 0, -1
    seen = set()
    while pos < len(data):
        if len(data) - pos < 16:
            raise ValueError("truncated record header")
        sec, ns, incl, orig = struct.unpack_from("<IIII", data, pos)
        pos += 16
        ts = sec * 1_000_000_000 + ns
        if ns >= 1_000_000_000 or ts < previous or not 14 <= incl <= snaplen or orig != incl or pos + incl > len(data):
            raise ValueError("invalid record")
        previous = ts
        frame = data[pos:pos + incl]
        pos += incl
        count += 1
        ethertype = int.from_bytes(frame[12:14], "big")
        off = 14
        if ethertype == 0x8100 and len(frame) >= 18:
            ethertype = int.from_bytes(frame[16:18], "big")
            off = 18
        if ethertype == 0x0806 and len(frame) >= off + 28:
            op = int.from_bytes(frame[off+6:off+8], "big")
            if op in (1, 2):
                seen.add(f"arp-{op}")
        if ethertype == 0x0800 and len(frame) >= off + 20 and frame[off+9] == 1:
            ihl = (frame[off] & 15) * 4
            if ihl >= 20 and len(frame) >= off+ihl+8:
                seen.add(f"icmp-{frame[off+ihl]}")
    required = {"arp-1", "arp-2", "icmp-8", "icmp-0"}
    if not required <= seen:
        raise ValueError(f"missing protocols: {sorted(required-seen)}")
    return count

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: verify_pcap.py FILE")
    print(f"PCAP structural smoke: {validate(Path(sys.argv[1]).read_bytes())} frames")
