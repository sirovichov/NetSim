"""Run built release binaries, never substitutes fixtures for actual simulation."""
from pathlib import Path
import argparse
import os
import subprocess
import sys
from verify_pcap import validate

ROOT = Path(__file__).resolve().parents[1]

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--bin-dir", type=Path, default=ROOT / "target/release")
    p.add_argument("--output", type=Path, default=ROOT / "verification")
    p.add_argument("--gui", action="store_true")
    p.add_argument("--tshark", action="store_true")
    args = p.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    suffix = ".exe" if os.name == "nt" else ""
    cli = args.bin_dir.resolve() / ("netsim-cli" + suffix)
    gui = args.bin_dir.resolve() / ("netsim-gui" + suffix)
    def run(name, command, timeout=180):
        print(name, flush=True)
        with (out / (name+".log")).open("w", encoding="utf-8") as log:
            proc = subprocess.run([str(c) for c in command], cwd=ROOT, text=True,
                                  encoding="utf-8", errors="replace", stdout=log,
                                  stderr=subprocess.STDOUT, timeout=timeout)
        if proc.returncode:
            raise RuntimeError(f"{name} failed: {proc.returncode}; see {out}")
        return (out / (name+".log")).read_text(encoding="utf-8")
    version = run("version", [cli, "--version"])
    if version.strip() != "NetSim Studio 0.1.0":
        raise RuntimeError("unexpected executable version")
    for name in ["catalog", "demo", "core-demo", "l2-demo", "l3-demo", "cisco-demo", "eltex-demo", "wireless-demo"]:
        run(name, [cli, name])
    for project in sorted((ROOT / "examples").glob("*.netsim")):
        run("validate-" + project.stem, [cli, "validate", project])
    report = run("labs", [cli, "lab-verify"], timeout=600)
    for i in range(1, 14):
        if f"LAB-{i:03}: 100/100 PASS" not in report.splitlines():
            raise RuntimeError(f"missing or failed lab {i}")
    capture = out / "smoke.pcap"
    run("capture", [cli, "capture-ping", ROOT/"examples/two-pcs.netsim", "1", "10.0.0.2", capture])
    print(f"PCAP structural validation: {validate(capture.read_bytes())} frames")
    if args.tshark:
        for name, filt in [("arp-request", "arp.opcode == 1"), ("arp-reply", "arp.opcode == 2"), ("echo-request", "icmp.type == 8"), ("echo-reply", "icmp.type == 0")]:
            result = run("tshark-"+name, ["tshark", "-r", capture, "-Y", filt, "-T", "fields", "-e", "frame.number"])
            if not any(line.strip().isdigit() for line in result.splitlines()):
                raise RuntimeError(f"tshark did not decode {name}")
    if args.gui:
        run("gui-smoke", [gui, "--gui-smoke"], timeout=60)
    print("Acceptance commands passed on this host")

if __name__ == "__main__":
    main()
