import struct
import unittest
from verify_pcap import validate

def fixture():
    # Synthetic data only, not simulator output.
    h = struct.pack("<IHHIIII", 0xA1B23C4D, 2, 4, 0, 0, 65535, 1)
    frames = []
    for op in (1, 2):
        arp = bytearray(28)
        arp[6:8] = op.to_bytes(2, "big")
        frames.append(bytes(12)+b"\x08\x06"+arp)
    for typ in (8, 0):
        ip = bytearray(28)
        ip[0], ip[9], ip[20] = 0x45, 1, typ
        frames.append(bytes(12)+b"\x08\x00"+ip)
    return h+b"".join(struct.pack("<IIII", 0, i, len(f), len(f))+f for i,f in enumerate(frames))

class PcapTests(unittest.TestCase):
    def test_four_records(self):
        self.assertEqual(validate(fixture()), 4)
    def test_truncated(self):
        with self.assertRaises(ValueError):
            validate(fixture()[:-1])
    def test_missing_protocol(self):
        data = fixture()
        with self.assertRaises(ValueError):
            validate(data[:24])
    def test_wrong_magic(self):
        with self.assertRaises(ValueError):
            validate(b"XXXX"+fixture()[4:])
