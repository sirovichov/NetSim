"""Native packaging; invoke after release build and acceptance tests."""
import argparse
import os
from pathlib import Path
import platform
import plistlib
import shutil
import subprocess
import tempfile
import tomllib

ROOT = Path(__file__).resolve().parents[1]
VERSION = tomllib.loads((ROOT/"Cargo.toml").read_text(encoding="utf-8"))["workspace"]["package"]["version"]

def run(*args):
    subprocess.run([str(x) for x in args], check=True)

def copy_exe(src, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
    if os.name != "nt":
        dest.chmod(0o755)

def resources(dest):
    dest.mkdir(parents=True, exist_ok=True)
    for name in ("LICENSE", "README.md"):
        shutil.copy2(ROOT/name, dest/name)
    shutil.copytree(ROOT/"examples", dest/"examples", ignore=shutil.ignore_patterns("*.txt"))

def package_linux(bin_dir, out, work, arch):
    tree = work/"deb"
    for name in ("netsim-gui", "netsim-cli"):
        copy_exe(bin_dir/name, tree/"usr/bin"/name)
    desktop = tree/"usr/share/applications"
    desktop.mkdir(parents=True)
    shutil.copy2(ROOT/"packaging/linux/netsim-studio.desktop", desktop)
    resources(tree/"usr/share/netsim-studio")
    doc = tree/"usr/share/doc/netsim-studio"
    doc.mkdir(parents=True)
    shutil.copy2(ROOT/"LICENSE", doc/"copyright")
    control = tree/"DEBIAN"
    control.mkdir()
    (control/"control").write_text(
        f"Package: netsim-studio\nVersion: {VERSION}\nArchitecture: {arch}\n"
        "Maintainer: NetSim Studio Contributors <netsim@example.invalid>\n"
        "Section: education\nPriority: optional\n"
        "Depends: libc6, libgcc-s1, libgl1, libx11-6, libxkbcommon0, libwayland-client0, libxcb1\n"
        "Description: Educational virtual network simulator\n", encoding="utf-8")
    path = out/f"netsim-studio_{VERSION}_{arch}.deb"
    run("dpkg-deb", "--root-owner-group", "--build", tree, path)
    run("dpkg-deb", "--info", path)
    return path

def package_macos(bin_dir, out, work, arch):
    stage = work/"disk"
    app = stage/"NetSim Studio.app"/"Contents"
    for name in ("netsim-gui", "netsim-cli"):
        copy_exe(bin_dir/name, app/"MacOS"/name)
    resources(app/"Resources")
    (app/"Info.plist").write_bytes(plistlib.dumps({
        "CFBundleIdentifier": "org.netsimstudio.desktop",
        "CFBundleName": "NetSim Studio",
        "CFBundleDisplayName": "NetSim Studio",
        "CFBundleExecutable": "netsim-gui",
        "CFBundlePackageType": "APPL",
        "CFBundleShortVersionString": VERSION,
        "CFBundleVersion": VERSION,
        "NSHighResolutionCapable": True,
    }))
    (stage/"Applications").symlink_to("/Applications")
    run("codesign", "--force", "--sign", "-", "--timestamp=none", app/"MacOS/netsim-cli")
    run("codesign", "--force", "--sign", "-", "--timestamp=none", app.parent)
    run("codesign", "--verify", "--deep", "--strict", app.parent)
    path = out/f"NetSim-Studio-{VERSION}-macos-{arch}.dmg"
    run("hdiutil", "create", "-ov", "-volname", "NetSim Studio", "-srcfolder", stage, "-format", "UDZO", path)
    run("hdiutil", "verify", path)
    return path

def package_windows(bin_dir, out):
    iscc = shutil.which("ISCC.exe") or str(Path(os.environ.get("ProgramFiles(x86)", r"C:\\Program Files (x86)"))/"Inno Setup 6"/"ISCC.exe")
    run(iscc, f"/DBuildDir={bin_dir}", f"/DOutputDir={out}", f"/DRepoDir={ROOT}", ROOT/"packaging/windows/netsim.iss")
    return out/f"NetSim-Studio-{VERSION}-windows-x64-setup.exe"

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--bin-dir", type=Path, default=ROOT/"target/release")
    p.add_argument("--output", type=Path, default=ROOT/"dist")
    args = p.parse_args()
    b, out = args.bin_dir.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    suffix = ".exe" if os.name == "nt" else ""
    for name in ("netsim-gui", "netsim-cli"):
        if not (b/(name+suffix)).is_file():
            raise SystemExit(f"Missing built executable: {name}")
    actual = subprocess.check_output([str(b/("netsim-cli"+suffix)), "--version"], text=True).strip()
    if actual != f"NetSim Studio {VERSION}":
        raise SystemExit(f"Wrong CLI version: {actual}")
    with tempfile.TemporaryDirectory(prefix="netsim-package-") as td:
        work = Path(td)
        if platform.system() == "Linux":
            arch = subprocess.check_output(["dpkg","--print-architecture"], text=True).strip()
            path = package_linux(b,out,work,arch)
        elif platform.system() == "Darwin":
            path = package_macos(b,out,work,platform.machine())
        elif platform.system() == "Windows" and platform.machine().lower() in ("amd64","x86_64"):
            path = package_windows(b,out)
        else:
            raise SystemExit("Unsupported packaging host")
    if not path.is_file() or not path.stat().st_size:
        raise SystemExit("Package missing")
    print(path)

if __name__ == "__main__":
    main()
