# assets/devices

Reserved for a later milestone; no implementation or licensed vendor assets included.
