# Contribution policy

Open an issue identifying the SPEC requirement and acceptance tests. Create a branch,
write tests and update docs/ADRs for changes. All CI checks and review are required
before merge. Do not add unlicensed vendor documents, logos or firmware. Never send
real network traffic or run vendor CLI through the host shell. Keep the engine
independent from vendor crates and GUI. Add source and test references for
every supported device capability; distinguish document and hardware verification.
