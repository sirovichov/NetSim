# NetSim Studio — v0.1.0 MVP Release Candidate

Учебный симулятор Cisco / Eltex на Rust, MIT. Windows, Linux, macOS.
В этой редакции восстановлено создание ПК, ноутбуков и серверов. На Linux x86_64 проверены сборка и все 13 эталонных лабораторий. Проект остаётся кандидатом на выпуск.

## Сборка

Установите [rustup](https://rustup.rs/) и системный linker:
MSVC Build Tools (Windows), Xcode Command Line Tools (macOS).
Linux (Debian/Ubuntu):

```bash
sudo apt-get install build-essential libxcb-render0-dev libxcb-shape0-dev libxcb-xfixes0-dev libxkbcommon-dev libssl-dev libgl1-mesa-dev libwayland-dev pkg-config
```

Rust 1.85.1 / Edition 2024. eframe =0.31.1 (glow, X11, Wayland),
serde =1.0.219, serde_json =1.0.140. Версии прямых и транзитивных зависимостей зафиксированы в корневом Cargo.lock.
Старый lockfile находится в docs/Cargo-v0.0.6.lock — не используйте его для сборки.

```bash
cargo fetch --locked
cargo build --workspace --locked
cargo test --workspace --locked
cargo run --locked -p netsim-gui
```

При первой загрузке зависимостей требуется сеть. После `cargo fetch --locked` можно собирать проект с `--offline`. Все машины CI используют Cargo.lock из исходного дерева.

## Работа с GUI

1. Перетащите PC, маршрутизатор или коммутатор из каталога на поле.
   Альтернатива: щёлкните по модели, затем по рабочей области.
2. Перемещайте узлы мышью, фон — для панорамирования. Кнопки масштаба и сброса вида находятся над топологией.
3. Выберите первый узел, порт и «Выбрать конец кабеля». Выберите второй узел
   и порт, затем нажмите ту же кнопку. Кабели удаляются в свойствах.
4. Для PC/Laptop/Server задайте IPv4, CIDR и (если нужен) шлюз. Дважды щёлкните по любому устройству на схеме или нажмите «Открыть CLI» в свойствах.
   У каждого узла своё окно терминала. Можно держать несколько окон рядом. При повторном открытии в том же проекте сохраняются вывод и незаконченная команда.
   Enter выполняет команду. Кнопка `?` вызывает справку, а кнопка Tab дополняет команды Cisco.
   У ПК, ноутбуков и серверов доступны `hostname`, `ipconfig`, `ping АДРЕС` и `show probes`. На точке доступа `show clients` выводит подключённых клиентов.
5. Simulation: «Шаг» обрабатывает ближайшее событие (или дедлайн ESR);
   +1 s / +40 s продвигают время с ограничением в 4096 событий за запрос.
   Для коммутаторов подождите сходимости STP. Real-Time: «Пуск»/«Пауза» и скорость.
6. В свойствах IP-устройства введите адрес назначения и отправьте ICMP.
   В Simulation обрабатывайте шаги до получения ответа; либо используйте Real-Time.
   Журнал показывает реальные события. Жёлтые точки — анимация FrameTx,
   не точное отображение виртуальной длительности передачи.
7. В меню «Проект» введите путь к `.netsim` и нажмите «Сохранить». «Открыть» заменяет документ
   только после успешной проверки и построения новой сети. RU/EN — верхняя панель.

Пример `examples/two-pcs.netsim`: два ПК, соединённые напрямую.
Откройте проект, продвиньте время +1 s, выберите PC1, отправьте ping на 10.0.0.2.

## Headless CLI

```bash
cargo run -p netsim-cli -- cisco router
cargo run -p netsim-cli -- cisco switch
cargo run -p netsim-cli -- eltex mes
cargo run -p netsim-cli -- eltex esr
cargo run -p netsim-cli -- eltex-demo
cargo run -p netsim-cli -- wireless-demo
```

Также сохранены `catalog`, `demo`, `core-demo`, `l2-demo`, `l3-demo`, `cisco-demo`.
Подробности: [Cisco](docs/cli-reference/CISCO-IOS.md),
[Eltex](docs/cli-reference/ELTEX.md), [спецификация](docs/specification/SPEC-001-NetSim-Studio.md).

## Ограничения

- Step, Advance, CLI и Grade выполняются в worker; редактор блокируется на время задания. Постоянный actor и полностью неблокирующее редактирование не реализованы.
- Real-Time — приближение: при нагрузке или паузе окна часы могут отставать.
- `.netsim` v3 хранит топологию, seed, координаты, питание и конфигурации,
  но не виртуальное время, MAC/ARP, сеансы, события, историю пакетов.
  Из v2 выполняется миграция, из v1 — только пустой шаблон. При pending ESR commit сохранение
  отклоняется до confirm/restore. Файл ограничен 32 MiB.
- Кабели пока Ethernet 100 Mbps / 1 μs, без отдельного редактора свойств линии.
- WEP-2ac и Smart используют учебную L2-радиомодель: до 32 ассоциаций на AP, отдельные виртуальные каналы передачи, один Ethernet uplink. Нет моделирования реальных 802.11 кадров, AES, разделения эфирного времени или Mesh. DHCP сервер только на Server.
- Перевод RU/EN охватывает основные панели и действия; CLI, технические
  идентификаторы, часть статусов и ошибок остаются на английском.
- Packet Inspector и Undo/Redo имеют учебные ограничения (см. Beta ниже); физическая панель отсутствует. OSPF — модель Area 0, не совместимый с RFC 2328 wire protocol. DHCP — DORA с повторным получением адреса после истечения аренды, без T1/T2, relay и DNS. Настройки OSPF/DHCP не являются командами реального CLI.
- Проверки на Windows и macOS, а также ручная приёмка GUI остаются открытыми. Результаты локальной проверки приведены в [отчёте](docs/MVP-VERIFICATION.md).

## Wireless & Routing: лаборатория

Откройте `examples/wireless-dhcp.netsim` в GUI. Server1 имеет 10.0.0.1/24, пул
10.0.0.100–10.0.0.120, AP2 и Laptop3 связаны через VAP VLAN 1. Тестовый SSID
`NetSim`, тестовый ключ `labpass123`. Это исключительно данные лаборатории.
AP4 (Smart) расположен вне радиуса. Нажмите +40 s, затем +1 s несколько раз
для сходимости STP и завершения DHCP; в свойствах Laptop3 ожидается Bound.
Отправьте ICMP на 10.0.0.1. Перемещение ноутбука за пределы зоны покрытия
разрывает ассоциацию. Пункт Manage / VAP позволяет менять SSID, VLAN и режим
WPA Personal, Manage / Radio — диапазон и канал, Update применяет настройки.

В свойствах ноутбука выберите диапазон и откройте «Доступные сети». Список упорядочен по уровню сигнала и показывает SSID, точку доступа, канал и тип защиты. Щелчок переносит SSID в форму подключения. Для скрытой сети введите SSID вручную.

Для DHCP Server настройте статический IPv4 и затем пул в свойствах Server.
Для DHCP Client выберите PC/Laptop/Server без настроенного серверного пула.
OSPF: настройте IP-интерфейсы маршрутизаторов, соедините кабелями и в свойствах
обоих задайте уникальные Router ID, затем Enable / Apply OSPF. Дождитесь
обмена Hello/LSA. Cisco `show ip route` показывает O для динамических маршрутов.
Для тестирования обрыва удалите транзитный кабель и продвиньте время на 10 s.

PSK в файле `.netsim` хранится открытым текстом: не используйте реальные ключи.
DHCP leases, OSPF LSDB и ассоциации не являются контрольным снимком и
восстанавливаются из конфигурации после открытия. Подробнее:
[статус Wireless & Routing](docs/WIRELESS-ROUTING-STATUS.md).

## Beta: лаборатории, анализ пакетов и служебный CLI

Откройте вкладку Labs в каталоге, выберите LAB-001…LAB-013, нажмите Start
(заменяет текущую сеть), настройте оборудование, нажмите Grade. Проверка
выполняется на отдельной реконструированной копии проекта и не изменяет
текущие таблицы или время. Инструкции пока на английском.

Кнопка Packets открывает инспектор. Выберите запись, просмотрите Ethernet,
VLAN, IPv4, ICMP, UDP/DHCP и сырые байты. Export PCAP сохраняет последние
4096 попыток передачи, включая потерянные на линии кадры; время соответствует
моменту постановки в виртуальную очередь, а не аппаратной метке. Экспорт
объединяет виртуальные линии, поэтому один пакет может встречаться несколько раз.

Undo/Redo — история снимков проектов при добавлении/удалении/перемещении
узлов и подключении/отключении кабелей, до 32 снимков. При восстановлении
пересоздаются динамические таблицы, сессии, часы и очередь. Это не
реверсивное выполнение событий. Изменения CLI отдельно не протоколируются.

В GUI Step, Advance, Real-Time, CLI и Grade выполняются в worker, которому
на время операции передаётся исключительное владение Desktop. В этот момент
редактор блокирован; простые топологические операции и сохранение выполняются
в GUI. Не является полностью постоянным actor API.

```bash
cargo run --locked -p netsim-cli -- validate examples/two-pcs.netsim
cargo run -p netsim-cli -- labs
cargo run -p netsim-cli -- lab-start LAB-001 lab.netsim
cargo run -p netsim-cli -- lab-grade LAB-001 lab.netsim
cargo run -p netsim-cli -- capture-ping examples/two-pcs.netsim 1 10.0.0.2 capture.pcap
```

Команда `validate` открывает проект тем же способом, что и GUI. При успешной проверке она выводит версию схемы после загрузки, число узлов и кабелей. При ошибке возвращает ненулевой код.

Служебные команды симулятора
```
:dhcp client
:dhcp server FIRST LAST PREFIX GATEWAY_OR_- LEASE_SECONDS
:dhcp show
:ospf enable ROUTER_ID
:ospf show
```
Вводятся в терминале выбранного устройства GUI или:
```
cargo run -p netsim-cli -- service lab.netsim 1 :dhcp client
```
CLI изменяет проект на диске при настройке. Поддержка оригинальных
`ip dhcp pool`, `router ospf`, OSPF network/area, ESR commit для OSPF
и DHCP остаётся отдельной задачей. DHCP-сервер пока только Generic Server.

Отчёт о проверках: docs/BETA-VERIFICATION.md.

## v0.1.0: приёмка и установочные пакеты

```bash
cargo fetch --locked
cargo check --workspace --all-targets --locked --offline
cargo test --workspace --locked --offline
cargo build --workspace --release --locked --offline
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --locked --offline -- -D warnings
python scripts/verify_release.py --gui
python scripts/package_release.py
```

На Linux используйте `xvfb-run -a python scripts/verify_release.py --gui --tshark`
для проверки без рабочего стола. На Windows для установщика требуется Inno
Setup 6, на Linux dpkg-deb, на macOS hdiutil/codesign. GitHub Actions
проверяет Linux x64/ARM64, Windows x64, macOS Intel/Apple Silicon.
Тег v0.1.0 создаёт только черновик релиза после успешной матрицы.
Установщики неподписанные (macOS ad-hoc), без нотарификации Apple.
Не публикуйте до ручной проверки интерфейса, лицензий зависимостей и
производительности. `lab-verify` выводит оценку всех 13 эталонов и код
ошибки при любом провале; `lab-grade` теперь также возвращает ошибку,
если оценка ниже 100. `capture-ping` требует успешного ICMP-ответа.

См. [фактически выполненные проверки](docs/MVP-VERIFICATION.md) и
[обязательную приёмку](docs/MVP-ACCEPTANCE.md).
