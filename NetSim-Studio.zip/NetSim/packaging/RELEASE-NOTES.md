# NetSim Studio v0.1.0 — draft

This draft is generated only when the release CI completes. Review the actual
CI logs before publication. Native installers are not signed with publisher
certificates; macOS uses ad-hoc signing, not notarization. Review dependency
licenses/notices, manual GUI acceptance, performance on the reference hardware,
and the protocol fidelity limitations in docs/MVP-ACCEPTANCE.md. Do not publish
until these gates are satisfied.
