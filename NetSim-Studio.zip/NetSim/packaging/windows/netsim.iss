#ifndef BuildDir
  #error BuildDir must be supplied
#endif
#ifndef OutputDir
  #error OutputDir must be supplied
#endif
#ifndef RepoDir
  #error RepoDir must be supplied
#endif
[Setup]
AppId=NetSimStudio
AppName=NetSim Studio
AppVersion=0.1.0
DefaultDirName={localappdata}\Programs\NetSim Studio
DefaultGroupName=NetSim Studio
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir={#OutputDir}
OutputBaseFilename=NetSim-Studio-0.1.0-windows-x64-setup
Compression=lzma2
SolidCompression=yes
UninstallDisplayIcon={app}\netsim-gui.exe
[Files]
Source: "{#BuildDir}\netsim-gui.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#BuildDir}\netsim-cli.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#RepoDir}\LICENSE"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#RepoDir}\README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#RepoDir}\examples\*.netsim"; DestDir: "{app}\examples"; Flags: ignoreversion
[Icons]
Name: "{group}\NetSim Studio"; Filename: "{app}\netsim-gui.exe"; WorkingDir: "{userdocs}"
Name: "{group}\Uninstall NetSim Studio"; Filename: "{uninstallexe}"
